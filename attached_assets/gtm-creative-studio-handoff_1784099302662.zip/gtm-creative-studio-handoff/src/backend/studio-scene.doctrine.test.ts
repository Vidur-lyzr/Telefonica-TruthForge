import { beforeEach, describe, expect, it, vi } from "vitest";
import type { BrandPalette } from "./brand-catalog";

/**
 * AWS-ramp doctrine guard for the Creative Studio server scene builders.
 *
 * The studio face must match the GTM canvas / Email-InMail benchmark: a clean
 * split or inset composition with a SOLID copy panel. The rules enforced here:
 *   - NO filled CTA pill (no layer named "CTA_BG").
 *   - NO legibility scrim / gradient overlay (no gradient rects, no "Scrim"/
 *     "Gradient" named layer).
 *   - The CTA is a typeset link: a "CTA_Label" text layer whose text carries the
 *     "→" glyph, coloured interactive blue (never Amazon orange).
 *   - On non-banner layouts copy never sits over the photo: every text layer's
 *     box must be disjoint from the teaser image box.
 *   - Scenes are versioned at the ramp version (2).
 */

const ORANGE = "#FF9900";

const findBrandPalette = vi.fn<(id: string) => BrandPalette | undefined>();
const readBrandPalettes = vi.fn<() => BrandPalette[]>();

vi.mock("./brand-catalog", () => ({
  findBrandPalette: (id: string) => findBrandPalette(id),
  readBrandPalettes: () => readBrandPalettes(),
  catalogByCategory: () => [],
  findCatalogAsset: () => undefined,
  findBrandPalettes: () => [],
}));

import {
  buildDefaultScene,
  buildNeuScene,
  type StudioScene,
} from "./studio-store";

function cleanPalette(): BrandPalette {
  return {
    id: "bp_aws",
    entity: "AWS",
    primary: "#232F3E",
    secondary: "#0073BB",
    accent: "#0073BB",
  };
}

// The full production dimension set, with the compact-banner branch flagged.
const ALL_DIMS: Array<{ w: number; h: number; banner: boolean }> = [
  { w: 160, h: 600, banner: false }, // Skyscraper
  { w: 300, h: 600, banner: false }, // Halfpage
  { w: 728, h: 90, banner: true }, // Leaderboard
  { w: 300, h: 250, banner: false }, // Medium Rectangle
  { w: 320, h: 50, banner: true }, // Mobile Leaderboard
  { w: 1200, h: 626, banner: false }, // Animated
  { w: 1080, h: 1080, banner: false }, // Social Square
  { w: 1080, h: 1350, banner: false }, // Social Portrait
  { w: 1080, h: 1920, banner: false }, // Social Story
  { w: 1200, h: 628, banner: false }, // Paid Social
  { w: 970, h: 250, banner: true }, // Billboard
  { w: 336, h: 280, banner: false }, // Large Rectangle
  { w: 600, h: 200, banner: true }, // Email Header
  { w: 234, h: 60, banner: true }, // Half Banner
];

/** Axis-aligned box overlap (treats edge-touching as disjoint). */
function overlaps(
  a: { x: number; y: number; w: number; h: number },
  b: { x: number; y: number; w: number; h: number },
): boolean {
  return (
    a.x < b.x + b.w &&
    a.x + a.w > b.x &&
    a.y < b.y + b.h &&
    a.y + a.h > b.y
  );
}

function assertRampDoctrine(scene: StudioScene, banner: boolean): void {
  // Versioned at the ramp version.
  expect(scene.version).toBe(2);

  // No filled CTA pill.
  expect(scene.layers.find((l) => l.name === "CTA_BG")).toBeUndefined();

  // No scrim / gradient overlays anywhere.
  for (const l of scene.layers) {
    expect(/scrim|gradient/i.test(l.name)).toBe(false);
    if (l.type === "rect") {
      expect(l.gradient === undefined || l.gradient.length === 0).toBe(true);
    }
  }

  // CTA is a typeset blue link with the arrow glyph.
  const cta = scene.layers.find((l) => l.name === "CTA_Label");
  expect(cta).toBeDefined();
  if (cta && cta.type === "text") {
    expect(cta.text).toContain("\u2192");
    expect(cta.color?.toUpperCase()).not.toBe(ORANGE);
  }

  // No rectangle fill may be Amazon orange.
  for (const l of scene.layers) {
    if (l.type === "rect" && typeof l.fill === "string") {
      expect(l.fill.toUpperCase()).not.toBe(ORANGE);
    }
  }

  // On non-banner layouts, copy never sits over the photo.
  if (!banner) {
    const teaser = scene.layers.find(
      (l) => l.type === "image" && l.fieldId === "teaser_image",
    );
    expect(teaser).toBeDefined();
    if (teaser) {
      for (const l of scene.layers) {
        if (l.type !== "text") continue;
        expect(
          overlaps(l, teaser),
          `${l.name} overlaps the teaser image`,
        ).toBe(false);
      }
    }
  }
}

describe("studio scene doctrine — AWS ramp, no pill, no scrim, copy off-photo", () => {
  beforeEach(() => {
    findBrandPalette.mockReturnValue(cleanPalette());
    readBrandPalettes.mockReturnValue([cleanPalette()]);
  });

  for (const d of ALL_DIMS) {
    it(`buildDefaultScene @ ${d.w}x${d.h} follows the ramp doctrine`, () => {
      assertRampDoctrine(buildDefaultScene(d.w, d.h), d.banner);
    });
  }

  const STYLES = ["navy-hero", "texture-hero", "proof"] as const;
  for (const style of STYLES) {
    for (const d of ALL_DIMS) {
      it(`buildNeuScene[${style}] @ ${d.w}x${d.h} follows the ramp doctrine`, () => {
        assertRampDoctrine(buildNeuScene(d.w, d.h, style), d.banner);
      });
    }
  }
});
