import {
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  renameSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { AGENT_HOME, WORKSPACE_ROOT } from "./agent-home";
import { isValidAccent, resolvePalette } from "./gtm";

/**
 * Creative Studio store — the AdTUNE-parity creative-production data model.
 *
 * Everything lives under `agent-home/.studio/` as atomic JSON + on-disk media,
 * mirroring the existing abm-store conventions (write-tmp-then-rename, safe ids,
 * path-escape guards). The web app renders every creative client-side on
 * react-konva from the stored scene model; this store is the source of truth for
 * assets, templates (with per-dimension scenes), creative feeds, and the
 * persisted render outputs.
 *
 * Filesystem layout:
 *   .studio/assets/index.json                  — asset library index
 *   .studio/assets/files/<assetId>.<ext>       — uploaded media bytes
 *   .studio/templates/<templateId>.json        — template + variants + schema + output
 *   .studio/feeds/<feedId>.json                — creative feed (rows = creatives)
 *   .studio/renders/index.json                 — persisted render index
 *   .studio/renders/files/<renderId>.<ext>     — persisted render bitmaps
 */

function writeJsonAtomic(filePath: string, value: unknown): void {
  ensureDir(path.dirname(filePath));
  const tmp = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  writeFileSync(tmp, JSON.stringify(value, null, 2), "utf-8");
  renameSync(tmp, filePath);
}

function ensureDir(p: string): void {
  if (!existsSync(p)) mkdirSync(p, { recursive: true });
}

const ID_RE = /^[a-z0-9_]+$/;
const SLUG_RE = /^[a-z][a-z0-9_]*$/;

function safeId(prefix: string, id: string): string {
  if (!ID_RE.test(id) || id.length > 80) {
    throw new Error(`Invalid ${prefix} id: ${id}`);
  }
  return id;
}

function safeJoin(baseDir: string, ...parts: string[]): string {
  const resolved = path.resolve(path.join(baseDir, ...parts));
  const baseResolved = path.resolve(baseDir);
  if (
    resolved !== baseResolved &&
    !resolved.startsWith(baseResolved + path.sep)
  ) {
    throw new Error(`Path escape: ${parts.join("/")}`);
  }
  return resolved;
}

function studioDir(): string {
  const d = path.join(AGENT_HOME, ".studio");
  ensureDir(d);
  return d;
}

// =============================================================================
// Scene / layer model (shared shape with the client via mirrored types)
// =============================================================================

export type StudioLayerType = "text" | "image" | "rect";
export type StudioImageKind = "image" | "logo" | "blur";

export type StudioClipType =
  | "fadeIn"
  | "fadeOut"
  | "slideIn"
  | "slideOut"
  | "popIn"
  | "pulse";
export type StudioEasing = "linear" | "easeIn" | "easeOut" | "easeInOut";

export interface StudioAnimationClip {
  type: StudioClipType;
  startMs: number;
  durationMs: number;
  /** Slide direction for slideIn / slideOut. */
  direction?: "left" | "right" | "up" | "down";
  /** Numeric override (px slide distance, or scale factor for pop / pulse). */
  from?: number;
  to?: number;
  easing?: StudioEasing;
}

export interface StudioLayerAnimation {
  clips: StudioAnimationClip[];
}

export interface StudioLayerBase {
  id: string;
  name: string;
  type: StudioLayerType;
  x: number;
  y: number;
  w: number;
  h: number;
  rotation?: number;
  /** 0..1 */
  opacity?: number;
  visible?: boolean;
  locked?: boolean;
  /** Optional keyframe animation; only played on dynamic variants. */
  animation?: StudioLayerAnimation;
}

export interface StudioTextLayer extends StudioLayerBase {
  type: "text";
  /** Static text; may contain merge tokens like %field_id%. */
  text: string;
  /** Bound rich-text schema field id; when set, content comes from the creative row. */
  fieldId?: string;
  fontFamily?: string;
  fontSize?: number;
  fontWeight?: number;
  lineHeight?: number;
  letterSpacing?: number;
  align?: "left" | "center" | "right";
  valign?: "top" | "middle" | "bottom";
  color?: string;
  upper?: boolean;
}

export interface StudioImageLayer extends StudioLayerBase {
  type: "image";
  imageKind: StudioImageKind;
  /** Default asset id when no feed binding / no row value. */
  assetId?: string;
  /** Bound media schema field id; when set, the asset comes from the creative row. */
  fieldId?: string;
  fit?: "cover" | "contain" | "stretch";
  cornerRadius?: number;
  /** Konva blur radius for "blur" image layers (frosted background). */
  blur?: number;
  /** Unsharp-mask amount (0–100) for non-blur image/logo layers. */
  sharpen?: number;
  /**
   * Template-level cover-crop framing for THIS image section (focal pan/zoom).
   * Per-LAYER (not per-fieldId) so a blurred background and the sharp foreground
   * card bound to the same media field can be framed independently. Applied at
   * render/export as the base crop; a per-creative row crop (keyed by fieldId)
   * still wins when present.
   */
  crop?: StudioCropOverride;
}

export interface StudioRectLayer extends StudioLayerBase {
  type: "rect";
  fill?: string;
  /** Optional CSS-style linear gradient applied vertically (legibility scrims). */
  gradient?: [number, string][];
  cornerRadius?: number;
  stroke?: string;
  strokeWidth?: number;
}

export type StudioLayer = StudioTextLayer | StudioImageLayer | StudioRectLayer;

export interface StudioTimeline {
  /** Total scene duration in ms. */
  durationMs: number;
  /** Capture frame-rate for animated export. */
  fps: number;
  /** Time (ms) at which the static poster / thumbnail frame is sampled. */
  captureMs: number;
}

export interface StudioScene {
  version: number;
  bg: string;
  layers: StudioLayer[];
  /** Optional animation timeline; absent ⇒ static scene (captured at 0ms). */
  timeline?: StudioTimeline;
}

// =============================================================================
// Schema fields
// =============================================================================

export type StudioFieldType = "media" | "rich_text";

export interface StudioSchemaField {
  /** Slug identifier used as the merge-token name, e.g. "headline". */
  id: string;
  label: string;
  type: StudioFieldType;
  description?: string;
  multi?: boolean;
  defaultValue?: string;
  preselectedAssetIds?: string[];
  /** Allowed media formats (lowercase, no dot): png jpg svg webp gif. */
  allowedFormats?: string[];
  maxSizeMB?: number;
  hidden?: boolean;
}

// =============================================================================
// Variants (dimensions) + output settings + template
// =============================================================================

export interface StudioVariant {
  id: string;
  name: string;
  type: "static" | "dynamic";
  width: number;
  height: number;
  scene: StudioScene;
}

export interface StudioOutputSettings {
  /** variantId -> enabled export formats (subset of png/jpg/webp). */
  formatsByVariant: Record<string, string[]>;
}

export interface StudioTemplate {
  id: string;
  name: string;
  brand?: string;
  schemaFields: StudioSchemaField[];
  variants: StudioVariant[];
  output: StudioOutputSettings;
  createdAt: number;
  updatedAt: number;
}

export const STUDIO_STATIC_FORMATS = ["png", "jpg", "webp"] as const;
export const STUDIO_DYNAMIC_FORMATS = ["gif", "html5"] as const;
export const STUDIO_ALL_FORMATS = [
  ...STUDIO_STATIC_FORMATS,
  ...STUDIO_DYNAMIC_FORMATS,
] as const;

/** File extension on disk for a persisted render of the given output format. */
export function renderExtForFormat(format: string): string {
  if (format === "jpg" || format === "jpeg") return "jpg";
  if (format === "html5") return "html";
  return format;
}

// =============================================================================
// Assets
// =============================================================================

export type StudioAssetKind = "image" | "packshot";

export interface StudioAsset {
  id: string;
  kind: StudioAssetKind;
  originalName: string;
  fileName: string;
  mime: string;
  ext: string;
  width?: number;
  height?: number;
  bytes: number;
  tags: string[];
  createdAt: number;
}

export interface StudioAssetIndex {
  assets: StudioAsset[];
  updatedAt: number;
}

// =============================================================================
// Feeds / creatives
// =============================================================================

export interface StudioCropOverride {
  /** Normalized focal offset (-0.5..0.5) and zoom (>=1) for one image cell. */
  x: number;
  y: number;
  scale: number;
}

/** Per-creative layer-style override keyed by image fieldId (see client type). */
export interface StudioStyleOverride {
  opacity?: number;
  cornerRadius?: number;
  blur?: number;
}

export interface StudioCreativeRow {
  id: string;
  uid: string;
  locale: string;
  tags: string[];
  /** fieldId -> value (rich_text string OR media assetId). */
  values: Record<string, string>;
  /** Multi-slice crops keyed by `${variantId}:${fieldId}`. */
  crops?: Record<string, StudioCropOverride>;
  /** Per-creative layer-style overrides keyed by image fieldId. */
  styleOverrides?: Record<string, StudioStyleOverride>;
}

export interface StudioFeed {
  id: string;
  templateId: string;
  name: string;
  rows: StudioCreativeRow[];
  createdAt: number;
  updatedAt: number;
}

// =============================================================================
// Renders
// =============================================================================

export interface StudioRender {
  id: string;
  feedId: string;
  rowId: string;
  variantId: string;
  format: string;
  fileName: string;
  width: number;
  height: number;
  bytes: number;
  createdAt: number;
}

export interface StudioRenderIndex {
  renders: StudioRender[];
  updatedAt: number;
}

// =============================================================================
// Default scene generator — produces a tasteful adaptive layout for a new
// dimension. Shared single source so seeded and user-created variants match.
// =============================================================================

const BRAND = {
  navy: "#161E2D",
  blue: "#0972D3",
  // Amazon Orange is reserved for the AWS Smile logo ONLY. It must never be used
  // as a CTA / accent fill — use `ctaFill()` for buttons, not `BRAND.orange`.
  orange: "#FF9900",
  ink: "#0B1F33",
  paper: "#FFFFFF",
};

/**
 * Brand-safe CTA / accent fill for generated scenes. The studio face is AWS
 * Interactive Blue (`#0972D3`); it is validated through the same brand
 * governance rule (`isValidAccent`) that forbids Amazon orange from ever
 * becoming an accent, falling back to the governance palette accent if the
 * studio blue itself ever fails the rule. This guarantees a static template
 * scene can never emit `#FF9900` as a CTA fill.
 */
export function ctaFill(): string {
  return isValidAccent(BRAND.blue) ? BRAND.blue : resolvePalette({}).accent;
}

/**
 * Northern European Banking campaign palette + type face. The GenAI-on-Bedrock
 * tailored asset is anchor-forward: Squid Ink navy leads, AWS Interactive Blue
 * is the single accent signal, and Amazon Orange stays reserved for the AWS
 * logo. Consumed by `buildNeuScene` so the NEU GTM template library renders in
 * the campaign's real tokens rather than the generic studio navy.
 */
const NEU = {
  navy: "#232F3E", // Squid Ink — primary anchor surface
  navyDeep: "#161E2D", // deeper navy band for depth
  blue: "#0073BB", // AWS Interactive Blue — accent / CTA / eyebrow
  blueDeep: "#1D69A8", // FSI secondary blue
  paper: "#FFFFFF",
} as const;

/** Amazon Ember Mono stack — matches the agent-os `--font-ember-mono` face. */
const EMBER_MONO_STACK =
  '"Amazon Ember Mono", "Open Sans", ui-monospace, "SFMono-Regular", Menlo, monospace';

/**
 * Brand-safe NEU accent. The campaign accent is AWS Interactive Blue (#0073BB);
 * it is validated through the same `isValidAccent` rule that forbids Amazon
 * orange, falling back to the governed studio CTA blue if it ever fails. A NEU
 * scene can therefore never emit `#FF9900` as a CTA / accent fill.
 */
export function neuAccent(): string {
  return isValidAccent(NEU.blue) ? NEU.blue : ctaFill();
}

let layerSeq = 0;
function lid(_prefix: string): string {
  layerSeq += 1;
  return `ly_${Date.now().toString(36)}_${layerSeq}_${randomUUID().slice(0, 4)}`;
}

// =============================================================================
// AWS strict type-ramp scene builder (Creative Studio)
//
// The studio face matches the GTM canvas (agent-os scene.ts buildScene) and the
// Email/InMail benchmark: a split / inset composition of CLEAN imagery and a
// SOLID copy panel. Copy lives only on the panel — NEVER over the photo, never
// behind a scrim. The CTA is a typeset link ("label →") in Amazon Ember
// Display interactive blue — never a filled pill. The eyebrow is Amazon Ember
// Mono, uppercased. All geometry is capped by min(W,H) plus a safe-area pad so
// nothing crops at any dimension. The renderer's auto-fit then shrinks any
// over-long copy so headlines and CTAs can never clip.
// =============================================================================

/**
 * Scene-spec version. Bump whenever the generated layout doctrine changes so the
 * seeder can detect and regenerate scenes persisted by an older builder.
 */
export const STUDIO_AWS_RAMP_SCENE_VERSION = 2;

/** Baked into the CTA text so it always reads as a typeset link, not a pill. */
const CTA_ARROW = "\u2192";

interface RampPalette {
  /** Solid copy-panel + page surface (anchor navy). */
  surface: string;
  /** Deeper navy base behind the image region (clean fallback / proof frame). */
  surfaceDeep: string;
  /** Interactive blue — eyebrow, CTA link and accent rules. */
  accent: string;
  /** White copy. */
  paper: string;
}

interface RampRegion {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Contained logo lockup at the top-left of a copy panel. */
function pushRampLogo(layers: StudioLayer[], r: RampRegion): void {
  layers.push({
    id: lid("logo"),
    name: "Logo",
    type: "image",
    imageKind: "logo",
    fieldId: "logo",
    x: r.x,
    y: r.y,
    w: r.w,
    h: r.h,
    fit: "contain",
  } satisfies StudioImageLayer);
}

/**
 * Lay out the copy stack (logo → eyebrow → headline → CTA link) on a SOLID
 * panel region. The headline flexes to fill the gap between the eyebrow and the
 * CTA; the CTA is pinned near the panel foot as an accent link. No pill, no
 * scrim. Returns nothing — pushes layers in z-order onto `layers`.
 */
function pushPanelCopy(
  layers: StudioLayer[],
  panel: RampRegion,
  palette: RampPalette,
  opts: { withEyebrow: boolean; accentRule: boolean },
): void {
  const pad = Math.max(10, Math.round(Math.min(panel.w, panel.h) * 0.09));
  const innerX = panel.x + pad;
  const innerW = Math.max(8, panel.w - pad * 2);
  const innerTop = panel.y + pad;
  const innerBottom = panel.y + panel.h - pad;
  const innerH = Math.max(8, innerBottom - innerTop);

  // Logo lockup (top-left).
  const logoH = Math.max(
    14,
    Math.min(Math.round(panel.h * 0.14), Math.round(innerW * 0.42), 72),
  );
  const logoW = Math.min(Math.round(logoH * 3), innerW);
  pushRampLogo(layers, { x: innerX, y: innerTop, w: logoW, h: logoH });

  let cursor = innerTop + logoH + Math.round(innerH * 0.07);

  // Eyebrow — Amazon Ember Mono, uppercased, accent blue.
  if (opts.withEyebrow) {
    const eyeFs = Math.max(
      10,
      Math.min(Math.round(innerW * 0.05), Math.round(panel.h * 0.045), 22),
    );
    const eyeH = Math.round(eyeFs * 1.5);
    layers.push({
      id: lid("eyebrow"),
      name: "Eyebrow",
      type: "text",
      fieldId: "eyebrow",
      text: "%eyebrow%",
      x: innerX,
      y: cursor,
      w: innerW,
      h: eyeH,
      fontSize: eyeFs,
      fontFamily: EMBER_MONO_STACK,
      fontWeight: 700,
      letterSpacing: Math.max(1, Math.round(eyeFs * 0.08)),
      color: palette.accent,
      align: "left",
      valign: "middle",
      upper: true,
    } satisfies StudioTextLayer);
    cursor += eyeH + Math.round(innerH * 0.03);

    // Proof style: a short accent rule under the eyebrow.
    if (opts.accentRule) {
      const ruleH = Math.max(2, Math.round(panel.h * 0.007));
      const ruleW = Math.min(innerW, Math.max(24, Math.round(innerW * 0.36)));
      layers.push({
        id: lid("rule"),
        name: "Accent_Rule",
        type: "rect",
        x: innerX,
        y: cursor,
        w: ruleW,
        h: ruleH,
        fill: palette.accent,
      } satisfies StudioRectLayer);
      cursor += ruleH + Math.round(innerH * 0.035);
    }
  }

  // CTA link pinned near the panel foot ("label →").
  const ctaFs = Math.max(
    11,
    Math.min(Math.round(innerW * 0.06), Math.round(panel.h * 0.07), 30),
  );
  const ctaH = Math.round(ctaFs * 1.5);
  const ctaY = innerBottom - ctaH;
  layers.push({
    id: lid("cta"),
    name: "CTA_Label",
    type: "text",
    fieldId: "cta_label",
    text: `%cta_label% ${CTA_ARROW}`,
    x: innerX,
    y: ctaY,
    w: innerW,
    h: ctaH,
    fontSize: ctaFs,
    fontWeight: 500,
    color: palette.accent,
    align: "left",
    valign: "middle",
  } satisfies StudioTextLayer);

  // Headline fills the gap between the cursor and the CTA — auto-fit shrinks it.
  const headTop = cursor;
  const headGap = Math.round(innerH * 0.035);
  const headBottom = ctaY - headGap;
  const headH = Math.max(8, headBottom - headTop);
  const headFs = Math.max(
    12,
    Math.min(Math.round(innerW * 0.13), Math.round(headH * 0.4)),
  );
  layers.push({
    id: lid("headline"),
    name: "Headline",
    type: "text",
    fieldId: "headline",
    text: "%headline%",
    x: innerX,
    y: headTop,
    w: innerW,
    h: headH,
    fontSize: headFs,
    fontWeight: 500,
    lineHeight: 1.12,
    color: palette.paper,
    align: "left",
    valign: "top",
  } satisfies StudioTextLayer);
}

/**
 * Compact horizontal banner (no photo room): a solid surface with a left accent
 * tab, logo · headline · CTA link on a single centred row. Used for leaderboard
 * / billboard / email-header / half-banner classes.
 */
function pushBannerRow(
  layers: StudioLayer[],
  W: number,
  H: number,
  palette: RampPalette,
): void {
  const barW = Math.max(3, Math.round(W * 0.012));
  layers.push({
    id: lid("tab"),
    name: "Accent_Tab",
    type: "rect",
    x: 0,
    y: 0,
    w: barW,
    h: H,
    fill: palette.accent,
  } satisfies StudioRectLayer);

  const pad = Math.max(8, Math.round(H * 0.18));
  const rowTop = pad;
  const rowH = Math.max(8, H - pad * 2);
  const leftX = barW + pad;

  // Logo.
  const logoH = rowH;
  const logoW = Math.min(Math.round(rowH * 2.6), Math.round(W * 0.18));
  pushRampLogo(layers, { x: leftX, y: rowTop, w: logoW, h: logoH });

  // CTA link (right).
  const gap = Math.max(6, Math.round(W * 0.02));
  const ctaW = Math.min(Math.round(W * 0.3), Math.max(Math.round(W * 0.18), 100));
  const ctaX = W - pad - ctaW;
  // Cap by the CTA box width too so the longest CTA copy stays within two lines.
  const ctaFs = Math.max(
    10,
    Math.min(Math.round(H * 0.3), Math.round(W * 0.05), Math.round(ctaW * 0.16)),
  );
  layers.push({
    id: lid("cta"),
    name: "CTA_Label",
    type: "text",
    fieldId: "cta_label",
    text: `%cta_label% ${CTA_ARROW}`,
    x: ctaX,
    y: rowTop,
    w: ctaW,
    h: rowH,
    fontSize: ctaFs,
    fontWeight: 500,
    color: palette.accent,
    align: "right",
    valign: "middle",
  } satisfies StudioTextLayer);

  // Headline between the logo and the CTA.
  const headX = leftX + logoW + gap;
  const headW = Math.max(8, ctaX - gap - headX);
  const headFs = Math.max(11, Math.min(Math.round(H * 0.34), Math.round(headW * 0.1)));
  layers.push({
    id: lid("headline"),
    name: "Headline",
    type: "text",
    fieldId: "headline",
    text: "%headline%",
    x: headX,
    y: rowTop,
    w: headW,
    h: rowH,
    fontSize: headFs,
    fontWeight: 500,
    lineHeight: 1.1,
    color: palette.paper,
    align: "left",
    valign: "middle",
  } satisfies StudioTextLayer);
}

/**
 * The single adaptive AWS-ramp scene builder shared by the default master and
 * every NEU style. Three composition families:
 *   - compact banner  → solid surface, logo · headline · CTA link row (no photo)
 *   - landscape       → copy panel left | clean image right (side-by-side)
 *   - stacked         → clean image top | copy panel bottom (square / portrait)
 *
 * `style` only varies the image emphasis + accent treatment; the copy doctrine
 * (solid panel, typeset CTA link, Ember type, no scrim) is identical.
 */
function buildRampScene(
  W: number,
  H: number,
  palette: RampPalette,
  style: "navy-hero" | "texture-hero" | "proof",
  withEyebrow: boolean,
  blurBackdrop = false,
): StudioScene {
  const layers: StudioLayer[] = [];
  const ar = W / H;

  // Base surface fills the whole canvas (also the copy-panel background).
  layers.push({
    id: lid("bg"),
    name: "Surface",
    type: "rect",
    x: 0,
    y: 0,
    w: W,
    h: H,
    fill: palette.surface,
  } satisfies StudioRectLayer);

  // Compact horizontal banners get the no-photo treatment.
  const isBanner = H <= 260 && ar >= 2.4;
  if (isBanner) {
    pushBannerRow(layers, W, H, palette);
    return { version: STUDIO_AWS_RAMP_SCENE_VERSION, bg: palette.surface, layers };
  }

  const minDim = Math.min(W, H);
  const isSquare = Math.abs(W - H) <= Math.round(minDim * 0.08);
  const stacked = isSquare || H > W;

  // Image + panel regions (non-overlapping).
  let image: RampRegion;
  let panel: RampRegion;
  if (stacked) {
    const frac =
      style === "texture-hero" ? 0.52 : isSquare ? 0.42 : 0.36;
    const imageH = Math.round(H * frac);
    image = { x: 0, y: 0, w: W, h: imageH };
    panel = { x: 0, y: imageH, w: W, h: H - imageH };
  } else {
    const panelFrac = style === "texture-hero" ? 0.48 : 0.58;
    const panelW = Math.round(W * panelFrac);
    panel = { x: 0, y: 0, w: panelW, h: H };
    image = { x: panelW, y: 0, w: W - panelW, h: H };
  }

  // Deep navy base behind the full image region (clean fallback + proof frame).
  layers.push({
    id: lid("imgbase"),
    name: "Image_Base",
    type: "rect",
    x: image.x,
    y: image.y,
    w: image.w,
    h: image.h,
    fill: palette.surfaceDeep,
  } satisfies StudioRectLayer);

  // AdTune-style soft blurred backdrop: a full-bleed blurred copy of the teaser
  // filling the whole image region, sitting UNDER the sharp focal teaser. The
  // sharp teaser is inset (below) so the blur reads as a premium halo around it.
  // Copy always stays in the solid panel — never painted over a photo (doctrine).
  if (blurBackdrop) {
    layers.push({
      id: lid("teaserblur"),
      name: "Teaser_Blur",
      type: "image",
      imageKind: "blur",
      fieldId: "teaser_image",
      x: image.x,
      y: image.y,
      w: image.w,
      h: image.h,
      fit: "cover",
      blur: Math.max(10, Math.round(minDim * 0.05)),
    } satisfies StudioImageLayer);
  }

  // Proof style insets the image so a navy frame + rounded corners reads. With a
  // blurred backdrop every style insets the sharp focal so the blur halo shows.
  let imageRect = image;
  let cornerRadius = 0;
  if (style === "proof") {
    const m = Math.max(6, Math.round(minDim * 0.05));
    imageRect = {
      x: image.x + m,
      y: image.y + m,
      w: Math.max(8, image.w - m * 2),
      h: Math.max(8, image.h - m * 2),
    };
    cornerRadius = Math.round(minDim * 0.02);
  } else if (blurBackdrop) {
    const m = Math.max(4, Math.round(minDim * 0.035));
    imageRect = {
      x: image.x + m,
      y: image.y + m,
      w: Math.max(8, image.w - m * 2),
      h: Math.max(8, image.h - m * 2),
    };
    cornerRadius = Math.round(minDim * 0.012);
  }

  layers.push({
    id: lid("teaser"),
    name: "Teaser",
    type: "image",
    imageKind: "image",
    fieldId: "teaser_image",
    x: imageRect.x,
    y: imageRect.y,
    w: imageRect.w,
    h: imageRect.h,
    fit: "cover",
    cornerRadius,
    sharpen: 12,
  } satisfies StudioImageLayer);

  // Accent treatment varies by style (graphic only — never over the copy text).
  if (style === "navy-hero") {
    // Thin accent bar along the panel's outer edge.
    const barW = Math.max(3, Math.round(minDim * 0.018));
    layers.push({
      id: lid("bar"),
      name: "Accent_Bar",
      type: "rect",
      x: panel.x,
      y: panel.y,
      w: barW,
      h: panel.h,
      fill: palette.accent,
    } satisfies StudioRectLayer);
  } else {
    // texture-hero + proof: an accent divider at the image / panel seam.
    const thick = Math.max(2, Math.round(minDim * (style === "proof" ? 0.014 : 0.008)));
    if (stacked) {
      layers.push({
        id: lid("div"),
        name: "Accent_Divider",
        type: "rect",
        x: 0,
        y: Math.max(0, image.y + image.h - thick),
        w: W,
        h: thick,
        fill: palette.accent,
      } satisfies StudioRectLayer);
    } else {
      layers.push({
        id: lid("div"),
        name: "Accent_Divider",
        type: "rect",
        x: Math.max(0, panel.x + panel.w - thick),
        y: 0,
        w: thick,
        h: H,
        fill: palette.accent,
      } satisfies StudioRectLayer);
    }
  }

  pushPanelCopy(layers, panel, palette, {
    withEyebrow,
    accentRule: style === "proof",
  });

  return { version: STUDIO_AWS_RAMP_SCENE_VERSION, bg: palette.surface, layers };
}

/**
 * Build an adaptive default scene for a w×h dimension (the AWS CX Banner master).
 * Clean split/inset composition, solid copy panel, typeset CTA link — no pill,
 * no scrim. Layers bind to the standard schema field ids (logo, teaser_image,
 * headline, cta_label) so a creative feed lights up every dimension at once.
 */
export function buildDefaultScene(width: number, height: number): StudioScene {
  return buildRampScene(
    width,
    height,
    {
      surface: BRAND.navy,
      surfaceDeep: "#0F1722",
      accent: ctaFill(),
      paper: BRAND.paper,
    },
    "navy-hero",
    false,
  );
}

export type NeuStyle = "navy-hero" | "texture-hero" | "proof";

/**
 * Build a Northern European Banking GTM scene in one of three styles, all on the
 * same AWS ramp (Squid Ink navy surface, AWS Interactive Blue accent, Amazon
 * Ember Display/Mono, typeset CTA link, clean split/inset imagery, no scrim).
 * Adds an Ember Mono eyebrow on top of the shared copy doctrine.
 */
export function buildNeuScene(
  width: number,
  height: number,
  style: NeuStyle = "navy-hero",
): StudioScene {
  return buildRampScene(
    width,
    height,
    {
      surface: NEU.navy,
      surfaceDeep: NEU.navyDeep,
      accent: neuAccent(),
      paper: NEU.paper,
    },
    style,
    true,
    // blurBackdrop: NEU creatives carry the AdTune soft-blur depth by default.
    true,
  );
}

// =============================================================================
// Blur-Hero scene builder (Northern European Banking)
//
// A DISTINCT look from the AWS ramp: a soft full-bleed blurred teaser fills the
// frame, a crisp rounded image card sits inset on top, and the AWS logo +
// headline are overlaid DIRECTLY on the blur (over a low navy legibility scrim)
// — deliberately departing from the ramp doctrine of "copy only on a solid
// panel". The blurred backdrop AND the sharp card both bind `teaser_image`, so
// each is given its own per-layer crop framing (independent focal pan/zoom).
// =============================================================================

/** Scene-spec version for blur-hero layouts (independent of the ramp version). */
export const STUDIO_BLUR_HERO_SCENE_VERSION = 1;

interface BlurRegion {
  x: number;
  y: number;
  w: number;
  h: number;
}

function pushBlurLogo(layers: StudioLayer[], r: BlurRegion): void {
  layers.push({
    id: lid("logo"),
    name: "Logo",
    type: "image",
    imageKind: "logo",
    fieldId: "logo",
    x: r.x,
    y: r.y,
    w: r.w,
    h: r.h,
    fit: "contain",
  } satisfies StudioImageLayer);
}

function pushBlurCard(
  layers: StudioLayer[],
  r: BlurRegion,
  cornerRadius: number,
): void {
  layers.push({
    id: lid("card"),
    name: "Teaser_Card",
    type: "image",
    imageKind: "image",
    fieldId: "teaser_image",
    x: r.x,
    y: r.y,
    w: r.w,
    h: r.h,
    fit: "cover",
    cornerRadius,
    sharpen: 12,
  } satisfies StudioImageLayer);
}

function pushBlurHeadline(
  layers: StudioLayer[],
  r: BlurRegion,
  fontSize: number,
  valign: "top" | "middle" | "bottom",
): void {
  layers.push({
    id: lid("headline"),
    name: "Headline",
    type: "text",
    fieldId: "headline",
    text: "%headline%",
    x: r.x,
    y: r.y,
    w: r.w,
    h: r.h,
    fontSize,
    fontWeight: 600,
    lineHeight: 1.12,
    color: NEU.paper,
    align: "left",
    valign,
  } satisfies StudioTextLayer);
}

function pushBlurCta(
  layers: StudioLayer[],
  r: BlurRegion,
  fontSize: number,
  accent: string,
): void {
  layers.push({
    id: lid("cta"),
    name: "CTA_Label",
    type: "text",
    fieldId: "cta_label",
    text: `%cta_label% ${CTA_ARROW}`,
    x: r.x,
    y: r.y,
    w: r.w,
    h: r.h,
    fontSize,
    fontWeight: 500,
    color: accent,
    align: "left",
    valign: "middle",
  } satisfies StudioTextLayer);
}

/**
 * Build a Northern European Banking blur-hero scene for a w×h dimension.
 * Adaptive across three families — wide-short banner, tall portrait, and
 * square-ish rectangle — but always: blurred teaser backdrop → legibility scrim
 * → sharp inset card → logo → overlaid headline (+ CTA where space allows).
 * Layers bind the standard NEU schema ids so a feed lights up every size.
 */
export function buildBlurHeroScene(W: number, H: number): StudioScene {
  const layers: StudioLayer[] = [];
  const minDim = Math.min(W, H);
  const ar = W / H;
  const accent = neuAccent();

  // 1) Full-bleed blurred teaser backdrop.
  layers.push({
    id: lid("blurbg"),
    name: "Teaser_Blur_BG",
    type: "image",
    imageKind: "blur",
    fieldId: "teaser_image",
    x: 0,
    y: 0,
    w: W,
    h: H,
    fit: "cover",
    blur: Math.max(10, Math.round(minDim * 0.06)),
  } satisfies StudioImageLayer);

  // 2) Low navy legibility scrim so overlaid white copy stays readable on the
  //    blur (sits UNDER the sharp card, which is painted next, so the card is
  //    never darkened).
  layers.push({
    id: lid("scrim"),
    name: "Legibility_Scrim",
    type: "rect",
    x: 0,
    y: 0,
    w: W,
    h: H,
    fill: NEU.navy,
    opacity: 0.46,
  } satisfies StudioRectLayer);

  const isBanner = H <= 120 && ar >= 2.4;
  const stacked = H > W;
  const cardRadius = Math.max(3, Math.round(minDim * 0.04));

  if (isBanner) {
    // Wide-short: logo left · headline centre · sharp card right.
    const pad = Math.max(5, Math.round(H * 0.16));
    const rowTop = pad;
    const rowH = Math.max(8, H - pad * 2);
    const gap = Math.max(5, Math.round(W * 0.02));

    const cardW = Math.min(Math.round(W * 0.24), Math.round(rowH * 1.6));
    const cardX = W - pad - cardW;
    pushBlurCard(layers, { x: cardX, y: rowTop, w: cardW, h: rowH }, cardRadius);

    const logoH = rowH;
    const logoW = Math.min(Math.round(rowH * 2.6), Math.round(W * 0.18));
    pushBlurLogo(layers, { x: pad, y: rowTop, w: logoW, h: logoH });

    const headX = pad + logoW + gap;
    const headW = Math.max(8, cardX - gap - headX);
    const headFs = Math.max(
      11,
      Math.min(Math.round(H * 0.34), Math.round(headW * 0.1)),
    );
    pushBlurHeadline(
      layers,
      { x: headX, y: rowTop, w: headW, h: rowH },
      headFs,
      "middle",
    );
    return { version: STUDIO_BLUR_HERO_SCENE_VERSION, bg: NEU.navy, layers };
  }

  if (stacked) {
    // Tall portrait: logo top · headline · sharp card · CTA foot.
    const pad = Math.max(10, Math.round(minDim * 0.08));
    const innerX = pad;
    const innerW = Math.max(8, W - pad * 2);

    const logoH = Math.max(16, Math.min(Math.round(H * 0.07), 56));
    const logoW = Math.min(Math.round(logoH * 3), innerW);
    pushBlurLogo(layers, { x: innerX, y: pad, w: logoW, h: logoH });

    const headTop = pad + logoH + Math.round(H * 0.025);
    const headH = Math.round(H * 0.2);
    const headFs = Math.max(
      13,
      Math.min(Math.round(innerW * 0.13), Math.round(headH * 0.34)),
    );
    pushBlurHeadline(
      layers,
      { x: innerX, y: headTop, w: innerW, h: headH },
      headFs,
      "top",
    );

    const ctaFs = Math.max(11, Math.min(Math.round(innerW * 0.08), 24));
    const ctaH = Math.round(ctaFs * 1.6);
    const ctaY = H - pad - ctaH;

    const cardTop = headTop + headH + Math.round(H * 0.02);
    const cardBottom = ctaY - Math.round(H * 0.025);
    const cardH = Math.max(40, cardBottom - cardTop);
    pushBlurCard(
      layers,
      { x: innerX, y: cardTop, w: innerW, h: cardH },
      cardRadius,
    );

    pushBlurCta(
      layers,
      { x: innerX, y: ctaY, w: innerW, h: ctaH },
      ctaFs,
      accent,
    );
    return { version: STUDIO_BLUR_HERO_SCENE_VERSION, bg: NEU.navy, layers };
  }

  // Square-ish (medium rectangle): headline top · sharp card centre · logo foot.
  const pad = Math.max(8, Math.round(minDim * 0.07));
  const innerX = pad;
  const innerW = Math.max(8, W - pad * 2);

  const headH = Math.round(H * 0.26);
  const headFs = Math.max(
    13,
    Math.min(Math.round(innerW * 0.1), Math.round(headH * 0.4)),
  );
  pushBlurHeadline(
    layers,
    { x: innerX, y: pad, w: innerW, h: headH },
    headFs,
    "top",
  );

  const logoH = Math.max(14, Math.min(Math.round(H * 0.1), 40));
  const logoW = Math.min(Math.round(logoH * 3), Math.round(innerW * 0.5));
  const logoY = H - pad - logoH;
  pushBlurLogo(layers, { x: W - pad - logoW, y: logoY, w: logoW, h: logoH });

  const cardTop = pad + headH + Math.round(H * 0.02);
  const cardBottom = logoY - Math.round(H * 0.02);
  const cardH = Math.max(40, cardBottom - cardTop);
  pushBlurCard(
    layers,
    { x: innerX, y: cardTop, w: innerW, h: cardH },
    Math.max(4, Math.round(minDim * 0.035)),
  );
  return { version: STUDIO_BLUR_HERO_SCENE_VERSION, bg: NEU.navy, layers };
}

// =============================================================================
// Token resolution — replace %field_id% with the row's value.
// =============================================================================

export function resolveTokens(
  text: string,
  values: Record<string, string>,
): string {
  return text.replace(/%([a-z][a-z0-9_]*)%/g, (_m, key: string) => {
    const v = values[key];
    return typeof v === "string" && v.length > 0 ? v : "";
  });
}

// =============================================================================
// Templates store
// =============================================================================

function templatesDir(): string {
  const d = path.join(studioDir(), "templates");
  ensureDir(d);
  return d;
}

export function newTemplateId(): string {
  return `tpl_${Date.now()}_${randomUUID().replace(/-/g, "").slice(0, 8)}`;
}
export function newVariantId(): string {
  return `var_${Date.now()}_${randomUUID().replace(/-/g, "").slice(0, 6)}`;
}
export function newFeedId(): string {
  return `feed_${Date.now()}_${randomUUID().replace(/-/g, "").slice(0, 8)}`;
}
export function newRowId(): string {
  return `row_${Date.now()}_${randomUUID().replace(/-/g, "").slice(0, 6)}`;
}
export function newAssetId(): string {
  return `ast_${Date.now()}_${randomUUID().replace(/-/g, "").slice(0, 8)}`;
}
export function newRenderId(): string {
  return `rnd_${Date.now()}_${randomUUID().replace(/-/g, "").slice(0, 8)}`;
}

export function validateFieldId(id: string): string {
  if (!SLUG_RE.test(id) || id.length > 48) {
    throw new Error(`Invalid field identifier: ${id}`);
  }
  return id;
}

export function listTemplates(): StudioTemplate[] {
  const dir = templatesDir();
  const files = readdirSync(dir).filter((f) => f.endsWith(".json"));
  const out: StudioTemplate[] = [];
  for (const f of files) {
    try {
      out.push(JSON.parse(readFileSync(path.join(dir, f), "utf-8")));
    } catch {
      // skip corrupt
    }
  }
  return out.sort((a, b) => b.updatedAt - a.updatedAt);
}

export function getTemplate(id: string): StudioTemplate | null {
  try {
    const p = safeJoin(templatesDir(), `${safeId("template", id)}.json`);
    if (!existsSync(p)) return null;
    return JSON.parse(readFileSync(p, "utf-8"));
  } catch {
    return null;
  }
}

export function saveTemplate(t: StudioTemplate): void {
  const p = safeJoin(templatesDir(), `${safeId("template", t.id)}.json`);
  t.updatedAt = Date.now();
  writeJsonAtomic(p, t);
}

export function deleteTemplate(id: string): boolean {
  try {
    const p = safeJoin(templatesDir(), `${safeId("template", id)}.json`);
    if (!existsSync(p)) return false;
    rmSync(p, { force: true });
    return true;
  } catch {
    return false;
  }
}

// =============================================================================
// Feeds store
// =============================================================================

function feedsDir(): string {
  const d = path.join(studioDir(), "feeds");
  ensureDir(d);
  return d;
}

export function listFeeds(templateId?: string): StudioFeed[] {
  const dir = feedsDir();
  const files = readdirSync(dir).filter((f) => f.endsWith(".json"));
  const out: StudioFeed[] = [];
  for (const f of files) {
    try {
      const feed = JSON.parse(
        readFileSync(path.join(dir, f), "utf-8"),
      ) as StudioFeed;
      if (templateId && feed.templateId !== templateId) continue;
      out.push(feed);
    } catch {
      // skip
    }
  }
  return out.sort((a, b) => b.updatedAt - a.updatedAt);
}

export function getFeed(id: string): StudioFeed | null {
  try {
    const p = safeJoin(feedsDir(), `${safeId("feed", id)}.json`);
    if (!existsSync(p)) return null;
    return JSON.parse(readFileSync(p, "utf-8"));
  } catch {
    return null;
  }
}

export function saveFeed(f: StudioFeed): void {
  const p = safeJoin(feedsDir(), `${safeId("feed", f.id)}.json`);
  f.updatedAt = Date.now();
  writeJsonAtomic(p, f);
}

export function deleteFeed(id: string): boolean {
  try {
    const p = safeJoin(feedsDir(), `${safeId("feed", id)}.json`);
    if (!existsSync(p)) return false;
    rmSync(p, { force: true });
    return true;
  } catch {
    return false;
  }
}

// =============================================================================
// Assets store
// =============================================================================

export function assetsDir(): string {
  const d = path.join(studioDir(), "assets");
  ensureDir(d);
  return d;
}

export function assetFilesDir(): string {
  const d = path.join(assetsDir(), "files");
  ensureDir(d);
  return d;
}

function assetIndexPath(): string {
  return path.join(assetsDir(), "index.json");
}

export function readAssetIndex(): StudioAssetIndex {
  try {
    const p = assetIndexPath();
    if (!existsSync(p)) return { assets: [], updatedAt: 0 };
    return JSON.parse(readFileSync(p, "utf-8"));
  } catch {
    return { assets: [], updatedAt: 0 };
  }
}

export function saveAssetIndex(idx: StudioAssetIndex): void {
  idx.updatedAt = Date.now();
  writeJsonAtomic(assetIndexPath(), idx);
}

export function getAsset(id: string): StudioAsset | null {
  return readAssetIndex().assets.find((a) => a.id === id) ?? null;
}

export function addAssets(newAssets: StudioAsset[]): StudioAssetIndex {
  const idx = readAssetIndex();
  idx.assets = [...newAssets, ...idx.assets];
  saveAssetIndex(idx);
  return idx;
}

export function updateAsset(
  id: string,
  patch: Partial<Pick<StudioAsset, "tags" | "kind">>,
): StudioAsset | null {
  const idx = readAssetIndex();
  const a = idx.assets.find((x) => x.id === id);
  if (!a) return null;
  if (patch.tags) a.tags = patch.tags.slice(0, 24);
  if (patch.kind) a.kind = patch.kind;
  saveAssetIndex(idx);
  return a;
}

export function deleteAsset(id: string): boolean {
  const idx = readAssetIndex();
  const a = idx.assets.find((x) => x.id === id);
  if (!a) return false;
  idx.assets = idx.assets.filter((x) => x.id !== id);
  saveAssetIndex(idx);
  try {
    const fp = safeJoin(assetFilesDir(), a.fileName);
    if (existsSync(fp)) rmSync(fp, { force: true });
  } catch {
    // best-effort file cleanup
  }
  return true;
}

export function assetFilePath(fileName: string): string {
  return safeJoin(assetFilesDir(), fileName);
}

// =============================================================================
// Renders store
// =============================================================================

export function rendersDir(): string {
  const d = path.join(studioDir(), "renders");
  ensureDir(d);
  return d;
}

export function renderFilesDir(): string {
  const d = path.join(rendersDir(), "files");
  ensureDir(d);
  return d;
}

function renderIndexPath(): string {
  return path.join(rendersDir(), "index.json");
}

export function readRenderIndex(): StudioRenderIndex {
  try {
    const p = renderIndexPath();
    if (!existsSync(p)) return { renders: [], updatedAt: 0 };
    return JSON.parse(readFileSync(p, "utf-8"));
  } catch {
    return { renders: [], updatedAt: 0 };
  }
}

export function saveRenderIndex(idx: StudioRenderIndex): void {
  idx.updatedAt = Date.now();
  writeJsonAtomic(renderIndexPath(), idx);
}

export function renderFilePath(fileName: string): string {
  return safeJoin(renderFilesDir(), fileName);
}

/** Replace any existing render for a (feed,row,variant,format) then add new. */
export function upsertRender(r: StudioRender, bytes: Buffer): StudioRender {
  const idx = readRenderIndex();
  const prior = idx.renders.filter(
    (x) =>
      x.feedId === r.feedId &&
      x.rowId === r.rowId &&
      x.variantId === r.variantId &&
      x.format === r.format,
  );
  for (const p of prior) {
    try {
      const fp = safeJoin(renderFilesDir(), p.fileName);
      if (existsSync(fp)) rmSync(fp, { force: true });
    } catch {
      // ignore
    }
  }
  idx.renders = idx.renders.filter(
    (x) =>
      !(
        x.feedId === r.feedId &&
        x.rowId === r.rowId &&
        x.variantId === r.variantId &&
        x.format === r.format
      ),
  );
  writeFileSync(safeJoin(renderFilesDir(), r.fileName), bytes);
  idx.renders = [r, ...idx.renders];
  saveRenderIndex(idx);
  return r;
}

// =============================================================================
// Reviews store — per-feed approval state (row/variant statuses + pack +
// QA summary + distribution handoffs). One JSON per feed under .studio/reviews/.
// =============================================================================

export type StudioReviewStatus = "pending" | "approved" | "changes_requested";

export interface StudioReviewEntry {
  rowId: string;
  variantId: string;
  status: StudioReviewStatus;
  note?: string;
  updatedAt: number;
}

export interface StudioQaSummary {
  ranAt: number;
  totalFindings: number;
  bySeverity: Record<string, number>;
  skillCallIds?: string[];
}

export interface StudioHandoffRecord {
  id: string;
  destination: string;
  status: string;
  renderCount: number;
  skillCallId?: string;
  summary?: string;
  createdAt: number;
}

export interface StudioReview {
  feedId: string;
  packStatus: StudioReviewStatus;
  entries: StudioReviewEntry[];
  qaSummary?: StudioQaSummary;
  handoffs: StudioHandoffRecord[];
  updatedAt: number;
}

function reviewsDir(): string {
  const d = path.join(studioDir(), "reviews");
  ensureDir(d);
  return d;
}

export function newHandoffId(): string {
  return `ho_${Date.now()}_${randomUUID().replace(/-/g, "").slice(0, 8)}`;
}

export function emptyReview(feedId: string): StudioReview {
  return {
    feedId,
    packStatus: "pending",
    entries: [],
    handoffs: [],
    updatedAt: Date.now(),
  };
}

export function getReview(feedId: string): StudioReview | null {
  try {
    const p = safeJoin(reviewsDir(), `${safeId("feed", feedId)}.json`);
    if (!existsSync(p)) return null;
    return JSON.parse(readFileSync(p, "utf-8"));
  } catch {
    return null;
  }
}

export function listReviews(): StudioReview[] {
  try {
    const dir = reviewsDir();
    const files = readdirSync(dir).filter((f) => f.endsWith(".json"));
    const out: StudioReview[] = [];
    for (const f of files) {
      try {
        out.push(JSON.parse(readFileSync(path.join(dir, f), "utf-8")));
      } catch {
        // skip unreadable/corrupt review files
      }
    }
    return out;
  } catch {
    return [];
  }
}

export function saveReview(r: StudioReview): void {
  const p = safeJoin(reviewsDir(), `${safeId("feed", r.feedId)}.json`);
  r.updatedAt = Date.now();
  writeJsonAtomic(p, r);
}

export function deleteReview(feedId: string): boolean {
  try {
    const p = safeJoin(reviewsDir(), `${safeId("feed", feedId)}.json`);
    if (!existsSync(p)) return false;
    rmSync(p, { force: true });
    return true;
  } catch {
    return false;
  }
}

// =============================================================================
// Seed — the AWS CX Banner Master template + sample feed, on first boot.
// =============================================================================

const STANDARD_DIMENSIONS: {
  name: string;
  type: "static" | "dynamic";
  width: number;
  height: number;
}[] = [
  { name: "Skyscraper", type: "static", width: 160, height: 600 },
  { name: "Halfpage", type: "static", width: 300, height: 600 },
  { name: "Leaderboard", type: "static", width: 728, height: 90 },
  { name: "Medium Rectangle", type: "static", width: 300, height: 250 },
  { name: "Mobile Leaderboard", type: "static", width: 320, height: 50 },
  { name: "Animated", type: "dynamic", width: 1200, height: 626 },
];

function defaultSchema(): StudioSchemaField[] {
  return [
    {
      id: "account_or_cluster",
      label: "Account or cluster",
      type: "rich_text",
      description: "The ABM account name or cluster label woven into copy.",
      defaultValue: "your team",
    },
    {
      id: "headline",
      label: "Headline",
      type: "rich_text",
      description: "Primary creative headline. Supports %account_or_cluster%.",
      defaultValue: "Accelerate %account_or_cluster% with AWS",
    },
    {
      id: "cta_label",
      label: "CTA label",
      type: "rich_text",
      description: "Call-to-action button text.",
      defaultValue: "Learn more",
    },
    {
      id: "logo",
      label: "Logo",
      type: "media",
      description: "Brand or partner logo (transparent PNG/SVG preferred).",
      allowedFormats: ["png", "svg", "webp"],
      maxSizeMB: 4,
    },
    {
      id: "teaser_image",
      label: "Teaser image",
      type: "media",
      description: "Hero / teaser image filling the creative.",
      allowedFormats: ["jpg", "png", "webp"],
      maxSizeMB: 8,
    },
  ];
}

export function makeTemplate(
  name: string,
  brand: string | undefined,
  dimensions = STANDARD_DIMENSIONS,
): StudioTemplate {
  const now = Date.now();
  const variants: StudioVariant[] = dimensions.map((d) => ({
    id: newVariantId(),
    name: d.name,
    type: d.type,
    width: d.width,
    height: d.height,
    scene: buildDefaultScene(d.width, d.height),
  }));
  const formatsByVariant: Record<string, string[]> = {};
  for (const v of variants) {
    formatsByVariant[v.id] = v.type === "static" ? ["png", "jpg"] : ["png"];
  }
  return {
    id: newTemplateId(),
    name,
    brand,
    schemaFields: defaultSchema(),
    variants,
    output: { formatsByVariant },
    createdAt: now,
    updatedAt: now,
  };
}

const MASTER_TEMPLATE_NAME = "AWS CX Banner Master";

/**
 * Repurposed-format dimensions layered on top of STANDARD_DIMENSIONS so a single
 * creative can be produced as paid-social, billboard, social, email, etc.
 */
const REPURPOSED_DIMENSIONS: typeof STANDARD_DIMENSIONS = [
  { name: "Social Square", type: "static", width: 1080, height: 1080 },
  { name: "Social Portrait", type: "static", width: 1080, height: 1350 },
  { name: "Social Story", type: "static", width: 1080, height: 1920 },
  { name: "Paid Social", type: "static", width: 1200, height: 628 },
  { name: "Billboard", type: "static", width: 970, height: 250 },
  { name: "Large Rectangle", type: "static", width: 336, height: 280 },
  { name: "Email Header", type: "static", width: 600, height: 200 },
  { name: "Half Banner", type: "static", width: 234, height: 60 },
];

const ALL_DIMENSIONS: typeof STANDARD_DIMENSIONS = [
  ...STANDARD_DIMENSIONS,
  ...REPURPOSED_DIMENSIONS,
];

const SEED_TAG_PREFIX = "seed:t124:";
// Source art ranges up to ~9000px / 40MB. Downscale on ingest so the library
// and the multi-stage Konva editor stay light (and files fit the upload cap).
const SEED_MAX_EDGE = 2048;
const SEED_EXT = new Set(["png", "jpg", "jpeg", "webp", "svg", "gif"]);
const SEED_MIME: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
  svg: "image/svg+xml",
  gif: "image/gif",
};

interface SeedAssetSpec {
  key: string;
  src: string;
  name: string;
  tags: string[];
}

/** Curated, hardcoded allowlist of real shared assets shipped in attached_assets. */
const SEED_ASSETS: SeedAssetSpec[] = [
  // Brand / partner logos — tagged with brand slug + industry for tag search.
  { key: "logo-thomsonreuters", src: "tr-pri-logo-rgb-color_1781979555108.png", name: "Thomson Reuters logo", tags: ["logo", "brand", "thomson-reuters", "media"] },
  { key: "logo-natwest", src: "NatWest_id0-btG5fe_1_1781979555111.png", name: "NatWest logo", tags: ["logo", "brand", "natwest", "financial-services"] },
  { key: "logo-nasdaq", src: "Nasdaq_idx2-KjaR2_1_1781979555111.png", name: "Nasdaq logo", tags: ["logo", "brand", "nasdaq", "financial-services"] },
  { key: "logo-bbva", src: "bbva-seeklogo_1781979555111.png", name: "BBVA logo", tags: ["logo", "brand", "bbva", "financial-services"] },
  { key: "logo-toyota", src: "toyota-seeklogo_1781979555111.png", name: "Toyota logo", tags: ["logo", "brand", "toyota", "automotive"] },
  // AWS photo-library textures — sharp (hero / teaser backgrounds).
  { key: "tex-649", src: "AWS_PhotoLibrary_Texture-649_1781979374469.jpg", name: "AWS Texture 649", tags: ["aws", "texture", "sharp", "background"] },
  { key: "tex-747", src: "AWS_PhotoLibrary_Texture-747_1781979374469.jpg", name: "AWS Texture 747", tags: ["aws", "texture", "sharp", "background"] },
  { key: "tex-crop-233", src: "AWS_PhotoLibrary_Texture-Crops-233_1781979374468.jpg", name: "AWS Texture Crop 233", tags: ["aws", "texture", "sharp", "background"] },
  { key: "tex-crop-257", src: "AWS_PhotoLibrary_Texture-Crops-257_1781979374468.jpg", name: "AWS Texture Crop 257", tags: ["aws", "texture", "sharp", "background"] },
  { key: "tex-crop-269", src: "AWS_PhotoLibrary_Texture-Crops-269_1781979374467.jpg", name: "AWS Texture Crop 269", tags: ["aws", "texture", "sharp", "background"] },
  { key: "tex-crop-27", src: "AWS_PhotoLibrary_Texture-Crops-27_1781979374469.jpg", name: "AWS Texture Crop 27", tags: ["aws", "texture", "sharp", "background"] },
  // Pre-blurred AWS textures (ready-made full-bleed backdrops).
  { key: "blur-649", src: "AWS_PhotoLibrary_Texture-649_BLUR_1781978582245.png", name: "AWS Texture 649 (blurred)", tags: ["aws", "texture", "blur", "background"] },
  { key: "blur-747", src: "AWS_PhotoLibrary_Texture-747_BLUR_1781978582245.png", name: "AWS Texture 747 (blurred)", tags: ["aws", "texture", "blur", "background"] },
  { key: "blur-crop-233", src: "AWS_PhotoLibrary_Texture-Crops-233_BLUR_1781978582244.png", name: "AWS Texture Crop 233 (blurred)", tags: ["aws", "texture", "blur", "background"] },
  // AWS people — corporate / lifestyle.
  { key: "people-290", src: "AWS_PhotoLibrary_People-290_1781979374469.jpg", name: "AWS People 290", tags: ["aws", "people", "corporate", "lifestyle"] },
  { key: "people-310", src: "AWS_PhotoLibrary_People-310_1781979374469.jpg", name: "AWS People 310", tags: ["aws", "people", "corporate", "lifestyle"] },
  // Industry stock (Adobe Stock previews) — tagged by subject; editorial-only flagged.
  { key: "stock-1511873020", src: "AdobeStock_1511873020_Preview_1781978582246.jpeg", name: "Stadium under lights", tags: ["stock", "sports", "events"] },
  { key: "stock-1512193344", src: "AdobeStock_1512193344_Preview_1781978582245.jpeg", name: "Stethoscope on data chart", tags: ["stock", "healthcare"] },
  { key: "stock-365330255", src: "AdobeStock_365330255_Preview_1781978582246.jpeg", name: "Night highway light trails", tags: ["stock", "automotive", "transport"] },
  { key: "stock-430509812", src: "AdobeStock_430509812_Preview_1781978582246.jpeg", name: "Data center server racks", tags: ["stock", "tech", "data-center"] },
  { key: "stock-286300951", src: "AdobeStock_286300951_Preview_Editorial_Use_Only_1781978582246.jpeg", name: "BMW motorcycle badge (editorial use only)", tags: ["stock", "automotive", "editorial-only"] },
  { key: "stock-336282666", src: "AdobeStock_336282666_Preview_Editorial_Use_Only_1781978582246.jpeg", name: "Amazon Go storefront (editorial use only)", tags: ["stock", "retail", "editorial-only"] },
  { key: "stock-482250830", src: "AdobeStock_482250830_Preview_Editorial_Use_Only_1781978582246.jpeg", name: "Sports car in desert (editorial use only)", tags: ["stock", "automotive", "editorial-only"] },
  // Illustration / graphic.
  { key: "journey", src: "Journey_Thick_1781978582244.png", name: "Journey illustration", tags: ["illustration", "journey", "graphic"] },
];

const LOGO_PRESELECT_KEYS = [
  "logo-nasdaq",
  "logo-thomsonreuters",
  "logo-natwest",
  "logo-bbva",
  "logo-toyota",
];

// Non-blur, non-editorial, NON-HUMAN imagery surfaced as teaser-image picker
// suggestions. Creatives default to abstract AWS textures — no human photography.
const TEASER_PRESELECT_KEYS = [
  "tex-649",
  "tex-747",
  "tex-crop-233",
  "tex-crop-257",
  "tex-crop-269",
  "tex-crop-27",
  "stock-1511873020",
  "stock-1512193344",
  "stock-365330255",
  "stock-430509812",
];

const SEED_FEED_NAME = "Q3 ABM Cluster Feed";

// Stable per-row bindings (keyed by row uid) → curated asset keys. Every teaser
// is a NON-editorial asset so produced/paid renders never embed editorial-only
// stock (see the render-persist guard in routes/studio.ts).
const ROW_BINDINGS: Record<string, { logo: string; teaser: string }> = {
  "CX-001": { logo: "logo-nasdaq", teaser: "tex-649" },
  "CX-002": { logo: "logo-thomsonreuters", teaser: "stock-365330255" },
  "CX-003": { logo: "logo-bbva", teaser: "tex-747" },
  // Brand-specific sample creatives, each paired with an industry-appropriate
  // image (FSI → finance texture, automotive → night-highway, etc.).
  "CX-004": { logo: "logo-natwest", teaser: "tex-crop-233" },
  "CX-005": { logo: "logo-bbva", teaser: "tex-crop-257" },
  "CX-006": { logo: "logo-nasdaq", teaser: "stock-430509812" },
  "CX-007": { logo: "logo-toyota", teaser: "stock-365330255" },
  "CX-008": { logo: "logo-thomsonreuters", teaser: "tex-crop-269" },
};

interface SeedRowDef {
  uid: string;
  locale: string;
  tags: string[];
  values: Record<string, string>;
}

// Canonical seed feed rows. The first three are the original synthetic clusters;
// CX-004..008 are brand-specific sample creatives. Used both to build a fresh
// feed and to additively backfill missing rows on an existing repl.
const SEED_ROWS: SeedRowDef[] = [
  {
    uid: "CX-001",
    locale: "en-US",
    tags: ["financial-services", "priority"],
    values: {
      account_or_cluster: "BigBank",
      headline: "Accelerate %account_or_cluster% with AWS",
      cta_label: "Book a briefing",
    },
  },
  {
    uid: "CX-002",
    locale: "en-US",
    tags: ["retail"],
    values: {
      account_or_cluster: "Northwind Retail",
      headline: "Reinvent %account_or_cluster% customer journeys",
      cta_label: "See how",
    },
  },
  {
    uid: "CX-003",
    locale: "fr-FR",
    tags: ["energy"],
    values: {
      account_or_cluster: "Voltaic Energy",
      headline: "Modernisez %account_or_cluster% sur AWS",
      cta_label: "En savoir plus",
    },
  },
  {
    uid: "CX-004",
    locale: "en-GB",
    tags: ["financial-services", "brand"],
    values: {
      account_or_cluster: "NatWest",
      headline: "Bank smarter, %account_or_cluster%, on AWS",
      cta_label: "Explore the platform",
    },
  },
  {
    uid: "CX-005",
    locale: "es-ES",
    tags: ["financial-services", "brand"],
    values: {
      account_or_cluster: "BBVA",
      headline: "Impulsa %account_or_cluster% con la nube de AWS",
      cta_label: "Descubre cómo",
    },
  },
  {
    uid: "CX-006",
    locale: "en-US",
    tags: ["financial-services", "brand"],
    values: {
      account_or_cluster: "Nasdaq",
      headline: "Power %account_or_cluster% markets on AWS",
      cta_label: "Read the story",
    },
  },
  {
    uid: "CX-007",
    locale: "en-US",
    tags: ["automotive", "brand"],
    values: {
      account_or_cluster: "Toyota",
      headline: "Drive %account_or_cluster% innovation with AWS",
      cta_label: "See the journey",
    },
  },
  {
    uid: "CX-008",
    locale: "en-US",
    tags: ["media", "brand"],
    values: {
      account_or_cluster: "Thomson Reuters",
      headline: "Deliver trusted answers at %account_or_cluster% scale",
      cta_label: "Learn more",
    },
  },
];

// -----------------------------------------------------------------------------
// Northern European banking feed (additive). Anchored on the real NatWest logo
// plus existing non-editorial AWS imagery already in the library — no fabricated
// Nordic bank logos. Structured so real Nordic logos can be dropped in later by
// editing the bindings once uploaded. Seeded idempotently by feed name.
// -----------------------------------------------------------------------------
const NE_FEED_NAME = "Northern European Banking Feed";

const NE_ROW_BINDINGS: Record<string, { logo: string; teaser: string }> = {
  "NEB-001": { logo: "logo-natwest", teaser: "tex-crop-233" },
  "NEB-002": { logo: "logo-natwest", teaser: "stock-430509812" },
  "NEB-003": { logo: "logo-natwest", teaser: "tex-crop-269" },
  "NEB-004": { logo: "logo-natwest", teaser: "tex-747" },
  "NEB-005": { logo: "logo-natwest", teaser: "tex-crop-257" },
};

const NE_ROWS: SeedRowDef[] = [
  {
    uid: "NEB-001",
    locale: "en-GB",
    tags: ["financial-services", "brand", "northern-europe"],
    values: {
      account_or_cluster: "NatWest",
      headline: "Bank smarter, %account_or_cluster%, on AWS",
      cta_label: "Explore the platform",
    },
  },
  {
    uid: "NEB-002",
    locale: "en-GB",
    tags: ["financial-services", "brand", "northern-europe"],
    values: {
      account_or_cluster: "NatWest",
      headline: "Resilient cloud banking for %account_or_cluster%",
      cta_label: "See the architecture",
    },
  },
  {
    uid: "NEB-003",
    locale: "en-GB",
    tags: ["financial-services", "brand", "northern-europe"],
    values: {
      account_or_cluster: "NatWest",
      headline: "Reimagine %account_or_cluster% customer journeys on AWS",
      cta_label: "Read the story",
    },
  },
  {
    uid: "NEB-004",
    locale: "en-IE",
    tags: ["financial-services", "brand", "northern-europe"],
    values: {
      account_or_cluster: "NatWest",
      headline: "Secure, compliant banking for %account_or_cluster%",
      cta_label: "Talk to us",
    },
  },
  {
    uid: "NEB-005",
    locale: "en-GB",
    tags: ["financial-services", "brand", "northern-europe"],
    values: {
      account_or_cluster: "NatWest",
      headline: "Scale %account_or_cluster% payments with AWS",
      cta_label: "Get the brief",
    },
  },
];

function attachedAssetsDir(): string {
  return path.join(WORKSPACE_ROOT, "attached_assets");
}

function extOf(name: string): string {
  const dot = name.lastIndexOf(".");
  return dot >= 0 ? name.slice(dot + 1).toLowerCase() : "";
}

function mergeUnique(
  existing: string[] | undefined,
  add: string[],
): { value: string[]; changed: boolean } {
  const out = [...(existing ?? [])];
  let changed = false;
  for (const id of add) {
    if (id && !out.includes(id)) {
      out.push(id);
      changed = true;
    }
  }
  return { value: out.slice(0, 24), changed };
}

/**
 * Ingest the curated real assets into the studio library. Idempotent: each asset
 * is keyed by a stable `seed:t124:<key>` tag and skipped if already present, so
 * this can run on every boot without producing duplicates. Returns a
 * key→assetId map used to bind templates/feeds.
 */
async function ensureStudioAssetsSeed(): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  const idx = readAssetIndex();
  // Reuse any previously-seeded assets — but only if the backing file is still
  // on disk. If a seeded file was deleted, skip the stale index entry so the
  // asset is re-ingested below and we never bind templates/feeds to a dead file.
  for (const a of idx.assets) {
    if (!a.tags.some((t) => t.startsWith(SEED_TAG_PREFIX))) continue;
    if (!existsSync(assetFilePath(a.fileName))) continue;
    for (const t of a.tags) {
      if (t.startsWith(SEED_TAG_PREFIX)) {
        map.set(t.slice(SEED_TAG_PREFIX.length), a.id);
      }
    }
  }

  const dir = attachedAssetsDir();
  const created: StudioAsset[] = [];
  for (const spec of SEED_ASSETS) {
    if (map.has(spec.key)) continue; // already seeded
    const ext = extOf(spec.src);
    if (!SEED_EXT.has(ext)) continue; // extension allowlist
    const srcPath = path.join(dir, spec.src);
    if (!existsSync(srcPath)) continue; // source missing — skip silently
    let buf: Buffer;
    try {
      buf = readFileSync(srcPath);
    } catch {
      continue;
    }
    const safeExt = ext === "jpeg" ? "jpg" : ext;
    const id = newAssetId();
    const fileName = `${id}.${safeExt}`;
    let outBuf = buf;
    let width: number | undefined;
    let height: number | undefined;
    const isRaster =
      safeExt === "jpg" || safeExt === "png" || safeExt === "webp";
    if (isRaster) {
      try {
        const sharp = (await import("sharp")).default;
        let pipeline = sharp(buf).rotate().resize({
          width: SEED_MAX_EDGE,
          height: SEED_MAX_EDGE,
          fit: "inside",
          withoutEnlargement: true,
        });
        if (safeExt === "jpg") {
          pipeline = pipeline.jpeg({ quality: 82, mozjpeg: true });
        } else if (safeExt === "png") {
          // No palette: the blurred photographic textures would band badly.
          pipeline = pipeline.png({ compressionLevel: 9 });
        } else {
          pipeline = pipeline.webp({ quality: 82 });
        }
        outBuf = await pipeline.toBuffer();
        const meta = await sharp(outBuf).metadata();
        width = meta.width;
        height = meta.height;
      } catch {
        // Optimisation is best-effort — fall back to the raw bytes + metadata.
        outBuf = buf;
        try {
          const sharp = (await import("sharp")).default;
          const meta = await sharp(buf).metadata();
          width = meta.width;
          height = meta.height;
        } catch {
          // metadata unavailable; asset still usable without it
        }
      }
    } else if (safeExt !== "svg") {
      try {
        const sharp = (await import("sharp")).default;
        const meta = await sharp(buf).metadata();
        width = meta.width;
        height = meta.height;
      } catch {
        // metadata is best-effort; asset is still usable without it
      }
    }
    try {
      writeFileSync(assetFilePath(fileName), outBuf);
    } catch {
      continue;
    }
    const asset: StudioAsset = {
      id,
      kind: "image",
      originalName: spec.name,
      fileName,
      mime: SEED_MIME[safeExt] ?? "application/octet-stream",
      ext: safeExt,
      width,
      height,
      bytes: outBuf.length,
      tags: [...spec.tags, `${SEED_TAG_PREFIX}${spec.key}`],
      createdAt: Date.now(),
    };
    created.push(asset);
    map.set(spec.key, id);
  }
  if (created.length > 0) addAssets(created);
  return map;
}

function resolveIds(map: Map<string, string>, keys: string[]): string[] {
  const out: string[] = [];
  for (const k of keys) {
    const id = map.get(k);
    if (id) out.push(id);
  }
  return out;
}

/** Fill in media-field preselect suggestions (additive, never reorders). */
function applyPreselected(
  template: StudioTemplate,
  map: Map<string, string>,
): boolean {
  let changed = false;
  for (const f of template.schemaFields) {
    if (f.type !== "media") continue;
    if (f.id === "logo") {
      const merged = mergeUnique(
        f.preselectedAssetIds,
        resolveIds(map, LOGO_PRESELECT_KEYS),
      );
      if (merged.changed) {
        f.preselectedAssetIds = merged.value;
        changed = true;
      }
    } else if (f.id === "teaser_image") {
      const merged = mergeUnique(
        f.preselectedAssetIds,
        resolveIds(map, TEASER_PRESELECT_KEYS),
      );
      if (merged.changed) {
        f.preselectedAssetIds = merged.value;
        changed = true;
      }
    }
  }
  return changed;
}

/**
 * Bind a default asset onto each scene image layer (fill-empty-only) so the
 * template editor canvas renders real imagery even before any feed row exists.
 * Logo layers get a brand logo; image + blur layers (both bound to the teaser
 * field) get the same teaser asset, so the blur filter operates on the same
 * image the feed creatives use.
 */
function applyDefaultLayerAssets(
  template: StudioTemplate,
  map: Map<string, string>,
): boolean {
  const logoId = resolveIds(map, LOGO_PRESELECT_KEYS)[0];
  const teaserId = resolveIds(map, TEASER_PRESELECT_KEYS)[0];
  let changed = false;
  for (const variant of template.variants) {
    for (const layer of variant.scene.layers) {
      if (layer.type !== "image") continue;
      // Only repair the seed's own bound media layers — never populate a custom
      // image layer the user intentionally left blank.
      if (layer.fieldId !== "logo" && layer.fieldId !== "teaser_image") continue;
      if (layer.assetId) continue; // never override an existing default/user pick
      const pick = layer.fieldId === "logo" ? logoId : teaserId;
      if (pick) {
        layer.assetId = pick;
        changed = true;
      }
    }
  }
  return changed;
}

/** Add any repurposed-format variants the template is missing (by name). */
function addMissingVariants(template: StudioTemplate): boolean {
  const existing = new Set(template.variants.map((v) => v.name));
  let changed = false;
  for (const d of REPURPOSED_DIMENSIONS) {
    if (existing.has(d.name)) continue;
    const variant: StudioVariant = {
      id: newVariantId(),
      name: d.name,
      type: d.type,
      width: d.width,
      height: d.height,
      scene: buildDefaultScene(d.width, d.height),
    };
    template.variants.push(variant);
    template.output.formatsByVariant[variant.id] =
      variant.type === "static" ? ["png", "jpg"] : ["png"];
    changed = true;
  }
  return changed;
}

/** Materialize a seed row, binding its real logo + teaser asset ids via `bindings`. */
function makeRow(
  def: SeedRowDef,
  bindings: Record<string, { logo: string; teaser: string }>,
  map: Map<string, string>,
): StudioCreativeRow {
  const values: Record<string, string> = { ...def.values };
  const binding = bindings[def.uid];
  if (binding) {
    const logoId = map.get(binding.logo);
    const teaserId = map.get(binding.teaser);
    if (logoId) values.logo = logoId;
    if (teaserId) values.teaser_image = teaserId;
  }
  return {
    id: newRowId(),
    uid: def.uid,
    locale: def.locale,
    tags: [...def.tags],
    values,
  };
}

/** Materialize a canonical seed-feed row (uses the master ROW_BINDINGS). */
function makeSeedRow(def: SeedRowDef, map: Map<string, string>): StudioCreativeRow {
  return makeRow(def, ROW_BINDINGS, map);
}

function bindFeedRows(templateId: string, map: Map<string, string>): void {
  for (const feed of listFeeds(templateId)) {
    let changed = false;
    for (const row of feed.rows) {
      const binding = ROW_BINDINGS[row.uid];
      if (!binding) continue;
      if (!row.values.logo) {
        const id = map.get(binding.logo);
        if (id) {
          row.values.logo = id;
          changed = true;
        }
      }
      if (!row.values.teaser_image) {
        const id = map.get(binding.teaser);
        if (id) {
          row.values.teaser_image = id;
          changed = true;
        }
      }
    }
    if (changed) saveFeed(feed);
  }
}

/**
 * Additively backfill brand sample rows that are missing from the seed feed of
 * an existing repl. Scoped to the seed feed by name so user-created feeds are
 * never touched; idempotent (skips rows already present by uid).
 */
function addMissingFeedRows(templateId: string, map: Map<string, string>): void {
  for (const feed of listFeeds(templateId)) {
    if (feed.name !== SEED_FEED_NAME) continue;
    const present = new Set(feed.rows.map((r) => r.uid));
    let changed = false;
    for (const def of SEED_ROWS) {
      if (present.has(def.uid)) continue;
      feed.rows.push(makeSeedRow(def, map));
      changed = true;
    }
    if (changed) {
      feed.updatedAt = Date.now();
      saveFeed(feed);
    }
  }
}

/**
 * Ensure a named auxiliary feed exists for `templateId` and is bound to real
 * media. Idempotent by feed name: creates it once, then additively backfills any
 * missing rows and fills only EMPTY logo/teaser_image bindings. Never touches
 * user-created feeds (matched strictly by name).
 */
function ensureNamedFeed(
  templateId: string,
  name: string,
  rows: SeedRowDef[],
  bindings: Record<string, { logo: string; teaser: string }>,
  map: Map<string, string>,
): void {
  const existing = listFeeds(templateId).find((f) => f.name === name);
  if (!existing) {
    const now = Date.now();
    saveFeed({
      id: newFeedId(),
      templateId,
      name,
      rows: rows.map((def) => makeRow(def, bindings, map)),
      createdAt: now,
      updatedAt: now,
    });
    return;
  }
  const present = new Set(existing.rows.map((r) => r.uid));
  let changed = false;
  for (const def of rows) {
    if (present.has(def.uid)) continue;
    existing.rows.push(makeRow(def, bindings, map));
    changed = true;
  }
  for (const row of existing.rows) {
    const binding = bindings[row.uid];
    if (!binding) continue;
    if (!row.values.logo) {
      const id = map.get(binding.logo);
      if (id) {
        row.values.logo = id;
        changed = true;
      }
    }
    if (!row.values.teaser_image) {
      const id = map.get(binding.teaser);
      if (id) {
        row.values.teaser_image = id;
        changed = true;
      }
    }
  }
  if (changed) {
    existing.updatedAt = Date.now();
    saveFeed(existing);
  }
}

function buildSeedFeed(
  templateId: string,
  map: Map<string, string>,
): StudioFeed {
  const now = Date.now();
  return {
    id: newFeedId(),
    templateId,
    name: SEED_FEED_NAME,
    rows: SEED_ROWS.map((def) => makeSeedRow(def, map)),
    createdAt: now,
    updatedAt: now,
  };
}

/**
 * Additively merge any missing curated tags onto already-ingested seed assets.
 * Earlier seeds may have indexed an asset with a thinner tag set; this brings
 * existing repls up to the current taxonomy (industry/sharp/corporate/subject)
 * without re-ingesting or clobbering user-added tags. Idempotent.
 */
function upgradeSeedAssetTags(map: Map<string, string>): void {
  const specByKey = new Map(SEED_ASSETS.map((s) => [s.key, s]));
  for (const [key, id] of map) {
    const spec = specByKey.get(key);
    if (!spec) continue;
    const asset = getAsset(id);
    if (!asset) continue;
    const merged = [...asset.tags];
    let changed = false;
    for (const t of spec.tags) {
      if (!merged.includes(t)) {
        merged.push(t);
        changed = true;
      }
    }
    if (changed) updateAsset(id, { tags: merged });
  }
}

/** Amazon Orange — reserved for the AWS Smile logo, never a CTA/accent fill. */
const ORANGE_HEX = "#FF9900";

/**
 * One-time, idempotent migration: re-point any rectangle layer whose fill is
 * still baked-in Amazon orange (`#FF9900`) to the brand-safe CTA blue. Older
 * seeds painted the CTA button orange; this corrects already-persisted
 * templates so the surface the user is looking at actually changes. Only fills
 * that are EXACTLY orange are touched, so a user's intentionally customized
 * (non-orange) fill is never clobbered. No-op once every fill is blue.
 */
function migrateCtaOrangeFills(): void {
  const blue = ctaFill();
  if (blue.toUpperCase() === ORANGE_HEX) return; // never write orange
  for (const template of listTemplates()) {
    let changed = false;
    for (const variant of template.variants) {
      for (const layer of variant.scene.layers) {
        if (layer.type !== "rect") continue;
        if (
          typeof layer.fill === "string" &&
          layer.fill.toUpperCase() === ORANGE_HEX
        ) {
          layer.fill = blue;
          changed = true;
        }
      }
    }
    if (changed) saveTemplate(template);
  }
}

// -----------------------------------------------------------------------------
// Ingested brand-asset catalog → Creative Studio Asset Library bridge.
// The studio library historically only carried the curated SEED_ASSETS subset.
// This bridges the FULL ingested catalog (artifacts/agent-os/public/brand-assets
// /manifest.json — every AWS flat illustration, photo, AWS + customer logo) into
// the studio image pool so all shared assets are searchable + usable in
// templates/feeds. Additive and idempotent; never touches the curated seed
// assets or existing bindings, and not subject to the 24-item preselect cap.
// -----------------------------------------------------------------------------
const CATALOG_TAG_PREFIX = "catalog:";
const CATALOG_IMAGE_CATEGORIES = new Set([
  "illustrations",
  "photos",
  "logos",
  "customers",
]);

interface ManifestAsset {
  id: string;
  category: string;
  name: string;
  owner: string;
  url: string;
  thumbnailUrl?: string;
  format: string;
  width?: number;
  height?: number;
  bytes: number;
  tags: string[];
}

function agentOsPublicDir(): string {
  return path.join(WORKSPACE_ROOT, "artifacts", "agent-os", "public");
}

function readBrandManifest(): ManifestAsset[] {
  try {
    const p = path.join(agentOsPublicDir(), "brand-assets", "manifest.json");
    if (!existsSync(p)) return [];
    const data = JSON.parse(readFileSync(p, "utf-8"));
    return Array.isArray(data) ? (data as ManifestAsset[]) : [];
  } catch {
    return [];
  }
}

function ensureCatalogAssetsBridge(): void {
  const manifest = readBrandManifest();
  if (manifest.length === 0) return;
  const idx = readAssetIndex();
  // Already-bridged manifest ids (only count an entry if its file is on disk so
  // a deleted file is re-bridged rather than left dangling).
  const bridged = new Set<string>();
  for (const a of idx.assets) {
    if (!existsSync(assetFilePath(a.fileName))) continue;
    for (const t of a.tags) {
      if (t.startsWith(CATALOG_TAG_PREFIX)) {
        bridged.add(t.slice(CATALOG_TAG_PREFIX.length));
      }
    }
  }
  const created: StudioAsset[] = [];
  for (const m of manifest) {
    if (!CATALOG_IMAGE_CATEGORIES.has(m.category)) continue; // skip fonts
    if (bridged.has(m.id)) continue;
    const ext = m.format.toLowerCase() === "jpeg" ? "jpg" : m.format.toLowerCase();
    if (!SEED_EXT.has(ext)) continue;
    const srcPath = path.join(agentOsPublicDir(), m.url);
    if (!existsSync(srcPath)) continue;
    let buf: Buffer;
    try {
      buf = readFileSync(srcPath);
    } catch {
      continue;
    }
    const id = newAssetId();
    const fileName = `${id}.${ext}`;
    try {
      writeFileSync(assetFilePath(fileName), buf);
    } catch {
      continue;
    }
    const tags = Array.from(
      new Set([
        `${CATALOG_TAG_PREFIX}${m.id}`,
        m.category,
        ...m.tags.map((t) => t.toLowerCase()),
      ]),
    ).slice(0, 24);
    created.push({
      id,
      kind: "image",
      originalName: m.name,
      fileName,
      mime: SEED_MIME[ext] ?? "application/octet-stream",
      ext,
      width: m.width,
      height: m.height,
      bytes: buf.length,
      tags,
      createdAt: Date.now(),
    });
  }
  if (created.length > 0) addAssets(created);
}

// =============================================================================
// Northern European Banking GTM template library (additive, idempotent).
// A campaign-branded counterpart to the AWS CX Banner Master: three styles
// (navy hero, texture hero, proof bar) across the full dimension set, rendered
// in the NEU palette + Amazon Ember type, with a bound NEU creative feed.
// =============================================================================

const NEU_BRAND = "Accenture Song × AWS · Northern European Banking";

interface NeuTemplateSpec {
  name: string;
  style: NeuStyle;
}

const NEU_TEMPLATES: NeuTemplateSpec[] = [
  { name: "Northern European Banking — Navy Hero", style: "navy-hero" },
  { name: "Northern European Banking — Texture Hero", style: "texture-hero" },
  { name: "Northern European Banking — Proof Bar", style: "proof" },
];

// Per-style default copy mined from the GenAI-on-Bedrock tailored asset. These
// fill the schema `defaultValue`s so template thumbnails read as the real
// campaign even before a feed row is attached.
const NEU_STYLE_COPY: Record<
  NeuStyle,
  { eyebrow: string; headline: string; cta: string }
> = {
  "navy-hero": {
    eyebrow: "Generative AI on Amazon Bedrock",
    headline:
      "6 steps to fast-track generative AI from prototype to production for Northern European banks",
    cta: "Read the 6 steps",
  },
  "texture-hero": {
    eyebrow: "Northern European Banking",
    headline: "Move banking AI from prototype to production",
    cta: "See the playbook",
  },
  proof: {
    eyebrow: "Proven on AWS",
    headline: "Europe’s banks build generative AI on AWS",
    cta: "Explore the proof",
  },
};

function neuSchema(style: NeuStyle): StudioSchemaField[] {
  const c = NEU_STYLE_COPY[style];
  return [
    {
      id: "eyebrow",
      label: "Eyebrow",
      type: "rich_text",
      description:
        "Short mono kicker above the headline (uppercased in render).",
      defaultValue: c.eyebrow,
    },
    {
      id: "account_or_cluster",
      label: "Account or cluster",
      type: "rich_text",
      description: "The ABM account name or cluster label woven into copy.",
      defaultValue: "Northern European banks",
    },
    {
      id: "headline",
      label: "Headline",
      type: "rich_text",
      description: "Primary creative headline. Supports %account_or_cluster%.",
      defaultValue: c.headline,
    },
    {
      id: "cta_label",
      label: "CTA label",
      type: "rich_text",
      description: "Call-to-action button text.",
      defaultValue: c.cta,
    },
    {
      id: "logo",
      label: "Logo",
      type: "media",
      description: "Brand or partner logo (transparent PNG/SVG preferred).",
      allowedFormats: ["png", "svg", "webp"],
      maxSizeMB: 4,
    },
    {
      id: "teaser_image",
      label: "Teaser image",
      type: "media",
      description: "Hero / teaser image — AWS texture or banking lifestyle.",
      allowedFormats: ["jpg", "png", "webp"],
      maxSizeMB: 8,
    },
  ];
}

function makeNeuTemplate(name: string, style: NeuStyle): StudioTemplate {
  const now = Date.now();
  const variants: StudioVariant[] = ALL_DIMENSIONS.map((d) => ({
    id: newVariantId(),
    name: d.name,
    type: d.type,
    width: d.width,
    height: d.height,
    scene: buildNeuScene(d.width, d.height, style),
  }));
  const formatsByVariant: Record<string, string[]> = {};
  for (const v of variants) {
    formatsByVariant[v.id] = v.type === "static" ? ["png", "jpg"] : ["png"];
  }
  return {
    id: newTemplateId(),
    name,
    brand: NEU_BRAND,
    schemaFields: neuSchema(style),
    variants,
    output: { formatsByVariant },
    createdAt: now,
    updatedAt: now,
  };
}

// FSI-scoped preselect ordering. This is a 1:Few program, so the social tiles
// carry the AWS master mark (white, on the navy hero) rather than per-account
// logos — cleaner, and no account logo is expected at this tier. AWS
// texture-crop-269 (the tailored hero creative) still leads the teaser pool,
// which is all abstract AWS texture — no human photography (AdTune doctrine).
const NEU_LOGO_PRESELECT_KEYS = ["logo-aws-white"];
const NEU_TEASER_PRESELECT_KEYS = [
  "tex-crop-269",
  "tex-crop-233",
  "tex-crop-257",
  "tex-649",
  "tex-747",
];

/**
 * Preselect NEU media + bind default layer assets so the editor canvas renders
 * real campaign imagery before any feed row exists. Fill-empty-only on layers,
 * so re-running never clobbers a user pick.
 */
function applyNeuDefaults(
  template: StudioTemplate,
  map: Map<string, string>,
): void {
  for (const f of template.schemaFields) {
    if (f.type !== "media") continue;
    if (f.id === "logo") {
      f.preselectedAssetIds = resolveIds(map, NEU_LOGO_PRESELECT_KEYS);
    } else if (f.id === "teaser_image") {
      f.preselectedAssetIds = resolveIds(map, NEU_TEASER_PRESELECT_KEYS);
    }
  }
  const logoId = resolveIds(map, NEU_LOGO_PRESELECT_KEYS)[0];
  const teaserId = resolveIds(map, NEU_TEASER_PRESELECT_KEYS)[0];
  for (const variant of template.variants) {
    for (const layer of variant.scene.layers) {
      if (layer.type !== "image") continue;
      if (layer.fieldId !== "logo" && layer.fieldId !== "teaser_image") continue;
      if (layer.assetId) continue;
      const pick = layer.fieldId === "logo" ? logoId : teaserId;
      if (pick) layer.assetId = pick;
    }
  }
}

// Bound NEU creative feed — the AWS master mark (white) on every tile, paired
// with non-editorial AWS imagery. 1:Few program, so no per-account logos.
// Seeded once against the flagship navy-hero.
const NEU_LIB_FEED_NAME = "NEU GenAI Banner Feed";
const NEU_LIB_BINDINGS: Record<string, { logo: string; teaser: string }> = {
  "NEU-001": { logo: "logo-aws-white", teaser: "tex-crop-269" },
  "NEU-002": { logo: "logo-aws-white", teaser: "tex-crop-233" },
  "NEU-003": { logo: "logo-aws-white", teaser: "tex-747" },
};
const NEU_LIB_ROWS: SeedRowDef[] = [
  {
    uid: "NEU-001",
    locale: "en-GB",
    tags: ["financial-services", "brand", "northern-europe"],
    values: {
      eyebrow: "Generative AI on Amazon Bedrock",
      account_or_cluster: "Northern European banks",
      headline:
        "6 steps to fast-track generative AI from prototype to production for Northern European banks",
      cta_label: "Read the 6 steps",
    },
  },
  {
    uid: "NEU-002",
    locale: "en-GB",
    tags: ["financial-services", "brand", "northern-europe"],
    values: {
      eyebrow: "Northern European Banking",
      account_or_cluster: "BBVA",
      headline: "Move %account_or_cluster% from AI prototype to production",
      cta_label: "See the playbook",
    },
  },
  {
    uid: "NEU-003",
    locale: "en-GB",
    tags: ["financial-services", "brand", "northern-europe"],
    values: {
      eyebrow: "Proven on AWS",
      account_or_cluster: "NatWest",
      headline: "Why %account_or_cluster% builds generative AI on AWS",
      cta_label: "Explore the proof",
    },
  },
];

/**
 * Seed the NEU GTM template library + its bound feed. Idempotent by template
 * and feed name, so it never duplicates on repeat boots and never clobbers a
 * user's edits to an already-seeded NEU template.
 */
function ensureNeuLibrary(map: Map<string, string>): void {
  const existing = new Set(listTemplates().map((t) => t.name));
  for (const spec of NEU_TEMPLATES) {
    if (existing.has(spec.name)) continue;
    const template = makeNeuTemplate(spec.name, spec.style);
    applyNeuDefaults(template, map);
    saveTemplate(template);
  }
  const flagship = listTemplates().find(
    (t) => t.name === NEU_TEMPLATES[0].name,
  );
  if (flagship) {
    ensureNamedFeed(
      flagship.id,
      NEU_LIB_FEED_NAME,
      NEU_LIB_ROWS,
      NEU_LIB_BINDINGS,
      map,
    );
  }
}

// =============================================================================
// Northern European Banking — Blur Hero (additive, idempotent).
// A NEW GTM template with the blurred-background + sharp-foreground-card look,
// restricted to the five IAB ad sizes below (NO Animated variant). Kept OUT of
// NEU_TEMPLATES on purpose so the ramp/blur-backdrop migrations never rewrite
// its blur-hero scenes. Seeded once with its own bound feed.
// =============================================================================

const BLUR_HERO_TEMPLATE_NAME = "Northern European Banking — Blur Hero";

const BLUR_HERO_DIMENSIONS: typeof STANDARD_DIMENSIONS = [
  { name: "Halfpage", type: "static", width: 300, height: 600 },
  { name: "Leaderboard", type: "static", width: 728, height: 90 },
  { name: "Medium Rectangle", type: "static", width: 300, height: 250 },
  { name: "Mobile Leaderboard", type: "static", width: 320, height: 50 },
  { name: "Skyscraper", type: "static", width: 160, height: 600 },
];

const BLUR_HERO_COPY = {
  eyebrow: "Generative AI on Amazon Bedrock",
  headline:
    "Bring generative AI from prototype to production for %account_or_cluster%",
  cta: "See the playbook",
} as const;

function blurHeroSchema(): StudioSchemaField[] {
  const fields = neuSchema("navy-hero");
  for (const f of fields) {
    if (f.id === "eyebrow") f.defaultValue = BLUR_HERO_COPY.eyebrow;
    else if (f.id === "headline") f.defaultValue = BLUR_HERO_COPY.headline;
    else if (f.id === "cta_label") f.defaultValue = BLUR_HERO_COPY.cta;
  }
  return fields;
}

function makeBlurHeroTemplate(): StudioTemplate {
  const now = Date.now();
  const variants: StudioVariant[] = BLUR_HERO_DIMENSIONS.map((d) => ({
    id: newVariantId(),
    name: d.name,
    type: d.type,
    width: d.width,
    height: d.height,
    scene: buildBlurHeroScene(d.width, d.height),
  }));
  const formatsByVariant: Record<string, string[]> = {};
  for (const v of variants) {
    formatsByVariant[v.id] = v.type === "static" ? ["png", "jpg"] : ["png"];
  }
  return {
    id: newTemplateId(),
    name: BLUR_HERO_TEMPLATE_NAME,
    brand: NEU_BRAND,
    schemaFields: blurHeroSchema(),
    variants,
    output: { formatsByVariant },
    createdAt: now,
    updatedAt: now,
  };
}

const BLUR_HERO_FEED_NAME = "NEU Blur Hero Feed";
const BLUR_HERO_BINDINGS: Record<string, { logo: string; teaser: string }> = {
  "NEUBH-001": { logo: "logo-aws-white", teaser: "tex-crop-269" },
  "NEUBH-002": { logo: "logo-aws-white", teaser: "tex-crop-233" },
  "NEUBH-003": { logo: "logo-aws-white", teaser: "tex-747" },
  "NEUBH-004": { logo: "logo-aws-white", teaser: "tex-crop-257" },
};
const BLUR_HERO_ROWS: SeedRowDef[] = [
  {
    uid: "NEUBH-001",
    locale: "en-GB",
    tags: ["financial-services", "brand", "northern-europe", "blur-hero"],
    values: {
      eyebrow: "Generative AI on Amazon Bedrock",
      account_or_cluster: "Northern European banks",
      headline:
        "Bring generative AI from prototype to production for Northern European banks",
      cta_label: "See the 6 steps",
    },
  },
  {
    uid: "NEUBH-002",
    locale: "en-GB",
    tags: ["financial-services", "brand", "northern-europe", "blur-hero"],
    values: {
      eyebrow: "Generative AI on Amazon Bedrock",
      account_or_cluster: "Nordea",
      headline: "Scale generative AI for %account_or_cluster% on AWS",
      cta_label: "See the playbook",
    },
  },
  {
    uid: "NEUBH-003",
    locale: "en-GB",
    tags: ["financial-services", "brand", "northern-europe", "blur-hero"],
    values: {
      eyebrow: "Proven on AWS",
      account_or_cluster: "Danske Bank",
      headline: "Why %account_or_cluster% builds generative AI on AWS",
      cta_label: "Explore the proof",
    },
  },
  {
    uid: "NEUBH-004",
    locale: "en-GB",
    tags: ["financial-services", "brand", "northern-europe", "blur-hero"],
    values: {
      eyebrow: "Generative AI on Amazon Bedrock",
      account_or_cluster: "DNB",
      headline: "Move %account_or_cluster% from AI prototype to production",
      cta_label: "See the playbook",
    },
  },
];

/**
 * Seed the Blur-Hero GTM template + its bound feed. Idempotent by template and
 * feed name. Reuses applyNeuDefaults (generic by fieldId) to preselect the AWS
 * master mark + AWS texture teasers, so the canvas renders real imagery before
 * any feed row is attached.
 */
function ensureBlurHeroLibrary(map: Map<string, string>): void {
  const existing = listTemplates().find(
    (t) => t.name === BLUR_HERO_TEMPLATE_NAME,
  );
  if (!existing) {
    const template = makeBlurHeroTemplate();
    applyNeuDefaults(template, map);
    saveTemplate(template);
  }
  const template = listTemplates().find(
    (t) => t.name === BLUR_HERO_TEMPLATE_NAME,
  );
  if (template) {
    ensureNamedFeed(
      template.id,
      BLUR_HERO_FEED_NAME,
      BLUR_HERO_ROWS,
      BLUR_HERO_BINDINGS,
      map,
    );
  }
}

/**
 * Resolve a catalog-bridged asset id by its source manifest id (the asset is
 * tagged `catalog:<manifestId>` by `ensureCatalogAssetsBridge`). Only returns
 * an id whose backing file is still on disk. Used to reuse the already-ingested
 * AWS master logo rather than seeding a duplicate copy.
 */
function findCatalogAssetId(manifestId: string): string | undefined {
  const tag = `${CATALOG_TAG_PREFIX}${manifestId}`;
  for (const a of readAssetIndex().assets) {
    if (a.tags.includes(tag) && existsSync(assetFilePath(a.fileName))) {
      return a.id;
    }
  }
  return undefined;
}

/**
 * One-time, idempotent migration: repoint the NEU social tiles from per-account
 * logos (NatWest / BBVA / Nasdaq) to the AWS master mark (white). This is a
 * 1:Few program, so an account logo is not expected at this tier and the white
 * AWS mark on the navy hero reads cleaner. Scoped strictly to the NEU template
 * library + its bound "NEU GenAI Banner Feed"; the master/NEB feeds and any
 * user-created feed are never touched. Only swaps assets that are still one of
 * the seeded account logos (or empty), so a deliberate user pick is preserved.
 * No-op once every NEU logo surface already carries the AWS mark.
 */
function migrateNeuLogoToAwsWhite(map: Map<string, string>): void {
  const awsWhiteId = map.get("logo-aws-white");
  if (!awsWhiteId) return; // AWS mark unavailable — leave existing logos as-is
  const accountIds = new Set(
    ["logo-natwest", "logo-bbva", "logo-nasdaq"]
      .map((k) => map.get(k))
      .filter((id): id is string => Boolean(id)),
  );
  const neuNames = new Set(NEU_TEMPLATES.map((t) => t.name));
  for (const template of listTemplates()) {
    if (!neuNames.has(template.name)) continue;
    let changed = false;
    // Suggested-for-this-slot: drop account logos, lead with the AWS mark.
    for (const f of template.schemaFields) {
      if (f.type !== "media" || f.id !== "logo") continue;
      const cur = f.preselectedAssetIds ?? [];
      const next = [
        awsWhiteId,
        ...cur.filter((id) => id !== awsWhiteId && !accountIds.has(id)),
      ];
      if (cur.length !== next.length || cur.some((id, i) => id !== next[i])) {
        f.preselectedAssetIds = next;
        changed = true;
      }
    }
    // Baked default logo layer assets across every dimension.
    for (const variant of template.variants) {
      for (const layer of variant.scene.layers) {
        if (layer.type !== "image" || layer.fieldId !== "logo") continue;
        const isAccountOrEmpty = !layer.assetId || accountIds.has(layer.assetId);
        if (isAccountOrEmpty && layer.assetId !== awsWhiteId) {
          layer.assetId = awsWhiteId;
          changed = true;
        }
      }
    }
    if (changed) saveTemplate(template);
    // Per-creative logo bindings on the bound NEU feed.
    for (const feed of listFeeds(template.id)) {
      if (feed.name !== NEU_LIB_FEED_NAME) continue;
      let feedChanged = false;
      for (const row of feed.rows) {
        const cur = row.values.logo;
        if (cur && accountIds.has(cur) && cur !== awsWhiteId) {
          row.values.logo = awsWhiteId;
          feedChanged = true;
        }
      }
      if (feedChanged) {
        feed.updatedAt = Date.now();
        saveFeed(feed);
      }
    }
  }
}

// =============================================================================
// v2 scene re-seed migration.
// Older persisted templates (the AWS CX Banner Master + the NEU library) were
// built by the pre-ramp builders: solid blue CTA pill (CTA_BG), bottom scrim /
// gradient legibility overlays, and copy painted over the photo. This rebuilds
// their variant scenes with the strict AWS ramp (solid copy panel, typeset CTA
// link, no scrim) while preserving every media binding. Scoped by template name
// so user-authored templates are never touched. Idempotent: once a scene is at
// STUDIO_AWS_RAMP_SCENE_VERSION with no legacy markers it is skipped.
// =============================================================================

/** True if a persisted scene predates the AWS ramp and must be regenerated. */
function sceneIsLegacy(scene: StudioScene): boolean {
  if (scene.version < STUDIO_AWS_RAMP_SCENE_VERSION) return true;
  for (const layer of scene.layers) {
    if (layer.name === "CTA_BG") return true;
    if (/scrim/i.test(layer.name)) return true;
    if (layer.type === "rect" && layer.gradient && layer.gradient.length > 0) {
      return true;
    }
  }
  return false;
}

/** First preselected asset id for a media schema field, by field id. */
function preselectByFieldId(
  template: StudioTemplate,
  fieldId: string,
): string | undefined {
  for (const f of template.schemaFields) {
    if (f.type === "media" && f.id === fieldId) {
      return f.preselectedAssetIds?.[0];
    }
  }
  return undefined;
}

/**
 * Carry every image layer's bound assetId from the OLD scene onto the freshly
 * built scene, matched by fieldId. Any new image layer left empty is filled from
 * the template's preselected media so the regenerated thumbnail still renders.
 */
function transferSceneAssets(
  template: StudioTemplate,
  oldScene: StudioScene,
  newScene: StudioScene,
): void {
  const byField = new Map<string, string>();
  for (const layer of oldScene.layers) {
    if (layer.type === "image" && layer.fieldId && layer.assetId) {
      if (!byField.has(layer.fieldId)) byField.set(layer.fieldId, layer.assetId);
    }
  }
  for (const layer of newScene.layers) {
    if (layer.type !== "image" || !layer.fieldId) continue;
    const carried = byField.get(layer.fieldId);
    if (carried) {
      layer.assetId = carried;
    } else {
      const fallback = preselectByFieldId(template, layer.fieldId);
      if (fallback) layer.assetId = fallback;
    }
  }
}

/** Snapshot a template's pre-migration JSON so a bad rebuild is recoverable. */
function backupTemplate(template: StudioTemplate): void {
  try {
    const dir = path.join(studioDir(), "migrations");
    ensureDir(dir);
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const file = path.join(dir, `${stamp}_${template.id}_pre-aws-ramp.json`);
    writeJsonAtomic(file, template);
  } catch {
    // Backup is best-effort; never block the migration on a snapshot failure.
  }
}

/**
 * Rebuild legacy master + NEU scenes onto the AWS ramp, preserving media
 * bindings. Runs on every boot; a no-op once all in-scope scenes are at v2.
 */
function migrateStudioScenesToAwsRamp(): void {
  const neuStyleByName = new Map<string, NeuStyle>(
    NEU_TEMPLATES.map((t) => [t.name, t.style]),
  );
  for (const template of listTemplates()) {
    const isMaster = template.name === MASTER_TEMPLATE_NAME;
    const neuStyle = neuStyleByName.get(template.name);
    if (!isMaster && !neuStyle) continue;

    const needsAny = template.variants.some((v) => sceneIsLegacy(v.scene));
    if (!needsAny) continue;

    backupTemplate(template);
    for (const variant of template.variants) {
      if (!sceneIsLegacy(variant.scene)) continue;
      const rebuilt = isMaster
        ? buildDefaultScene(variant.width, variant.height)
        : buildNeuScene(variant.width, variant.height, neuStyle);
      transferSceneAssets(template, variant.scene, rebuilt);
      variant.scene = rebuilt;
    }
    template.updatedAt = Date.now();
    saveTemplate(template);
  }
}

/** True if a NEU scene has a sharp teaser but no blurred backdrop layer yet. */
function neuSceneNeedsBlur(scene: StudioScene): boolean {
  let hasSharpTeaser = false;
  let hasBlur = false;
  for (const layer of scene.layers) {
    if (layer.type !== "image") continue;
    if (layer.imageKind === "blur") hasBlur = true;
    else if (layer.imageKind === "image" && layer.fieldId === "teaser_image") {
      hasSharpTeaser = true;
    }
  }
  return hasSharpTeaser && !hasBlur;
}

/**
 * Idempotent migration: rebuild persisted NEU scenes that predate the AdTune
 * soft-blur backdrop. Scoped to NEU templates, only rebuilds variants missing
 * the blur layer, snapshots first, and preserves every media binding via
 * transferSceneAssets. No-op once all NEU scenes carry the backdrop.
 */
function migrateNeuBlurBackdrop(): void {
  const neuStyleByName = new Map<string, NeuStyle>(
    NEU_TEMPLATES.map((t) => [t.name, t.style]),
  );
  for (const template of listTemplates()) {
    const neuStyle = neuStyleByName.get(template.name);
    if (!neuStyle) continue;
    if (!template.variants.some((v) => neuSceneNeedsBlur(v.scene))) continue;
    backupTemplate(template);
    for (const variant of template.variants) {
      if (!neuSceneNeedsBlur(variant.scene)) continue;
      const rebuilt = buildNeuScene(variant.width, variant.height, neuStyle);
      transferSceneAssets(template, variant.scene, rebuilt);
      variant.scene = rebuilt;
    }
    template.updatedAt = Date.now();
    saveTemplate(template);
  }
}

/**
 * Idempotent migration: drop human (AWS People) imagery from the creatives.
 * Repoints any feed row still bound to a people teaser onto a non-human AWS
 * texture, and scrubs people assets out of teaser-image picker suggestions.
 * No-op once nothing references the people assets.
 */
function migrateNeuTeaserAwayFromPeople(map: Map<string, string>): void {
  const peopleIds = new Set(
    ["people-290", "people-310"]
      .map((k) => map.get(k))
      .filter((v): v is string => Boolean(v)),
  );
  if (peopleIds.size === 0) return;
  const texId = map.get("tex-crop-269");
  const neuNames = new Set<string>(NEU_TEMPLATES.map((t) => t.name));
  // Scope strictly to NEU surfaces: the NEU GTM templates and the auxiliary
  // Northern European feed. Never touch other templates/feeds — a human teaser
  // elsewhere may be a deliberate user pick outside this campaign.
  for (const template of listTemplates()) {
    const isNeuTemplate = neuNames.has(template.name);
    if (texId) {
      for (const feed of listFeeds(template.id)) {
        if (!isNeuTemplate && feed.name !== NE_FEED_NAME) continue;
        let changed = false;
        for (const row of feed.rows) {
          const cur = row.values.teaser_image;
          if (cur && peopleIds.has(cur)) {
            row.values.teaser_image = texId;
            changed = true;
          }
        }
        if (changed) {
          feed.updatedAt = Date.now();
          saveFeed(feed);
        }
      }
    }
    if (!isNeuTemplate) continue;
    let tChanged = false;
    for (const f of template.schemaFields) {
      if (f.type !== "media" || f.id !== "teaser_image") continue;
      if (!f.preselectedAssetIds) continue;
      const next = f.preselectedAssetIds.filter((id) => !peopleIds.has(id));
      if (next.length !== f.preselectedAssetIds.length) {
        f.preselectedAssetIds = next;
        tChanged = true;
      }
    }
    if (tChanged) {
      template.updatedAt = Date.now();
      saveTemplate(template);
    }
  }
}

/**
 * Idempotent copy fix: the NEU GenAI hero headline must read "…for Northern
 * European banks", never the truncated "…for Northern banks". Rewrites the
 * substring in NEU template headline defaults and in every NEU feed row value.
 * Scoped strictly to the NEU GTM templates + their feeds; no-op once corrected.
 */
function migrateNeuHeadlineNorthernEuropean(): void {
  const FROM = "production for Northern banks";
  const TO = "production for Northern European banks";
  const fix = (s: string): string => s.split(FROM).join(TO);
  const neuNames = new Set<string>(NEU_TEMPLATES.map((t) => t.name));
  for (const template of listTemplates()) {
    if (!neuNames.has(template.name)) continue;
    let tChanged = false;
    for (const f of template.schemaFields) {
      if (typeof f.defaultValue === "string" && f.defaultValue.includes(FROM)) {
        f.defaultValue = fix(f.defaultValue);
        tChanged = true;
      }
    }
    if (tChanged) {
      template.updatedAt = Date.now();
      saveTemplate(template);
    }
    for (const feed of listFeeds(template.id)) {
      let fChanged = false;
      for (const row of feed.rows) {
        for (const key of Object.keys(row.values)) {
          const v = row.values[key];
          if (typeof v === "string" && v.includes(FROM)) {
            row.values[key] = fix(v);
            fChanged = true;
          }
        }
      }
      if (fChanged) {
        feed.updatedAt = Date.now();
        saveFeed(feed);
      }
    }
  }
}

let seedPromise: Promise<void> | null = null;

/**
 * Seed + upgrade the studio on first request. Guarded by a single promise so
 * concurrent first requests don't double-write. The asset seeding + additive
 * upgrade are idempotent and run on every boot (filling only EMPTY fields and
 * adding only MISSING variants), so existing user edits are never overwritten.
 */
export function ensureStudioSeed(): Promise<void> {
  if (seedPromise) return seedPromise;
  seedPromise = (async () => {
    ensureDir(studioDir());
    const assetMap = await ensureStudioAssetsSeed();
    // Bring already-ingested assets up to the current curated taxonomy. No-op
    // on a fresh repl (assets seeded with the right tags) and on repeat boots.
    upgradeSeedAssetTags(assetMap);
    // Bridge the FULL ingested brand-asset catalog (all illustrations / photos /
    // logos / customers) into the studio library. Additive + idempotent.
    ensureCatalogAssetsBridge();
    // Expose the catalog-bridged AWS master mark (white) under a stable seed key
    // so NEU bindings/preselect/migration can resolve it without a duplicate
    // seed asset. Prefer the raster (reliable in Konva) over the SVG.
    const awsWhiteId =
      findCatalogAssetId("logo-aws-white-png") ??
      findCatalogAssetId("logo-aws-white");
    if (awsWhiteId) assetMap.set("logo-aws-white", awsWhiteId);
    // Correct any already-persisted templates whose CTA fill is baked-in orange.
    migrateCtaOrangeFills();

    if (listTemplates().length === 0) {
      // Fresh repl: build the master with the full dimension set + bound feed.
      const template = makeTemplate(
        MASTER_TEMPLATE_NAME,
        "Accenture Song × AWS",
        ALL_DIMENSIONS,
      );
      applyPreselected(template, assetMap);
      applyDefaultLayerAssets(template, assetMap);
      saveTemplate(template);
      saveFeed(buildSeedFeed(template.id, assetMap));
      ensureNamedFeed(template.id, NE_FEED_NAME, NE_ROWS, NE_ROW_BINDINGS, assetMap);
      // Northern European Banking GTM template library (additive, idempotent).
      ensureNeuLibrary(assetMap);
      // Northern European Banking — Blur Hero template + feed (additive).
      ensureBlurHeroLibrary(assetMap);
      // Rebuild any legacy (pre-ramp) master/NEU scenes onto the AWS ramp.
      migrateStudioScenesToAwsRamp();
      // Add the AdTune soft-blur backdrop + drop any human teaser imagery.
      migrateNeuBlurBackdrop();
      migrateNeuTeaserAwayFromPeople(assetMap);
      migrateNeuLogoToAwsWhite(assetMap);
      migrateNeuHeadlineNorthernEuropean();
      return;
    }

    // Existing repl: additive, fill-empty-only upgrade of the seeded master.
    const master = listTemplates().find((t) => t.name === MASTER_TEMPLATE_NAME);
    if (master) {
      const a = applyPreselected(master, assetMap);
      const b = addMissingVariants(master);
      // Run after addMissingVariants so newly-added variants also get defaults.
      const c = applyDefaultLayerAssets(master, assetMap);
      if (a || b || c) saveTemplate(master);
      // Add any brand sample rows not yet present, then bind empty media on all.
      addMissingFeedRows(master.id, assetMap);
      bindFeedRows(master.id, assetMap);
      // Auxiliary Northern European banking feed (NatWest anchor), additive.
      ensureNamedFeed(master.id, NE_FEED_NAME, NE_ROWS, NE_ROW_BINDINGS, assetMap);
    }
    // Northern European Banking GTM template library (additive, idempotent).
    ensureNeuLibrary(assetMap);
    // Northern European Banking — Blur Hero template + feed (additive).
    ensureBlurHeroLibrary(assetMap);
    // Rebuild any legacy (pre-ramp) master/NEU scenes onto the AWS ramp.
    migrateStudioScenesToAwsRamp();
    // Add the AdTune soft-blur backdrop + drop any human teaser imagery.
    migrateNeuBlurBackdrop();
    migrateNeuTeaserAwayFromPeople(assetMap);
    // Repoint NEU social tiles to the AWS master mark (1:Few — no account logo).
    migrateNeuLogoToAwsWhite(assetMap);
    // Correct the legacy "for Northern banks" copy → "for Northern European banks".
    migrateNeuHeadlineNorthernEuropean();
  })().catch((err) => {
    // Drop the cached promise so a later request can retry after a transient
    // filesystem/write failure instead of being stuck on the rejected seed.
    seedPromise = null;
    throw err;
  });
  return seedPromise;
}
