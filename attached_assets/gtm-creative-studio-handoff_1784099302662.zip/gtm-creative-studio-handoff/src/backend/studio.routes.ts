import { Router, type IRouter, type Response } from "express";
import multer from "multer";
import { createReadStream, existsSync, statSync } from "node:fs";
import path from "node:path";
import { z } from "zod";
import {
  addAssets,
  assetFilePath,
  buildDefaultScene,
  deleteAsset,
  deleteFeed,
  deleteTemplate,
  ensureStudioSeed,
  getAsset,
  getFeed,
  getTemplate,
  listFeeds,
  listTemplates,
  makeTemplate,
  newAssetId,
  newFeedId,
  newRenderId,
  newRowId,
  newVariantId,
  readAssetIndex,
  readRenderIndex,
  renderFilePath,
  saveFeed,
  STUDIO_ALL_FORMATS,
  saveTemplate,
  updateAsset,
  upsertRender,
  validateFieldId,
  emptyReview,
  getReview,
  listReviews,
  saveReview,
  newHandoffId,
  type StudioAsset,
  type StudioAssetKind,
  type StudioCreativeRow,
  type StudioQaSummary,
  type StudioSchemaField,
  type StudioVariant,
} from "../lib/studio-store";
import { runSkill } from "../lib/abm-agent";
import { logger } from "../lib/logger";

const router: IRouter = Router();

// Seed/upgrade the AWS CX Banner Master + assets the first time any studio
// route is touched (idempotent + additive — safe to run on every boot).
router.use("/studio", (_req, _res, next) => {
  ensureStudioSeed()
    .then(() => next())
    .catch((err) => {
      logger.warn({ err }, "studio seed failed");
      next();
    });
});

// =============================================================================
// Validation helpers
// =============================================================================

const IMAGE_EXT = new Set(["png", "jpg", "jpeg", "webp", "gif", "svg"]);
const MIME_BY_EXT: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
  gif: "image/gif",
  svg: "image/svg+xml",
  html: "text/html",
};

const MAX_FILE_BYTES = 25 * 1024 * 1024; // 25 MB per file (zip libraries)
const MAX_FILES_PER_REQUEST = 24;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_BYTES, files: MAX_FILES_PER_REQUEST },
  fileFilter(_req, file, cb) {
    const ext = path.extname(file.originalname).toLowerCase().replace(".", "");
    const isImage = IMAGE_EXT.has(ext);
    const isZip =
      ext === "zip" ||
      file.mimetype === "application/zip" ||
      file.mimetype === "application/x-zip-compressed";
    if (isImage || isZip || file.mimetype === "application/octet-stream") {
      cb(null, true);
      return;
    }
    cb(new Error(`unsupported file type: ${file.mimetype || ext}`));
  },
});

function badRequest(res: Response, message: string, detail?: unknown): void {
  res.status(400).json({ error: message, detail });
}

function extFromName(name: string): string {
  return path.extname(name).toLowerCase().replace(".", "");
}

// =============================================================================
// Templates
// =============================================================================

router.get("/studio/templates", (_req, res) => {
  res.json({ templates: listTemplates() });
});

const CreateTemplateBody = z.object({
  name: z.string().min(1).max(120),
  brand: z.string().max(120).optional(),
});

router.post("/studio/templates", (req, res) => {
  const parsed = CreateTemplateBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "invalid template", parsed.error.issues);
  const t = makeTemplate(parsed.data.name, parsed.data.brand);
  saveTemplate(t);
  res.status(201).json({ template: t });
});

router.get("/studio/templates/:id", (req, res) => {
  const t = getTemplate(req.params.id);
  if (!t) {
    res.status(404).json({ error: "template not found" });
    return;
  }
  res.json({ template: t });
});

const SchemaFieldSchema: z.ZodType<StudioSchemaField> = z.object({
  id: z.string(),
  label: z.string().min(1).max(80),
  type: z.enum(["media", "rich_text"]),
  description: z.string().max(400).optional(),
  multi: z.boolean().optional(),
  defaultValue: z.string().max(2000).optional(),
  preselectedAssetIds: z.array(z.string()).max(24).optional(),
  allowedFormats: z.array(z.string()).max(8).optional(),
  maxSizeMB: z.number().min(0).max(64).optional(),
  hidden: z.boolean().optional(),
});

const UpdateTemplateBody = z.object({
  name: z.string().min(1).max(120).optional(),
  brand: z.string().max(120).nullable().optional(),
  schemaFields: z.array(SchemaFieldSchema).max(64).optional(),
  output: z
    .object({ formatsByVariant: z.record(z.string(), z.array(z.string()).max(8)) })
    .optional(),
});

router.put("/studio/templates/:id", (req, res) => {
  const t = getTemplate(req.params.id);
  if (!t) {
    res.status(404).json({ error: "template not found" });
    return;
  }
  const parsed = UpdateTemplateBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "invalid update", parsed.error.issues);
  const d = parsed.data;
  if (d.name != null) t.name = d.name;
  if (d.brand !== undefined) t.brand = d.brand ?? undefined;
  if (d.schemaFields) {
    try {
      for (const f of d.schemaFields) validateFieldId(f.id);
    } catch (err) {
      return badRequest(res, err instanceof Error ? err.message : "bad field id");
    }
    t.schemaFields = d.schemaFields;
  }
  if (d.output) t.output = d.output;
  saveTemplate(t);
  res.json({ template: t });
});

const UpdateSchemaBody = z.object({
  schemaFields: z.array(SchemaFieldSchema).max(64),
});

router.put("/studio/templates/:id/schema", (req, res) => {
  const t = getTemplate(req.params.id);
  if (!t) {
    res.status(404).json({ error: "template not found" });
    return;
  }
  const parsed = UpdateSchemaBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "invalid schema", parsed.error.issues);
  try {
    for (const f of parsed.data.schemaFields) validateFieldId(f.id);
  } catch (err) {
    return badRequest(res, err instanceof Error ? err.message : "bad field id");
  }
  t.schemaFields = parsed.data.schemaFields;
  saveTemplate(t);
  res.json({ template: t });
});

const UpdateOutputBody = z.object({
  formatsByVariant: z.record(z.string(), z.array(z.string()).max(8)),
});

router.put("/studio/templates/:id/output", (req, res) => {
  const t = getTemplate(req.params.id);
  if (!t) {
    res.status(404).json({ error: "template not found" });
    return;
  }
  const parsed = UpdateOutputBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "invalid output", parsed.error.issues);
  t.output = { formatsByVariant: parsed.data.formatsByVariant };
  saveTemplate(t);
  res.json({ template: t });
});

router.delete("/studio/templates/:id", (req, res) => {
  const ok = deleteTemplate(req.params.id);
  if (!ok) {
    res.status(404).json({ error: "template not found" });
    return;
  }
  res.json({ ok: true });
});

// ---- Variants -----------------------------------------------------------

const AddVariantBody = z.object({
  name: z.string().min(1).max(80),
  width: z.number().int().min(16).max(4096),
  height: z.number().int().min(16).max(4096),
  type: z.enum(["static", "dynamic"]).default("static"),
});

router.post("/studio/templates/:id/variants", (req, res) => {
  const t = getTemplate(req.params.id);
  if (!t) {
    res.status(404).json({ error: "template not found" });
    return;
  }
  const parsed = AddVariantBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "invalid variant", parsed.error.issues);
  const { name, width, height, type } = parsed.data;
  const v: StudioVariant = {
    id: newVariantId(),
    name,
    type,
    width,
    height,
    scene: buildDefaultScene(width, height),
  };
  t.variants.push(v);
  t.output.formatsByVariant[v.id] = type === "static" ? ["png", "jpg"] : ["png"];
  saveTemplate(t);
  res.status(201).json({ template: t, variant: v });
});

router.post("/studio/templates/:id/variants/:variantId/duplicate", (req, res) => {
  const t = getTemplate(req.params.id);
  if (!t) {
    res.status(404).json({ error: "template not found" });
    return;
  }
  const src = t.variants.find((v) => v.id === req.params.variantId);
  if (!src) {
    res.status(404).json({ error: "variant not found" });
    return;
  }
  const copy: StudioVariant = {
    ...structuredClone(src),
    id: newVariantId(),
    name: `${src.name} copy`,
  };
  t.variants.push(copy);
  t.output.formatsByVariant[copy.id] = [
    ...(t.output.formatsByVariant[src.id] ?? ["png", "jpg"]),
  ];
  saveTemplate(t);
  res.status(201).json({ template: t, variant: copy });
});

// Loose scene schema — the client owns the layer shape; we persist it verbatim
// after a light structural check to avoid storing junk.
const SceneSchema = z.object({
  version: z.number(),
  bg: z.string(),
  layers: z.array(z.record(z.string(), z.unknown())).max(200),
});

const UpdateVariantBody = z.object({
  name: z.string().min(1).max(80).optional(),
  width: z.number().int().min(16).max(4096).optional(),
  height: z.number().int().min(16).max(4096).optional(),
  scene: SceneSchema.optional(),
});

router.put("/studio/templates/:id/variants/:variantId", (req, res) => {
  const t = getTemplate(req.params.id);
  if (!t) {
    res.status(404).json({ error: "template not found" });
    return;
  }
  const v = t.variants.find((x) => x.id === req.params.variantId);
  if (!v) {
    res.status(404).json({ error: "variant not found" });
    return;
  }
  const parsed = UpdateVariantBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "invalid variant update", parsed.error.issues);
  const d = parsed.data;
  if (d.name != null) v.name = d.name;
  if (d.width != null) v.width = d.width;
  if (d.height != null) v.height = d.height;
  if (d.scene) v.scene = d.scene as unknown as StudioVariant["scene"];
  saveTemplate(t);
  res.json({ template: t, variant: v });
});

router.delete("/studio/templates/:id/variants/:variantId", (req, res) => {
  const t = getTemplate(req.params.id);
  if (!t) {
    res.status(404).json({ error: "template not found" });
    return;
  }
  const before = t.variants.length;
  t.variants = t.variants.filter((v) => v.id !== req.params.variantId);
  if (t.variants.length === before) {
    res.status(404).json({ error: "variant not found" });
    return;
  }
  delete t.output.formatsByVariant[req.params.variantId];
  saveTemplate(t);
  res.json({ template: t });
});

// =============================================================================
// Assets
// =============================================================================

router.get("/studio/assets", (_req, res) => {
  res.json(readAssetIndex());
});

async function ingestImageBuffer(
  buf: Buffer,
  originalName: string,
  ext: string,
  kind: StudioAssetKind,
  tags: string[],
): Promise<StudioAsset> {
  const id = newAssetId();
  const safeExt = ext === "jpeg" ? "jpg" : ext;
  const fileName = `${id}.${safeExt}`;
  let width: number | undefined;
  let height: number | undefined;
  if (safeExt !== "svg") {
    try {
      const sharp = (await import("sharp")).default;
      const meta = await sharp(buf).metadata();
      width = meta.width;
      height = meta.height;
    } catch (err) {
      logger.warn({ err, originalName }, "studio: sharp metadata failed");
    }
  } else {
    // Best-effort SVG intrinsic size from width/height or viewBox.
    const head = buf.toString("utf-8").slice(0, 2000);
    const vb = /viewBox\s*=\s*["']\s*[\d.]+\s+[\d.]+\s+([\d.]+)\s+([\d.]+)/.exec(head);
    if (vb) {
      width = Math.round(Number(vb[1]));
      height = Math.round(Number(vb[2]));
    }
  }
  const { writeFileSync } = await import("node:fs");
  writeFileSync(assetFilePath(fileName), buf);
  return {
    id,
    kind,
    originalName: originalName.slice(0, 160),
    fileName,
    mime: MIME_BY_EXT[safeExt] ?? "application/octet-stream",
    ext: safeExt,
    width,
    height,
    bytes: buf.length,
    tags,
    createdAt: Date.now(),
  };
}

router.post(
  "/studio/assets",
  (req, res, next) => {
    upload.array("files", MAX_FILES_PER_REQUEST)(req, res, (err) => {
      if (err) {
        logger.warn({ err }, "studio assets: multer rejected request");
        res
          .status(400)
          .json({ error: err instanceof Error ? err.message : String(err) });
        return;
      }
      next();
    });
  },
  async (req, res, next) => {
    try {
      const files = (req.files as Express.Multer.File[] | undefined) ?? [];
      if (files.length === 0) return badRequest(res, "no files uploaded");
      const kind: StudioAssetKind =
        req.body?.kind === "packshot" ? "packshot" : "image";
      const tags =
        typeof req.body?.tags === "string" && req.body.tags.trim()
          ? req.body.tags
              .split(",")
              .map((s: string) => s.trim().toLowerCase())
              .filter(Boolean)
              .slice(0, 24)
          : [];
      const created: StudioAsset[] = [];
      const skipped: { name: string; reason: string }[] = [];

      for (const f of files) {
        const ext = extFromName(f.originalname);
        const isZip =
          ext === "zip" ||
          f.mimetype === "application/zip" ||
          f.mimetype === "application/x-zip-compressed";
        if (isZip) {
          const { unzipSync } = await import("fflate");
          let entries: Record<string, Uint8Array>;
          try {
            entries = unzipSync(new Uint8Array(f.buffer));
          } catch (err) {
            skipped.push({ name: f.originalname, reason: "corrupt zip" });
            logger.warn({ err, name: f.originalname }, "studio: bad zip");
            continue;
          }
          for (const [entryName, data] of Object.entries(entries)) {
            // Ignore directory entries, macOS metadata, and dotfiles.
            const base = entryName.split("/").pop() ?? entryName;
            if (
              entryName.endsWith("/") ||
              entryName.includes("__MACOSX") ||
              base.startsWith(".")
            ) {
              continue;
            }
            const entryExt = extFromName(base);
            if (!IMAGE_EXT.has(entryExt)) {
              continue;
            }
            if (data.length > MAX_FILE_BYTES) {
              skipped.push({ name: base, reason: "too large" });
              continue;
            }
            created.push(
              await ingestImageBuffer(
                Buffer.from(data),
                base,
                entryExt,
                kind,
                tags,
              ),
            );
          }
          continue;
        }
        if (!IMAGE_EXT.has(ext)) {
          skipped.push({ name: f.originalname, reason: "unsupported type" });
          continue;
        }
        created.push(
          await ingestImageBuffer(f.buffer, f.originalname, ext, kind, tags),
        );
      }

      if (created.length === 0) {
        return badRequest(res, "no usable images found", { skipped });
      }
      const index = addAssets(created);
      res.status(201).json({ index, added: created, skipped });
    } catch (err) {
      next(err);
    }
  },
);

const PatchAssetBody = z.object({
  tags: z.array(z.string().max(40)).max(24).optional(),
  kind: z.enum(["image", "packshot"]).optional(),
});

router.patch("/studio/assets/:id", (req, res) => {
  const parsed = PatchAssetBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "invalid patch", parsed.error.issues);
  const a = updateAsset(req.params.id, {
    tags: parsed.data.tags?.map((t) => t.toLowerCase()),
    kind: parsed.data.kind,
  });
  if (!a) {
    res.status(404).json({ error: "asset not found" });
    return;
  }
  res.json({ asset: a });
});

router.delete("/studio/assets/:id", (req, res) => {
  const ok = deleteAsset(req.params.id);
  if (!ok) {
    res.status(404).json({ error: "asset not found" });
    return;
  }
  res.json({ ok: true });
});

const ASSET_FILE_RE = /^ast_[a-z0-9_]+\.[a-z0-9]+$/;

router.get("/studio/assets/file/:fileName", (req, res) => {
  const fileName = req.params.fileName;
  if (!ASSET_FILE_RE.test(fileName)) {
    res.status(400).json({ error: "invalid file name" });
    return;
  }
  let filePath: string;
  try {
    filePath = assetFilePath(fileName);
  } catch {
    res.status(400).json({ error: "invalid file name" });
    return;
  }
  if (!existsSync(filePath)) {
    res.status(404).json({ error: "file not found" });
    return;
  }
  const ext = extFromName(fileName);
  const stat = statSync(filePath);
  res.setHeader("Content-Type", MIME_BY_EXT[ext] ?? "application/octet-stream");
  res.setHeader("Content-Length", String(stat.size));
  res.setHeader("X-Content-Type-Options", "nosniff");
  if (ext === "svg") {
    // Defensive: <img>/Konva never execute SVG scripts, but lock it down anyway.
    res.setHeader("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'");
  }
  res.setHeader("Cache-Control", "private, max-age=600");
  const stream = createReadStream(filePath);
  stream.on("error", (err) => {
    req.log?.warn?.({ err, filePath }, "studio asset stream error");
    if (!res.headersSent) res.status(500).end();
    else res.destroy(err);
  });
  res.on("close", () => stream.destroy());
  stream.pipe(res);
});

// =============================================================================
// Feeds + creative rows
// =============================================================================

router.get("/studio/feeds", (req, res) => {
  const templateId =
    typeof req.query.templateId === "string" ? req.query.templateId : undefined;
  res.json({ feeds: listFeeds(templateId) });
});

const CreateFeedBody = z.object({
  templateId: z.string().min(1),
  name: z.string().min(1).max(120),
});

router.post("/studio/feeds", (req, res) => {
  const parsed = CreateFeedBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "invalid feed", parsed.error.issues);
  if (!getTemplate(parsed.data.templateId)) {
    res.status(404).json({ error: "template not found" });
    return;
  }
  const feed = {
    id: newFeedId(),
    templateId: parsed.data.templateId,
    name: parsed.data.name,
    rows: [] as StudioCreativeRow[],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  saveFeed(feed);
  res.status(201).json({ feed });
});

router.get("/studio/feeds/:id", (req, res) => {
  const feed = getFeed(req.params.id);
  if (!feed) {
    res.status(404).json({ error: "feed not found" });
    return;
  }
  res.json({ feed });
});

router.put("/studio/feeds/:id", (req, res) => {
  const feed = getFeed(req.params.id);
  if (!feed) {
    res.status(404).json({ error: "feed not found" });
    return;
  }
  const name = req.body?.name;
  if (typeof name === "string" && name.trim()) feed.name = name.slice(0, 120);
  saveFeed(feed);
  res.json({ feed });
});

router.delete("/studio/feeds/:id", (req, res) => {
  const ok = deleteFeed(req.params.id);
  if (!ok) {
    res.status(404).json({ error: "feed not found" });
    return;
  }
  res.json({ ok: true });
});

const CropSchema = z.object({
  x: z.number(),
  y: z.number(),
  scale: z.number().min(0.1).max(8),
});

const StyleSchema = z.object({
  opacity: z.number().min(0).max(1).optional(),
  cornerRadius: z.number().min(0).max(400).optional(),
  blur: z.number().min(0).max(200).optional(),
});

const RowBody = z.object({
  uid: z.string().max(40).optional(),
  locale: z.string().max(16).optional(),
  tags: z.array(z.string().max(40)).max(24).optional(),
  values: z.record(z.string(), z.string().max(4000)).optional(),
  // A `null` crop value deletes that field's crop on update (the merge below
  // can't express a removal by omitting the key).
  crops: z.record(z.string(), CropSchema.nullable()).optional(),
  // Same merge/null-delete semantics as crops, for per-creative layer styles.
  styleOverrides: z.record(z.string(), StyleSchema.nullable()).optional(),
});

router.post("/studio/feeds/:id/rows", (req, res) => {
  const feed = getFeed(req.params.id);
  if (!feed) {
    res.status(404).json({ error: "feed not found" });
    return;
  }
  const parsed = RowBody.safeParse(req.body ?? {});
  if (!parsed.success) return badRequest(res, "invalid row", parsed.error.issues);
  const d = parsed.data;
  const initialCrops: NonNullable<StudioCreativeRow["crops"]> = {};
  if (d.crops) {
    for (const [k, v] of Object.entries(d.crops)) if (v) initialCrops[k] = v;
  }
  const initialStyles: NonNullable<StudioCreativeRow["styleOverrides"]> = {};
  if (d.styleOverrides) {
    for (const [k, v] of Object.entries(d.styleOverrides)) if (v) initialStyles[k] = v;
  }
  const row: StudioCreativeRow = {
    id: newRowId(),
    uid: d.uid || `CR-${feed.rows.length + 1}`.padStart(5, "0"),
    locale: d.locale || "en-US",
    tags: d.tags ?? [],
    values: d.values ?? {},
    crops: initialCrops,
    styleOverrides: initialStyles,
  };
  feed.rows.push(row);
  saveFeed(feed);
  res.status(201).json({ feed, row });
});

router.put("/studio/feeds/:id/rows/:rowId", (req, res) => {
  const feed = getFeed(req.params.id);
  if (!feed) {
    res.status(404).json({ error: "feed not found" });
    return;
  }
  const row = feed.rows.find((r) => r.id === req.params.rowId);
  if (!row) {
    res.status(404).json({ error: "row not found" });
    return;
  }
  const parsed = RowBody.safeParse(req.body ?? {});
  if (!parsed.success) return badRequest(res, "invalid row", parsed.error.issues);
  const d = parsed.data;
  if (d.uid != null) row.uid = d.uid;
  if (d.locale != null) row.locale = d.locale;
  if (d.tags != null) row.tags = d.tags;
  if (d.values != null) row.values = { ...row.values, ...d.values };
  if (d.crops != null) {
    // Merge by field so an inspector patch never clobbers a crop another writer
    // changed; a `null` value explicitly deletes that field's crop.
    const nextCrops = { ...(row.crops ?? {}) };
    for (const [k, v] of Object.entries(d.crops)) {
      if (v == null) delete nextCrops[k];
      else nextCrops[k] = v;
    }
    row.crops = nextCrops;
  }
  if (d.styleOverrides != null) {
    // Same per-field merge + null-delete semantics as crops.
    const nextStyles = { ...(row.styleOverrides ?? {}) };
    for (const [k, v] of Object.entries(d.styleOverrides)) {
      if (v == null) delete nextStyles[k];
      else nextStyles[k] = v;
    }
    row.styleOverrides = nextStyles;
  }
  saveFeed(feed);
  res.json({ feed, row });
});

router.delete("/studio/feeds/:id/rows/:rowId", (req, res) => {
  const feed = getFeed(req.params.id);
  if (!feed) {
    res.status(404).json({ error: "feed not found" });
    return;
  }
  const before = feed.rows.length;
  feed.rows = feed.rows.filter((r) => r.id !== req.params.rowId);
  if (feed.rows.length === before) {
    res.status(404).json({ error: "row not found" });
    return;
  }
  saveFeed(feed);
  res.json({ feed });
});

// =============================================================================
// Renders — persist client-built Konva bitmaps and serve / export them.
// =============================================================================

router.get("/studio/renders", (req, res) => {
  const feedId =
    typeof req.query.feedId === "string" ? req.query.feedId : undefined;
  const idx = readRenderIndex();
  res.json({
    renders: feedId
      ? idx.renders.filter((r) => r.feedId === feedId)
      : idx.renders,
  });
});

const DATA_URL_RE = /^data:image\/(png|jpeg|jpg|webp);base64,([A-Za-z0-9+/=]+)$/;
const GIF_DATA_URL_RE = /^data:image\/gif;base64,([A-Za-z0-9+/=]+)$/;
const HTML_DATA_URL_RE = /^data:text\/html;base64,([A-Za-z0-9+/=]+)$/;

/**
 * Decode a render data URL for the given output format, or null when the URL
 * does not match the format. Static formats stay png/jpg/webp bitmaps; dynamic
 * formats carry a `gif` bitmap loop or a self-contained `html5` replay bundle.
 */
function decodeRenderDataUrl(
  format: string,
  dataUrl: string,
): { buf: Buffer; ext: string } | null {
  if (format === "gif") {
    const m = GIF_DATA_URL_RE.exec(dataUrl);
    return m ? { buf: Buffer.from(m[1]!, "base64"), ext: "gif" } : null;
  }
  if (format === "html5") {
    const m = HTML_DATA_URL_RE.exec(dataUrl);
    return m ? { buf: Buffer.from(m[1]!, "base64"), ext: "html" } : null;
  }
  const m = DATA_URL_RE.exec(dataUrl);
  if (!m) return null;
  return {
    buf: Buffer.from(m[2]!, "base64"),
    ext: format === "jpg" ? "jpg" : format,
  };
}

const PersistRenderItem = z.object({
  rowId: z.string().min(1),
  variantId: z.string().min(1),
  format: z.enum(["png", "jpg", "webp", "gif", "html5"]),
  width: z.number().int().min(1).max(8192),
  height: z.number().int().min(1).max(8192),
  dataUrl: z.string().min(16).max(26_000_000),
});

const PersistRendersBody = z.object({
  feedId: z.string().min(1),
  renders: z.array(PersistRenderItem).min(1).max(48),
});

router.post("/studio/renders", (req, res) => {
  const parsed = PersistRendersBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "invalid renders", parsed.error.issues);
  const feed = getFeed(parsed.data.feedId);
  if (!feed) {
    res.status(404).json({ error: "feed not found" });
    return;
  }
  const template = getTemplate(feed.templateId);
  if (!template) {
    res.status(404).json({ error: "template not found for feed" });
    return;
  }
  // Integrity gate: a persisted creative must correspond to a real row of this
  // feed and a real variant of the feed's template, at that variant's exact
  // dimensions and an output format enabled for it. Validate the whole batch
  // before writing any bytes so a rejected item never leaves orphaned files.
  const feedRowById = new Map(feed.rows.map((r) => [r.id, r]));
  const feedRowIds = new Set(feedRowById.keys());
  const variantById = new Map(template.variants.map((v) => [v.id, v]));
  // Editorial-licensed stock may only appear in editorial/PR contexts, never in
  // produced/paid creatives. Block persisting any render whose row binds an
  // editorial-only asset (logo or teaser) before any bytes are written.
  const editorialAssetIn = (row: StudioCreativeRow): string | null => {
    for (const field of ["logo", "teaser_image"] as const) {
      const assetId = row.values[field];
      if (!assetId) continue;
      const asset = getAsset(assetId);
      if (asset?.tags.includes("editorial-only")) return asset.originalName;
    }
    return null;
  };
  const DYNAMIC_FORMATS = new Set(["gif", "html5"]);
  const enabledFormatsFor = (variantId: string): string[] => {
    const raw = template.output?.formatsByVariant?.[variantId] ?? [];
    const allowed = raw.filter((f) =>
      (STUDIO_ALL_FORMATS as readonly string[]).includes(f),
    );
    return allowed.length > 0 ? allowed : ["png"];
  };
  for (const item of parsed.data.renders) {
    if (!feedRowIds.has(item.rowId)) {
      return badRequest(res, `render rowId not in feed: ${item.rowId}`);
    }
    const row = feedRowById.get(item.rowId);
    const editorialName = row ? editorialAssetIn(row) : null;
    if (editorialName) {
      return badRequest(
        res,
        `cannot produce a paid creative with editorial-only asset "${editorialName}"; swap it for a licensed image before rendering`,
      );
    }
    const variant = variantById.get(item.variantId);
    if (!variant) {
      return badRequest(
        res,
        `render variantId not in template: ${item.variantId}`,
      );
    }
    if (item.width !== variant.width || item.height !== variant.height) {
      return badRequest(
        res,
        `render dimensions ${item.width}x${item.height} do not match variant ${variant.width}x${variant.height}`,
      );
    }
    if (DYNAMIC_FORMATS.has(item.format) && variant.type !== "dynamic") {
      return badRequest(
        res,
        `dynamic format ${item.format} requires a dynamic variant: ${item.variantId}`,
      );
    }
    if (!enabledFormatsFor(item.variantId).includes(item.format)) {
      return badRequest(
        res,
        `render format ${item.format} not enabled for variant ${item.variantId}`,
      );
    }
    if (!decodeRenderDataUrl(item.format, item.dataUrl)) {
      return badRequest(res, "invalid data url for render");
    }
  }
  const saved = [];
  for (const item of parsed.data.renders) {
    const decoded = decodeRenderDataUrl(item.format, item.dataUrl);
    if (!decoded) {
      return badRequest(res, "invalid data url for render");
    }
    const id = newRenderId();
    const fileName = `${id}.${decoded.ext}`;
    const rec = upsertRender(
      {
        id,
        feedId: parsed.data.feedId,
        rowId: item.rowId,
        variantId: item.variantId,
        format: item.format,
        fileName,
        width: item.width,
        height: item.height,
        bytes: decoded.buf.length,
        createdAt: Date.now(),
      },
      decoded.buf,
    );
    saved.push(rec);
  }
  res.status(201).json({ saved, renders: readRenderIndex().renders });
});

const RENDER_FILE_RE = /^rnd_[a-z0-9_]+\.[a-z0-9]+$/;

router.get("/studio/renders/file/:fileName", (req, res) => {
  const fileName = req.params.fileName;
  if (!RENDER_FILE_RE.test(fileName)) {
    res.status(400).json({ error: "invalid file name" });
    return;
  }
  let filePath: string;
  try {
    filePath = renderFilePath(fileName);
  } catch {
    res.status(400).json({ error: "invalid file name" });
    return;
  }
  if (!existsSync(filePath)) {
    res.status(404).json({ error: "file not found" });
    return;
  }
  const ext = extFromName(fileName);
  const stat = statSync(filePath);
  res.setHeader("Content-Type", MIME_BY_EXT[ext] ?? "application/octet-stream");
  res.setHeader("Content-Length", String(stat.size));
  res.setHeader("X-Content-Type-Options", "nosniff");
  if (ext === "html") {
    // Self-contained HTML5 replay bundles are downloads, never executed inline:
    // serving client-authored HTML same-origin would be a stored-XSS vector.
    res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
    res.setHeader("Content-Security-Policy", "default-src 'none'");
  }
  res.setHeader("Cache-Control", "private, max-age=120");
  const stream = createReadStream(filePath);
  stream.on("error", (err) => {
    req.log?.warn?.({ err, filePath }, "studio render stream error");
    if (!res.headersSent) res.status(500).end();
    else res.destroy(err);
  });
  res.on("close", () => stream.destroy());
  stream.pipe(res);
});

// Export every stored render for a feed as a single zip download.
router.get("/studio/renders/export", async (req, res, next) => {
  try {
    const feedId =
      typeof req.query.feedId === "string" ? req.query.feedId : undefined;
    if (!feedId) return badRequest(res, "feedId required");
    const feed = getFeed(feedId);
    if (!feed) {
      res.status(404).json({ error: "feed not found" });
      return;
    }
    const renders = readRenderIndex().renders.filter((r) => r.feedId === feedId);
    if (renders.length === 0) {
      res.status(404).json({ error: "no renders stored for this feed" });
      return;
    }
    const { readFileSync } = await import("node:fs");
    const { zipSync } = await import("fflate");
    const files: Record<string, Uint8Array> = {};
    for (const r of renders) {
      const row = feed.rows.find((x) => x.id === r.rowId);
      const uid = (row?.uid || r.rowId).replace(/[^\w.\-]+/g, "_");
      try {
        const buf = readFileSync(renderFilePath(r.fileName));
        files[
          `${uid}/${r.variantId}_${r.width}x${r.height}.${extFromName(r.fileName)}`
        ] = new Uint8Array(buf);
      } catch (err) {
        logger.warn({ err, file: r.fileName }, "studio export: missing render file");
      }
    }
    const zipped = zipSync(files);
    const safeName = feed.name.replace(/[^\w.\-]+/g, "_") || "renders";
    res.setHeader("Content-Type", "application/zip");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${safeName}.zip"`,
    );
    res.setHeader("Content-Length", String(zipped.length));
    res.end(Buffer.from(zipped));
  } catch (err) {
    next(err);
  }
});

// =============================================================================
// Agentic endpoints — Gitclaw `runSkill` wrappers.
//
// Every endpoint here:
//   * is rate-limited + input-capped (LLM cost / abuse guard),
//   * returns PROPOSALS only — it NEVER auto-applies model output. The client
//     shows a diff, the user confirms, and the existing CRUD routes persist.
//   * validates every id the model emits against the live feed/template/assets
//     before returning, so a confirmed proposal can't write a phantom id.
//   * logs a SkillCall (visible in /observability) via runSkill.
// =============================================================================

const AGENT_RATE_LIMIT = 24;
const AGENT_RATE_WINDOW_MS = 60_000;
const AGENT_MAX_TRACKED_IPS = 1024;
const agentRateBuckets = new Map<string, number[]>();

function sweepAgentBuckets(now: number): void {
  const cutoff = now - AGENT_RATE_WINDOW_MS;
  for (const [ip, bucket] of agentRateBuckets) {
    const live = bucket.filter((t) => t > cutoff);
    if (live.length === 0) agentRateBuckets.delete(ip);
    else agentRateBuckets.set(ip, live);
  }
}

/** Take a rate-limit token; returns false (and sends 429) when over budget. */
function agentGuard(req: { ip?: string; socket: { remoteAddress?: string } }, res: Response): boolean {
  const ip = (req.ip || req.socket.remoteAddress || "unknown").toString().slice(0, 64);
  const now = Date.now();
  const cutoff = now - AGENT_RATE_WINDOW_MS;
  if (agentRateBuckets.size > AGENT_MAX_TRACKED_IPS) sweepAgentBuckets(now);
  const fresh = (agentRateBuckets.get(ip) ?? []).filter((t) => t > cutoff);
  if (fresh.length >= AGENT_RATE_LIMIT) {
    agentRateBuckets.set(ip, fresh);
    res.status(429).json({ error: "Too many studio agent requests; please slow down." });
    return false;
  }
  fresh.push(now);
  agentRateBuckets.set(ip, fresh);
  return true;
}

function richTextFieldIds(t: { schemaFields: StudioSchemaField[] }): Set<string> {
  return new Set(t.schemaFields.filter((f) => f.type === "rich_text").map((f) => f.id));
}

function clampNum(n: unknown, lo: number, hi: number, dflt: number): number {
  if (typeof n !== "number" || !Number.isFinite(n)) return dflt;
  return Math.min(hi, Math.max(lo, n));
}

/** Coerce a model-proposed values map down to the template's rich_text ids. */
function sanitizeValues(
  raw: unknown,
  allowed: Set<string>,
): Record<string, string> {
  const out: Record<string, string> = {};
  if (raw && typeof raw === "object") {
    for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
      if (allowed.has(k) && typeof v === "string" && v.trim()) {
        out[k] = v.slice(0, 240);
      }
    }
  }
  return out;
}

// --- Tolerant skill-output normalizers --------------------------------------
// LLM JSON is well-formed but its *shape* drifts (e.g. `proposals` vs
// `variants`, `field_values:[{field_id,value}]` vs `values:{}`). Rather than
// reject a good answer on a key name, we accept the common shape variants and
// then validate/sanitize everything against the live template.

/** First array found among candidate top-level keys of a skill result. */
function pickArray(result: unknown, keys: string[]): Record<string, unknown>[] {
  if (!result || typeof result !== "object") return [];
  const obj = result as Record<string, unknown>;
  for (const k of keys) {
    if (Array.isArray(obj[k])) return obj[k] as Record<string, unknown>[];
  }
  return [];
}

/** First string found among candidate keys of an item. */
function pickStr(item: Record<string, unknown>, keys: string[]): string {
  for (const k of keys) {
    if (typeof item[k] === "string" && (item[k] as string).trim()) {
      return item[k] as string;
    }
  }
  return "";
}

/**
 * Build a sanitized field-value map from an item, accepting either the object
 * form (`values: { fieldId: text }`) or the array form
 * (`field_values: [{ field_id, value }]`).
 */
function coerceValueMap(
  item: Record<string, unknown>,
  allowed: Set<string>,
): Record<string, string> {
  const direct = sanitizeValues(item.values, allowed);
  if (Object.keys(direct).length) return direct;
  const arr = Array.isArray(item.field_values)
    ? item.field_values
    : Array.isArray(item.fields)
      ? item.fields
      : null;
  if (Array.isArray(arr)) {
    const obj: Record<string, unknown> = {};
    for (const fv of arr as Record<string, unknown>[]) {
      const fid =
        typeof fv.field_id === "string"
          ? fv.field_id
          : typeof fv.id === "string"
            ? fv.id
            : "";
      if (fid) obj[fid] = fv.value;
    }
    return sanitizeValues(obj, allowed);
  }
  return {};
}

/** True when an item is a single flat field edit, not a per-row object. */
function isFieldEdit(item: Record<string, unknown>): boolean {
  if (item.values || item.field_values || item.fields) return false;
  const hasField =
    typeof item.field_id === "string" || typeof item.fieldId === "string";
  const hasValue =
    "proposed_value" in item || "value" in item || "new_value" in item;
  return hasField && hasValue;
}

/**
 * Feed-autofill models sometimes return a FLAT list of per-field edits
 * (`[{ row_uid, field_id, proposed_value }]`) instead of per-row objects.
 * Group those into per-row value maps keyed by row uid.
 */
function groupFieldEdits(
  items: Record<string, unknown>[],
  allowed: Set<string>,
): Map<string, Record<string, string>> {
  const byUid = new Map<string, Record<string, unknown>>();
  for (const it of items) {
    const uid = pickStr(it, ["row_uid", "uid", "concept_uid", "id"]);
    const fid = pickStr(it, ["field_id", "fieldId"]);
    if (!uid || !fid) continue;
    const val = it.proposed_value ?? it.value ?? it.new_value;
    const bucket = byUid.get(uid) ?? {};
    bucket[fid] = val;
    byUid.set(uid, bucket);
  }
  const out = new Map<string, Record<string, string>>();
  for (const [uid, raw] of byUid) {
    const v = sanitizeValues(raw, allowed);
    if (Object.keys(v).length) out.set(uid, v);
  }
  return out;
}

// --- POST /studio/agent/generate-variants ------------------------------------
const GenerateVariantsBody = z.object({
  templateId: z.string().min(1),
  feedId: z.string().min(1).optional(),
  brief: z.string().min(1).max(6000),
  count: z.number().int().min(1).max(12).optional(),
  locale: z.string().max(16).optional(),
});

router.post("/studio/agent/generate-variants", async (req, res, next) => {
  if (!agentGuard(req, res)) return;
  try {
    const parsed = GenerateVariantsBody.safeParse(req.body);
    if (!parsed.success) return badRequest(res, "invalid request", parsed.error.issues);
    const { templateId, feedId, brief, locale } = parsed.data;
    const count = parsed.data.count ?? 3;
    const template = getTemplate(templateId);
    if (!template) return void res.status(404).json({ error: "template not found" });
    const feed = feedId ? getFeed(feedId) : null;
    if (feedId && !feed) return void res.status(404).json({ error: "feed not found" });

    const rt = richTextFieldIds(template);
    const run = await runSkill<{ variants?: unknown[] }>({
      skillName: "studio-generate-creative-variants",
      input: {
        brand: template.brand,
        brief,
        count,
        locale: locale || "en-US",
        fields: template.schemaFields
          .filter((f) => f.type === "rich_text")
          .map((f) => ({ id: f.id, label: f.label, type: f.type, description: f.description })),
        existing_uids: (feed?.rows ?? []).map((r) => r.uid).slice(0, 200),
      },
    });
    if (!run.ok) {
      return void res.status(502).json({ error: run.error ?? "agent run failed", skillCallId: run.skillCallId });
    }

    const existing = new Set((feed?.rows ?? []).map((r) => r.uid));
    const seen = new Set<string>();
    const proposals = pickArray(run.result, ["variants", "proposals", "concepts"])
      .slice(0, count)
      .map((v, i) => {
        const values = coerceValueMap(v, rt);
        let uid = pickStr(v, ["uid", "concept_uid", "id"]).replace(/[^\w.\-]+/g, "-").slice(0, 40);
        if (!uid || existing.has(uid) || seen.has(uid)) uid = `AI-${Date.now().toString(36)}-${i + 1}`;
        seen.add(uid);
        const rationale = pickStr(v, ["rationale", "concept_summary", "note"]);
        return {
          uid,
          locale: pickStr(v, ["locale"]).slice(0, 16) || locale || "en-US",
          values,
          rationale: rationale ? rationale.slice(0, 200) : undefined,
        };
      })
      .filter((p) => Object.keys(p.values).length > 0);

    res.json({ proposals, skillCallId: run.skillCallId });
  } catch (err) {
    next(err);
  }
});

// --- POST /studio/agent/feed-autofill ----------------------------------------
const FeedAutofillBody = z.object({
  feedId: z.string().min(1),
  brief: z.string().max(6000).optional(),
  dataset: z.array(z.record(z.string(), z.unknown())).max(50).optional(),
});

router.post("/studio/agent/feed-autofill", async (req, res, next) => {
  if (!agentGuard(req, res)) return;
  try {
    const parsed = FeedAutofillBody.safeParse(req.body);
    if (!parsed.success) return badRequest(res, "invalid request", parsed.error.issues);
    const { feedId, brief } = parsed.data;
    const feed = getFeed(feedId);
    if (!feed) return void res.status(404).json({ error: "feed not found" });
    const template = getTemplate(feed.templateId);
    if (!template) return void res.status(404).json({ error: "template not found" });

    // Cap the dataset's serialized size to protect prompt cost.
    let dataset = parsed.data.dataset ?? [];
    if (JSON.stringify(dataset).length > 24_000) dataset = dataset.slice(0, 20);

    const rt = richTextFieldIds(template);
    const run = await runSkill<{ rows?: unknown[] }>({
      skillName: "studio-feed-autofill",
      input: {
        brand: template.brand,
        brief,
        fields: template.schemaFields
          .filter((f) => f.type === "rich_text")
          .map((f) => ({ id: f.id, label: f.label, type: f.type, description: f.description })),
        rows: feed.rows.map((r) => ({ uid: r.uid, locale: r.locale, values: r.values })).slice(0, 100),
        dataset,
      },
    });
    if (!run.ok) {
      return void res.status(502).json({ error: run.error ?? "agent run failed", skillCallId: run.skillCallId });
    }

    const rowByUid = new Map(feed.rows.map((r) => [r.uid, r]));
    const items = pickArray(run.result, ["rows", "proposals", "variants", "edits"]);

    // Two shapes are common: per-row objects (`{ uid, values }`) and a flat
    // list of per-field edits (`{ row_uid, field_id, proposed_value }`). When
    // the model returns the flat shape, group it into per-row value maps.
    let perRow: Array<{ uid: string; values: Record<string, string>; source?: unknown; locale?: string }>;
    if (items.some(isFieldEdit)) {
      perRow = [...groupFieldEdits(items, rt)].map(([uid, values]) => ({ uid, values }));
    } else {
      perRow = items.slice(0, 120).map((r) => ({
        uid: pickStr(r, ["uid", "concept_uid", "id"]).slice(0, 40),
        values: coerceValueMap(r, rt),
        source: r.source,
        locale: pickStr(r, ["locale"]).slice(0, 16) || undefined,
      }));
    }

    const proposals = perRow
      .map((r, i) => {
        const existingRow = rowByUid.get(r.uid);
        return {
          uid: r.uid || `AI-${Date.now().toString(36)}-${i + 1}`,
          rowId: existingRow?.id, // present ⇒ update existing row, absent ⇒ new row
          locale: r.locale || existingRow?.locale || "en-US",
          values: r.values,
          source: r.source === "dataset" ? "dataset" : "row",
        };
      })
      .filter((p) => Object.keys(p.values).length > 0);

    res.json({ proposals, skillCallId: run.skillCallId });
  } catch (err) {
    next(err);
  }
});

// --- POST /studio/agent/improve-creative -------------------------------------
// "Select a creative, ask the agent to improve it" — the feed-stage analogue of
// the Assembly improve pattern. Scoped to ONE row: reuses the feed-autofill
// skill but feeds it only the selected row plus a free-text instruction, and
// returns a single per-field before/after proposal applied via updateRow.
const ImproveCreativeBody = z.object({
  feedId: z.string().min(1),
  rowId: z.string().min(1),
  instruction: z.string().max(2000).optional(),
});

router.post("/studio/agent/improve-creative", async (req, res, next) => {
  if (!agentGuard(req, res)) return;
  try {
    const parsed = ImproveCreativeBody.safeParse(req.body);
    if (!parsed.success) return badRequest(res, "invalid request", parsed.error.issues);
    const { feedId, rowId, instruction } = parsed.data;
    const feed = getFeed(feedId);
    if (!feed) return void res.status(404).json({ error: "feed not found" });
    const row = feed.rows.find((r) => r.id === rowId);
    if (!row) return void res.status(404).json({ error: "creative not found" });
    const template = getTemplate(feed.templateId);
    if (!template) return void res.status(404).json({ error: "template not found" });

    const brief = [
      "Improve and refine the copy for this single creative.",
      "Keep the same fields; sharpen clarity, tone and impact; respect the brand voice; do not invent unverifiable claims.",
      instruction?.trim() ? `Author guidance: ${instruction.trim()}` : "",
    ]
      .filter(Boolean)
      .join(" ");

    const rt = richTextFieldIds(template);
    const run = await runSkill<{ rows?: unknown[] }>({
      skillName: "studio-feed-autofill",
      input: {
        brand: template.brand,
        brief,
        fields: template.schemaFields
          .filter((f) => f.type === "rich_text")
          .map((f) => ({ id: f.id, label: f.label, type: f.type, description: f.description })),
        rows: [{ uid: row.uid, locale: row.locale, values: row.values }],
        dataset: [],
      },
    });
    if (!run.ok) {
      return void res.status(502).json({ error: run.error ?? "agent run failed", skillCallId: run.skillCallId });
    }

    const items = pickArray(run.result, ["rows", "proposals", "variants", "edits"]);
    let values: Record<string, string> = {};
    if (items.some(isFieldEdit)) {
      const grouped = groupFieldEdits(items, rt);
      values = grouped.get(row.uid) ?? [...grouped.values()][0] ?? {};
    } else {
      const match =
        items.find((r) => pickStr(r, ["uid", "concept_uid", "id"]) === row.uid) ?? items[0];
      values = match ? coerceValueMap(match, rt) : {};
    }

    // Only surface fields that actually changed.
    const changed: Record<string, string> = {};
    for (const [fid, val] of Object.entries(values)) {
      if ((row.values[fid] ?? "") !== val) changed[fid] = val;
    }

    res.json({
      proposal: { rowId: row.id, uid: row.uid, values: changed },
      skillCallId: run.skillCallId,
    });
  } catch (err) {
    next(err);
  }
});

// --- POST /studio/agent/smart-crop -------------------------------------------
const SmartCropBody = z.object({
  templateId: z.string().min(1),
  assetId: z.string().min(1),
  fieldId: z.string().min(1),
  variantIds: z.array(z.string()).max(48).optional(),
});

router.post("/studio/agent/smart-crop", async (req, res, next) => {
  if (!agentGuard(req, res)) return;
  try {
    const parsed = SmartCropBody.safeParse(req.body);
    if (!parsed.success) return badRequest(res, "invalid request", parsed.error.issues);
    const { templateId, assetId, fieldId } = parsed.data;
    const template = getTemplate(templateId);
    if (!template) return void res.status(404).json({ error: "template not found" });
    const field = template.schemaFields.find((f) => f.id === fieldId);
    if (!field || field.type !== "media") {
      return badRequest(res, `fieldId ${fieldId} is not a media field of this template`);
    }
    const asset = getAsset(assetId);
    if (!asset) return void res.status(404).json({ error: "asset not found" });

    const wanted = new Set(parsed.data.variantIds ?? template.variants.map((v) => v.id));
    const targets = template.variants.filter((v) => wanted.has(v.id));
    if (targets.length === 0) return badRequest(res, "no matching variants");

    const run = await runSkill<{ crops?: unknown[] }>({
      skillName: "studio-smart-crop",
      input: {
        field_id: fieldId,
        asset: {
          id: asset.id,
          width: asset.width,
          height: asset.height,
          tags: asset.tags,
          kind: asset.kind,
        },
        targets: targets.map((v) => ({ variant_id: v.id, name: v.name, width: v.width, height: v.height })),
      },
    });
    if (!run.ok) {
      return void res.status(502).json({ error: run.error ?? "agent run failed", skillCallId: run.skillCallId });
    }

    const validVariant = new Set(targets.map((v) => v.id));
    const proposals = pickArray(run.result, ["crops", "proposals"])
      .map((c) => ({ c, vid: pickStr(c, ["variant_id", "variantId"]) }))
      .filter((x) => validVariant.has(x.vid))
      .map(({ c, vid }) => ({
        variantId: vid,
        fieldId,
        // crops are keyed `${variantId}:${fieldId}` on the row
        cropKey: `${vid}:${fieldId}`,
        x: clampNum(c.x, -0.5, 0.5, 0),
        y: clampNum(c.y, -0.5, 0.5, 0),
        scale: clampNum(c.scale, 1, 4, 1),
        rationale: typeof c.rationale === "string" ? c.rationale.slice(0, 160) : undefined,
      }));

    res.json({ proposals, skillCallId: run.skillCallId });
  } catch (err) {
    next(err);
  }
});

// --- POST /studio/agent/auto-tag ---------------------------------------------
const AutoTagBody = z.object({ assetId: z.string().min(1) });

router.post("/studio/agent/auto-tag", async (req, res, next) => {
  if (!agentGuard(req, res)) return;
  try {
    const parsed = AutoTagBody.safeParse(req.body);
    if (!parsed.success) return badRequest(res, "invalid request", parsed.error.issues);
    const asset = getAsset(parsed.data.assetId);
    if (!asset) return void res.status(404).json({ error: "asset not found" });

    const run = await runSkill<{
      tags?: unknown;
      idp?: unknown;
      audience?: unknown;
      funnel_stage?: unknown;
    }>({
      skillName: "asset-labeller-auto-label-new-asset",
      input: { asset_id: asset.id, originalName: asset.originalName, kind: asset.kind },
    });
    if (!run.ok) {
      return void res.status(502).json({ error: run.error ?? "agent run failed", skillCallId: run.skillCallId });
    }

    const toStrArr = (v: unknown): string[] =>
      Array.isArray(v)
        ? v.filter((x) => typeof x === "string").map((x) => (x as string).toLowerCase().slice(0, 40)).slice(0, 24)
        : [];
    const proposal = {
      tags: toStrArr(run.result?.tags),
      idp: typeof run.result?.idp === "string" ? run.result.idp.slice(0, 80) : undefined,
      audience: toStrArr(run.result?.audience),
      funnelStage:
        typeof run.result?.funnel_stage === "string" ? run.result.funnel_stage.slice(0, 80) : undefined,
    };
    res.json({ assetId: asset.id, proposal, skillCallId: run.skillCallId });
  } catch (err) {
    next(err);
  }
});

// --- POST /studio/agent/matrix-qa --------------------------------------------
const QA_CHECKS = {
  brand: "brand-check",
  competitor: "competitor-check",
  compliance: "brand-guardian-full-brand-qa-on-asset",
} as const;
type QaCheckKey = keyof typeof QA_CHECKS;

const MatrixQaBody = z.object({
  feedId: z.string().min(1),
  checks: z.array(z.enum(["brand", "competitor", "compliance"])).max(3).optional(),
});

router.post("/studio/agent/matrix-qa", async (req, res, next) => {
  if (!agentGuard(req, res)) return;
  try {
    const parsed = MatrixQaBody.safeParse(req.body);
    if (!parsed.success) return badRequest(res, "invalid request", parsed.error.issues);
    const feed = getFeed(parsed.data.feedId);
    if (!feed) return void res.status(404).json({ error: "feed not found" });
    const template = getTemplate(feed.templateId);
    if (!template) return void res.status(404).json({ error: "template not found" });
    const checks = (parsed.data.checks ?? ["brand", "competitor", "compliance"]) as QaCheckKey[];

    const rt = richTextFieldIds(template);
    // One composed_asset whose slot ids encode the row uid, so a single skill
    // call per check can attribute findings back to a creative. Copy-level QA is
    // dimension-independent, so dimension is reported as the full variant set.
    const slots = feed.rows.flatMap((row) =>
      Object.entries(row.values)
        .filter(([fid]) => rt.has(fid))
        .map(([fid, content]) => ({ slot_id: `${row.uid}::${fid}`, content })),
    );
    const composed = { slots };

    const findings: {
      check: QaCheckKey;
      rowUid: string;
      fieldId?: string;
      severity: string;
      rule?: string;
      snippet?: string;
      guidance?: string;
    }[] = [];
    const skillCallIds: string[] = [];
    const bySeverity: Record<string, number> = {};

    for (const check of checks) {
      const run = await runSkill<{ findings?: unknown[] }>({
        skillName: QA_CHECKS[check],
        input: {
          structured_brief: { brand: template.brand, campaign: feed.name },
          composed_asset: composed,
          creatives: feed.rows.map((r) => r.uid),
          dimensions: template.variants.map((v) => v.name),
        },
        phase: "tailoring",
      });
      skillCallIds.push(run.skillCallId);
      if (!run.ok) continue;
      for (const f of (run.result?.findings ?? []) as Record<string, unknown>[]) {
        const slotId = typeof f.slot_id === "string" ? f.slot_id : "";
        const [rowUid, fieldId] = slotId.includes("::") ? slotId.split("::") : ["", undefined];
        const severity = typeof f.severity === "string" ? f.severity : "warn";
        bySeverity[severity] = (bySeverity[severity] ?? 0) + 1;
        findings.push({
          check,
          rowUid: rowUid || feed.rows[0]?.uid || "—",
          fieldId,
          severity,
          rule: typeof f.rule === "string" ? f.rule : undefined,
          snippet: typeof f.snippet === "string" ? f.snippet.slice(0, 120) : undefined,
          guidance: typeof f.guidance === "string" ? f.guidance.slice(0, 200) : undefined,
        });
      }
    }

    const summary: StudioQaSummary = {
      ranAt: Date.now(),
      totalFindings: findings.length,
      bySeverity,
      skillCallIds,
    };
    // Persist the latest QA summary onto the feed's review record (T009 reads it).
    const review = getReview(feed.id) ?? emptyReview(feed.id);
    review.qaSummary = summary;
    saveReview(review);

    res.json({ findings, summary, skillCallIds });
  } catch (err) {
    next(err);
  }
});

// --- POST /studio/agent/chat -------------------------------------------------
const StudioChatMsg = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().max(4000),
});
const StudioChatBody = z.object({
  feedId: z.string().min(1).optional(),
  templateId: z.string().min(1).optional(),
  message: z.string().min(1).max(4000),
  history: z.array(StudioChatMsg).max(8).optional(),
});

const STUDIO_CHAT_ACTIONS = new Set([
  "generate",
  "autofill",
  "smart_crop",
  "qa",
  "none",
]);
/** Validate + truncate raw agent suggestions down to the safe allowed set. */
function sanitizeStudioChatSuggestions(
  raw: unknown,
): { action: string; label: string; note?: string }[] {
  return ((raw ?? []) as Record<string, unknown>[])
    .filter(
      (s) => typeof s.action === "string" && STUDIO_CHAT_ACTIONS.has(s.action),
    )
    .slice(0, 6)
    .map((s) => ({
      action: s.action as string,
      label: typeof s.label === "string" ? s.label.slice(0, 40) : "",
      note: typeof s.note === "string" ? s.note.slice(0, 80) : undefined,
    }))
    .filter((s) => s.label);
}

/** Shared compact studio context passed to the assistant skill. */
function buildStudioChatContext(
  template: ReturnType<typeof getTemplate>,
  feed: ReturnType<typeof getFeed>,
) {
  return {
    template: template
      ? {
          name: template.name,
          fields: template.schemaFields.map((f) => f.id),
          variants: template.variants.map((v) => `${v.width}x${v.height}`),
        }
      : null,
    feed: feed
      ? {
          name: feed.name,
          rowCount: feed.rows.length,
          locales: [...new Set(feed.rows.map((r) => r.locale))].slice(0, 12),
        }
      : null,
  };
}

router.post("/studio/agent/chat", async (req, res, next) => {
  if (!agentGuard(req, res)) return;
  try {
    const parsed = StudioChatBody.safeParse(req.body);
    if (!parsed.success) return badRequest(res, "invalid request", parsed.error.issues);
    const { message } = parsed.data;
    const feed = parsed.data.feedId ? getFeed(parsed.data.feedId) : null;
    const template =
      (feed && getTemplate(feed.templateId)) ||
      (parsed.data.templateId ? getTemplate(parsed.data.templateId) : null);

    const history = (parsed.data.history ?? []).slice(-8).map((m) => ({
      role: m.role,
      content: m.content.slice(0, 4000),
    }));

    const run = await runSkill<{ reply?: unknown; suggestions?: unknown[] }>({
      skillName: "studio-assistant-chat",
      input: {
        message,
        context: buildStudioChatContext(template, feed),
        history,
      },
    });
    if (!run.ok) {
      return void res.status(502).json({ error: run.error ?? "agent run failed", skillCallId: run.skillCallId });
    }

    res.json({
      reply: typeof run.result?.reply === "string" ? run.result.reply : "",
      suggestions: sanitizeStudioChatSuggestions(run.result?.suggestions),
      skillCallId: run.skillCallId,
    });
  } catch (err) {
    next(err);
  }
});

// --- POST /studio/agent/chat/stream ------------------------------------------
// SSE variant of the chat route: forwards the Gitclaw agent's live actions
// (tool_use / tool_result / system) as `action` events while it works, then a
// final `done` event carrying the parsed { reply, suggestions, skillCallId }.
// The non-streaming route above stays as a rollback fallback for the client.
router.post("/studio/agent/chat/stream", async (req, res) => {
  if (!agentGuard(req, res)) return;
  const parsed = StudioChatBody.safeParse(req.body);
  if (!parsed.success)
    return badRequest(res, "invalid request", parsed.error.issues);
  const { message } = parsed.data;
  const feed = parsed.data.feedId ? getFeed(parsed.data.feedId) : null;
  const template =
    (feed && getTemplate(feed.templateId)) ||
    (parsed.data.templateId ? getTemplate(parsed.data.templateId) : null);
  const history = (parsed.data.history ?? []).slice(-8).map((m) => ({
    role: m.role,
    content: m.content.slice(0, 4000),
  }));

  res.status(200);
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders?.();

  let clientGone = false;
  req.on("close", () => {
    clientGone = true;
  });
  const writeEvent = (obj: unknown) => {
    if (clientGone || res.writableEnded || res.destroyed) return;
    try {
      res.write(`data: ${JSON.stringify(obj)}\n\n`);
    } catch {
      /* client vanished mid-write */
    }
  };
  // Heartbeat comment keeps proxies/clients from idling out during long gaps.
  const heartbeat = setInterval(() => {
    if (clientGone || res.writableEnded || res.destroyed) return;
    try {
      res.write(`: ping\n\n`);
    } catch {
      /* ignore */
    }
  }, 20000);

  try {
    const run = await runSkill<{ reply?: unknown; suggestions?: unknown[] }>({
      skillName: "studio-assistant-chat",
      input: {
        message,
        context: buildStudioChatContext(template, feed),
        history,
      },
      onEvent: (ev) => {
        if (ev.type === "start") {
          writeEvent({ type: "start", skillCallId: ev.skillCallId });
        } else if (ev.type === "tool_use") {
          writeEvent({
            type: "action",
            kind: "tool_use",
            toolName: ev.toolName,
            detail: ev.argsPreview,
          });
        } else if (ev.type === "tool_result") {
          writeEvent({
            type: "action",
            kind: "tool_result",
            toolName: ev.toolName,
            isError: ev.isError,
          });
        } else if (ev.type === "system") {
          writeEvent({ type: "action", kind: "system", detail: ev.contentPreview });
        } else if (ev.type === "error") {
          writeEvent({ type: "action", kind: "error", detail: ev.contentPreview });
        }
      },
    });

    if (!run.ok) {
      writeEvent({
        type: "error",
        error: run.error ?? "agent run failed",
        skillCallId: run.skillCallId,
      });
    } else {
      writeEvent({
        type: "done",
        reply: typeof run.result?.reply === "string" ? run.result.reply : "",
        suggestions: sanitizeStudioChatSuggestions(run.result?.suggestions),
        skillCallId: run.skillCallId,
      });
    }
  } catch (err) {
    req.log?.error?.({ err }, "studio chat stream failed");
    writeEvent({ type: "error", error: (err as Error).message });
  } finally {
    clearInterval(heartbeat);
    if (!res.writableEnded) {
      try {
        res.end();
      } catch {
        /* ignore */
      }
    }
  }
});

// =============================================================================
// Review + Distribution (per-feed approval state). The review store is written
// by matrix-qa (qaSummary) and by these routes (entry statuses, pack approval,
// handoffs). UI in the Review/Distribution surface consumes them.
// =============================================================================

// --- GET /studio/reviews-summary — aggregate pipeline state for dashboard -----
// Scans every per-feed review file once and rolls up pack-approval +
// handoff counts so the dashboard tracker reflects real Review/Distribution
// state without N per-feed round-trips.
router.get("/studio/reviews-summary", (_req, res) => {
  const reviews = listReviews();
  let approvedPacks = 0;
  let pendingPacks = 0;
  let totalHandoffs = 0;
  for (const r of reviews) {
    if (r.packStatus === "approved") approvedPacks += 1;
    else pendingPacks += 1;
    totalHandoffs += r.handoffs?.length ?? 0;
  }
  res.json({
    summary: {
      reviewedFeeds: reviews.length,
      approvedPacks,
      pendingPacks,
      totalHandoffs,
    },
  });
});

// --- GET /studio/reviews/:feedId ---------------------------------------------
router.get("/studio/reviews/:feedId", (req, res) => {
  const feedId = req.params.feedId;
  const feed = getFeed(feedId);
  if (!feed) return void res.status(404).json({ error: "feed not found" });
  res.json({ review: getReview(feedId) ?? emptyReview(feedId) });
});

// --- PUT /studio/reviews/:feedId — upsert one row×variant review entry --------
const ReviewEntryBody = z.object({
  rowId: z.string().min(1),
  variantId: z.string().min(1),
  status: z.enum(["pending", "approved", "changes_requested"]),
  note: z.string().max(400).optional(),
});

router.put("/studio/reviews/:feedId", (req, res) => {
  const feedId = req.params.feedId;
  const feed = getFeed(feedId);
  if (!feed) return void res.status(404).json({ error: "feed not found" });
  const template = getTemplate(feed.templateId);
  if (!template) return void res.status(404).json({ error: "template not found" });

  const parsed = ReviewEntryBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "invalid request", parsed.error.issues);
  const { rowId, variantId, status, note } = parsed.data;

  // Validate the row/variant exist on the live feed/template before persisting.
  if (!feed.rows.some((r) => r.id === rowId)) {
    return void res.status(404).json({ error: "row not found" });
  }
  if (!template.variants.some((v) => v.id === variantId)) {
    return void res.status(404).json({ error: "variant not found" });
  }

  const review = getReview(feedId) ?? emptyReview(feedId);
  const existing = review.entries.find(
    (e) => e.rowId === rowId && e.variantId === variantId,
  );
  if (existing) {
    existing.status = status;
    existing.note = note;
    existing.updatedAt = Date.now();
  } else {
    review.entries.push({ rowId, variantId, status, note, updatedAt: Date.now() });
  }
  saveReview(review);
  res.json({ review });
});

// --- POST /studio/reviews/:feedId/approve — set pack-level approval -----------
const ApproveBody = z.object({
  status: z.enum(["pending", "approved", "changes_requested"]).optional(),
});

router.post("/studio/reviews/:feedId/approve", (req, res) => {
  const feedId = req.params.feedId;
  const feed = getFeed(feedId);
  if (!feed) return void res.status(404).json({ error: "feed not found" });
  const parsed = ApproveBody.safeParse(req.body ?? {});
  if (!parsed.success) return badRequest(res, "invalid request", parsed.error.issues);

  const review = getReview(feedId) ?? emptyReview(feedId);
  review.packStatus = parsed.data.status ?? "approved";
  saveReview(review);
  res.json({ review });
});

// --- POST /studio/distribution/handoff — package + DAM fixture handoff --------
const HandoffBody = z.object({
  feedId: z.string().min(1),
  destination: z.string().min(1).max(60).optional(),
});

router.post("/studio/distribution/handoff", async (req, res, next) => {
  if (!agentGuard(req, res)) return;
  try {
    const parsed = HandoffBody.safeParse(req.body);
    if (!parsed.success) return badRequest(res, "invalid request", parsed.error.issues);
    const { feedId } = parsed.data;
    const destination = (parsed.data.destination ?? "Brand DAM").slice(0, 60);

    const feed = getFeed(feedId);
    if (!feed) return void res.status(404).json({ error: "feed not found" });

    const review = getReview(feedId) ?? emptyReview(feedId);
    if (review.packStatus !== "approved") {
      return void res.status(409).json({ error: "pack not approved" });
    }

    const renders = readRenderIndex().renders.filter((r) => r.feedId === feedId);
    if (renders.length === 0) {
      return void res.status(404).json({ error: "no renders stored for this feed" });
    }

    // Best-effort fixture handoff via the DAM skill — failure to summarize must
    // not block recording the handoff (renders are still ZIP-exportable).
    const run = await runSkill<{ summary?: string }>({
      skillName: "adtune-ship-approved-pack-to-dam",
      input: {
        campaign: feed.name,
        destination,
        asset_count: renders.length,
        formats: [...new Set(renders.map((r) => r.format))],
      },
      phase: "adaptation",
    });

    const handoff = {
      id: newHandoffId(),
      destination,
      status: run.ok ? "shipped" : "recorded",
      renderCount: renders.length,
      skillCallId: run.skillCallId,
      summary:
        run.ok && typeof run.result?.summary === "string"
          ? run.result.summary.slice(0, 300)
          : undefined,
      createdAt: Date.now(),
    };
    review.handoffs.unshift(handoff);
    saveReview(review);

    res.json({ review, handoff });
  } catch (err) {
    next(err);
  }
});

export default router;
