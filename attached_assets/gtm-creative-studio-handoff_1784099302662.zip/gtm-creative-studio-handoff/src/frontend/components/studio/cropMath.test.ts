import { describe, expect, it } from "vitest";
import {
  clearFieldCrops,
  compositeCropKey,
  coverCrop,
  cropWriteKeyFor,
  fieldHasCrop,
  IDENTITY_CROP,
  MAX_CROP_SCALE,
  panCrop,
  perSizeCropCount,
  resolveCropOverride,
  zoomCrop,
} from "./cropMath";
import type { StudioCropOverride } from "./types";

/**
 * Guards for the on-canvas crop interaction. The crop frame in
 * `StudioKonva.CropOverlay` snaps back to its origin each frame, so Konva
 * reports the node offset as the CUMULATIVE pointer delta from drag-start.
 * The overlay therefore applies that cumulative delta to a FIXED base crop
 * captured at drag-start (not to the running result), so dragging must not
 * double-count. These tests pin that contract — the earlier bug pinned the
 * node via `dragBoundFunc` so the delta was always 0 and panning did nothing.
 */

// A landscape source (1600x900) shown in a tall portrait box (300x600) has
// horizontal overflow, so the X axis is pannable.
const NW = 1600;
const NH = 900;
const BOX_W = 300;
const BOX_H = 600;

describe("panCrop drag mechanics", () => {
  it("a non-zero horizontal drag moves the focal point", () => {
    const next = panCrop(IDENTITY_CROP, BOX_W, BOX_H, 40, 0, NW, NH);
    expect(next.x).not.toBe(0);
    // Dragging content right reveals the left edge: focal x decreases.
    expect(next.x).toBeLessThan(0);
  });

  it("cumulative deltas on a FIXED base equal one combined delta (no double-count)", () => {
    const base: StudioCropOverride = { ...IDENTITY_CROP };
    // Simulate three drag frames: Konva reports cumulative offset each frame,
    // and the overlay always re-applies it to the SAME base.
    const f1 = panCrop(base, BOX_W, BOX_H, 20, 0, NW, NH);
    const f2 = panCrop(base, BOX_W, BOX_H, 50, 0, NW, NH);
    const f3 = panCrop(base, BOX_W, BOX_H, 90, 0, NW, NH);
    const direct = panCrop(base, BOX_W, BOX_H, 90, 0, NW, NH);
    // Final frame must match a single 90px drag — i.e. it tracks the pointer,
    // it does not accelerate by accumulating onto prior results.
    expect(f3.x).toBeCloseTo(direct.x, 10);
    // And the motion is monotonic across frames.
    expect(f2.x).toBeLessThan(f1.x);
    expect(f3.x).toBeLessThan(f2.x);
  });

  it("re-applying the running result instead of the base WOULD double-count", () => {
    // Documents why the overlay keeps a fixed drag base. Feeding each result
    // back in (the buggy shape) over-pans versus tracking the pointer.
    let running: StudioCropOverride = { ...IDENTITY_CROP };
    running = panCrop(running, BOX_W, BOX_H, 30, 0, NW, NH);
    running = panCrop(running, BOX_W, BOX_H, 60, 0, NW, NH);
    const tracked = panCrop(IDENTITY_CROP, BOX_W, BOX_H, 60, 0, NW, NH);
    expect(running.x).toBeLessThan(tracked.x);
  });

  it("locked axes stay pinned (no vertical overflow here)", () => {
    const next = panCrop(IDENTITY_CROP, BOX_W, BOX_H, 0, 120, NW, NH);
    expect(next.y).toBe(0);
  });

  it("focal point is clamped to the pannable range", () => {
    const huge = panCrop(IDENTITY_CROP, BOX_W, BOX_H, 100000, 0, NW, NH);
    expect(huge.x).toBeGreaterThanOrEqual(-0.5);
    expect(huge.x).toBeLessThanOrEqual(0.5);
  });
});

describe("zoomCrop", () => {
  it("wheel/slider zoom changes scale but keeps the focal point", () => {
    const panned = panCrop(IDENTITY_CROP, BOX_W, BOX_H, 40, 0, NW, NH);
    const zoomed = zoomCrop(panned, 2);
    expect(zoomed.scale).toBe(2);
    expect(zoomed.x).toBe(panned.x);
    expect(zoomed.y).toBe(panned.y);
  });

  it("scale is clamped to the allowed range", () => {
    expect(zoomCrop(IDENTITY_CROP, 999).scale).toBe(MAX_CROP_SCALE);
    expect(zoomCrop(IDENTITY_CROP, 0).scale).toBe(1);
  });

  it("zooming in widens the pannable range so panning has more travel", () => {
    const beforeAtScale1 = panCrop(IDENTITY_CROP, BOX_W, BOX_H, 0, 40, NW, NH);
    // At scale 1 the Y axis is locked (cover already fills height); zooming in
    // creates vertical overflow so a vertical drag now moves the focal point.
    const zoomed = zoomCrop(IDENTITY_CROP, 2);
    const afterAtScale2 = panCrop(zoomed, BOX_W, BOX_H, 0, 40, NW, NH);
    expect(beforeAtScale1.y).toBe(0);
    expect(afterAtScale2.y).not.toBe(0);
  });

  it("cover crop honors the focal override within the source bounds", () => {
    const region = coverCrop(NW, NH, BOX_W, BOX_H, { x: 0.25, y: 0, scale: 1 });
    expect(region.x).toBeGreaterThan(0);
    expect(region.x + region.width).toBeLessThanOrEqual(NW + 1e-6);
    expect(region.height).toBeLessThanOrEqual(NH + 1e-6);
  });
});

/**
 * Per-size crop model. Each banner size keeps its OWN draggable frame via a
 * composite `${variantId}:${fieldId}` key, while a shared `${fieldId}` base key
 * applies to every size. Resolution is composite-then-base. These pin that
 * contract so the editor preview and the stored render resolve identically.
 */
describe("per-size crop resolution", () => {
  const base: StudioCropOverride = { x: 0.1, y: 0, scale: 1 };
  const perA: StudioCropOverride = { x: -0.2, y: 0.3, scale: 2 };

  it("a composite override wins over the base for its own variant", () => {
    const crops = {
      teaser_image: base,
      [compositeCropKey("v_a", "teaser_image")]: perA,
    };
    expect(resolveCropOverride(crops, "teaser_image", "v_a")).toEqual(perA);
  });

  it("falls back to the shared base when a variant has no override", () => {
    const crops = {
      teaser_image: base,
      [compositeCropKey("v_a", "teaser_image")]: perA,
    };
    expect(resolveCropOverride(crops, "teaser_image", "v_b")).toEqual(base);
    // No variant context at all also resolves to the base.
    expect(resolveCropOverride(crops, "teaser_image")).toEqual(base);
  });

  it("returns undefined when neither a per-size nor base crop exists", () => {
    expect(resolveCropOverride({}, "teaser_image", "v_a")).toBeUndefined();
  });

  it("write key is composite only in per-size mode with a known variant", () => {
    expect(cropWriteKeyFor("teaser_image", "v_a", true)).toBe(
      "v_a:teaser_image",
    );
    // Consistent mode → shared base key.
    expect(cropWriteKeyFor("teaser_image", "v_a", false)).toBe("teaser_image");
    // No variant (e.g. feed inspector) → always the base key.
    expect(cropWriteKeyFor("teaser_image", undefined, true)).toBe(
      "teaser_image",
    );
  });

  it("a field is 'cropped' via the base OR any per-size override", () => {
    expect(fieldHasCrop({ teaser_image: base }, "teaser_image")).toBe(true);
    expect(
      fieldHasCrop(
        { [compositeCropKey("v_a", "teaser_image")]: perA },
        "teaser_image",
      ),
    ).toBe(true);
    expect(fieldHasCrop({ logo: base }, "teaser_image")).toBe(false);
  });

  it("reset clears the base and EVERY per-size override for the field only", () => {
    const crops = {
      teaser_image: base,
      [compositeCropKey("v_a", "teaser_image")]: perA,
      [compositeCropKey("v_b", "teaser_image")]: perA,
      logo: base,
      [compositeCropKey("v_a", "logo")]: perA,
    };
    const next = clearFieldCrops(crops, "teaser_image");
    expect(fieldHasCrop(next, "teaser_image")).toBe(false);
    // A different field's crops survive untouched.
    expect(next.logo).toEqual(base);
    expect(next[compositeCropKey("v_a", "logo")]).toEqual(perA);
  });

  it("a similarly-named field is not falsely matched by the colon delimiter", () => {
    // `image` must not match `v_a:hero_image` — the colon is the boundary.
    const crops = {
      [compositeCropKey("v_a", "hero_image")]: perA,
    };
    expect(fieldHasCrop(crops, "image")).toBe(false);
    expect(perSizeCropCount(crops, "image")).toBe(0);
    expect(clearFieldCrops(crops, "image")).toEqual(crops);
  });

  it("per-size count tallies only composite overrides, not the base", () => {
    const crops = {
      teaser_image: base,
      [compositeCropKey("v_a", "teaser_image")]: perA,
      [compositeCropKey("v_b", "teaser_image")]: perA,
    };
    expect(perSizeCropCount(crops, "teaser_image")).toBe(2);
  });
});
