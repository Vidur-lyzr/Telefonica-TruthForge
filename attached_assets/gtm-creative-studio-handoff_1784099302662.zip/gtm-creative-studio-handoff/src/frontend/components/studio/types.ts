/**
 * Creative Studio — client-side mirror of the server store types
 * (`artifacts/api-server/src/lib/studio-store.ts`). Kept in sync by hand; the
 * studio surface deliberately uses raw fetch + mirrored types instead of the
 * OpenAPI/orval pipeline so the layer/scene model can evolve quickly.
 */

export type StudioLayerType = "text" | "image" | "rect";
export type StudioImageKind = "image" | "logo" | "blur";

export type StudioClipType =
  | "fadeIn"
  | "fadeOut"
  | "slideIn"
  | "slideOut"
  | "popIn"
  | "pulse";
export type StudioEasing = "linear" | "easeIn" | "easeOut" | "easeInOut";

export interface StudioAnimationClip {
  type: StudioClipType;
  startMs: number;
  durationMs: number;
  /** Slide direction for slideIn / slideOut. */
  direction?: "left" | "right" | "up" | "down";
  /** Numeric override (px slide distance, or scale factor for pop / pulse). */
  from?: number;
  to?: number;
  easing?: StudioEasing;
}

export interface StudioLayerAnimation {
  clips: StudioAnimationClip[];
}

export interface StudioLayerBase {
  id: string;
  name: string;
  type: StudioLayerType;
  x: number;
  y: number;
  w: number;
  h: number;
  rotation?: number;
  opacity?: number;
  visible?: boolean;
  locked?: boolean;
  /** Optional keyframe animation; only played on dynamic variants. */
  animation?: StudioLayerAnimation;
}

export interface StudioTextLayer extends StudioLayerBase {
  type: "text";
  text: string;
  fieldId?: string;
  fontFamily?: string;
  fontSize?: number;
  fontWeight?: number;
  lineHeight?: number;
  letterSpacing?: number;
  align?: "left" | "center" | "right";
  valign?: "top" | "middle" | "bottom";
  color?: string;
  upper?: boolean;
}

export interface StudioImageLayer extends StudioLayerBase {
  type: "image";
  imageKind: StudioImageKind;
  assetId?: string;
  fieldId?: string;
  fit?: "cover" | "contain" | "stretch";
  cornerRadius?: number;
  blur?: number;
  /** Unsharp-mask amount (0–100) for non-blur image/logo layers. */
  sharpen?: number;
  /**
   * Template-level cover-crop framing for THIS image section (focal pan/zoom).
   * Per-LAYER (not per-fieldId) so a blurred background and the sharp foreground
   * card bound to the same media field frame independently. Applied at
   * render/export as the base crop; a per-creative row crop (by fieldId) wins
   * when present. Mirrors the server `StudioImageLayer.crop`.
   */
  crop?: StudioCropOverride;
}

export interface StudioRectLayer extends StudioLayerBase {
  type: "rect";
  fill?: string;
  gradient?: [number, string][];
  cornerRadius?: number;
  stroke?: string;
  strokeWidth?: number;
}

export type StudioLayer = StudioTextLayer | StudioImageLayer | StudioRectLayer;

export interface StudioTimeline {
  /** Total scene duration in ms. */
  durationMs: number;
  /** Capture frame-rate for animated export. */
  fps: number;
  /** Time (ms) at which the static poster / thumbnail frame is sampled. */
  captureMs: number;
}

export interface StudioScene {
  version: number;
  bg: string;
  layers: StudioLayer[];
  /** Optional animation timeline; absent ⇒ static scene (captured at 0ms). */
  timeline?: StudioTimeline;
}

export type StudioFieldType = "media" | "rich_text";

export interface StudioSchemaField {
  id: string;
  label: string;
  type: StudioFieldType;
  description?: string;
  multi?: boolean;
  defaultValue?: string;
  preselectedAssetIds?: string[];
  allowedFormats?: string[];
  maxSizeMB?: number;
  hidden?: boolean;
}

export interface StudioVariant {
  id: string;
  name: string;
  type: "static" | "dynamic";
  width: number;
  height: number;
  scene: StudioScene;
}

export interface StudioOutputSettings {
  formatsByVariant: Record<string, string[]>;
}

export interface StudioTemplate {
  id: string;
  name: string;
  brand?: string;
  schemaFields: StudioSchemaField[];
  variants: StudioVariant[];
  output: StudioOutputSettings;
  createdAt: number;
  updatedAt: number;
}

export type StudioAssetKind = "image" | "packshot";

export interface StudioAsset {
  id: string;
  kind: StudioAssetKind;
  originalName: string;
  fileName: string;
  mime: string;
  ext: string;
  width?: number;
  height?: number;
  bytes: number;
  tags: string[];
  createdAt: number;
}

export interface StudioAssetIndex {
  assets: StudioAsset[];
  updatedAt: number;
}

export interface StudioCropOverride {
  x: number;
  y: number;
  scale: number;
}

/**
 * Per-creative layer-style override, keyed by the bound image fieldId (like
 * crops). Each field is optional so a creative can override just opacity while
 * inheriting corner radius / blur from the template layer. Applied across every
 * dimension at render time.
 */
export interface StudioStyleOverride {
  opacity?: number;
  cornerRadius?: number;
  blur?: number;
}

export interface StudioCreativeRow {
  id: string;
  uid: string;
  locale: string;
  tags: string[];
  values: Record<string, string>;
  crops?: Record<string, StudioCropOverride>;
  styleOverrides?: Record<string, StudioStyleOverride>;
}

export interface StudioFeed {
  id: string;
  templateId: string;
  name: string;
  rows: StudioCreativeRow[];
  createdAt: number;
  updatedAt: number;
}

export interface StudioRender {
  id: string;
  feedId: string;
  rowId: string;
  variantId: string;
  format: string;
  fileName: string;
  width: number;
  height: number;
  bytes: number;
  createdAt: number;
}

export const STUDIO_STATIC_FORMATS = ["png", "jpg", "webp"] as const;
export const STUDIO_DYNAMIC_FORMATS = ["gif", "html5"] as const;
export const STUDIO_ALL_FORMATS = [
  ...STUDIO_STATIC_FORMATS,
  ...STUDIO_DYNAMIC_FORMATS,
] as const;

// =============================================================================
// Review / distribution (per-feed approval state) — mirror of the server store.
// =============================================================================

export type StudioReviewStatus = "pending" | "approved" | "changes_requested";

export interface StudioReviewEntry {
  rowId: string;
  variantId: string;
  status: StudioReviewStatus;
  note?: string;
  updatedAt: number;
}

export interface StudioQaSummary {
  ranAt: number;
  totalFindings: number;
  bySeverity: Record<string, number>;
  skillCallIds?: string[];
}

export interface StudioHandoffRecord {
  id: string;
  destination: string;
  status: string;
  renderCount: number;
  skillCallId?: string;
  summary?: string;
  createdAt: number;
}

export interface StudioReview {
  feedId: string;
  packStatus: StudioReviewStatus;
  entries: StudioReviewEntry[];
  qaSummary?: StudioQaSummary;
  handoffs: StudioHandoffRecord[];
  updatedAt: number;
}
