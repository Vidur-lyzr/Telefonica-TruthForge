/**
 * Shared cover-crop math for the Creative Studio. Pure functions (no Konva / DOM)
 * so the renderer, the on-canvas crop overlay and the multi-slice grid all agree
 * on exactly how a `StudioCropOverride { x, y, scale }` maps a source image into
 * a cover-fit box.
 *
 * Focal model: `x` / `y` are offsets from centre in [-0.5, 0.5]; `scale` is the
 * zoom factor (>= 1). The visible window keeps the BOX aspect ratio and can pan
 * across the FULL overflow of the source — so at scale 1 you can still slide
 * along the cropped axis (the earlier model could only pan inside the extra zoom
 * slack, which meant panning did nothing until you zoomed in).
 */
import type { StudioCropOverride } from "./types";

export const MIN_CROP_SCALE = 1;
export const MAX_CROP_SCALE = 4;

export function clamp01(n: number): number {
  return Math.max(0, Math.min(1, n));
}

export function clampScale(scale: number): number {
  if (!Number.isFinite(scale)) return MIN_CROP_SCALE;
  return Math.max(MIN_CROP_SCALE, Math.min(MAX_CROP_SCALE, scale));
}

export interface CoverGeometry {
  /** Source-pixel size of the visible (post-zoom) window. */
  zw: number;
  zh: number;
  /** Pannable source range on each axis (0 when that axis is locked). */
  rangeX: number;
  rangeY: number;
}

/** Geometry of the cover window for a source `nw×nh` shown in a `w×h` box. */
export function coverGeometry(
  nw: number,
  nh: number,
  w: number,
  h: number,
  scale: number,
): CoverGeometry {
  const target = w / h;
  const ar = nw / nh;
  let cw: number;
  let ch: number;
  if (ar > target) {
    cw = nh * target;
    ch = nh;
  } else {
    cw = nw;
    ch = nw / target;
  }
  const s = clampScale(scale);
  const zw = cw / s;
  const zh = ch / s;
  return { zw, zh, rangeX: Math.max(0, nw - zw), rangeY: Math.max(0, nh - zh) };
}

/** Cover-crop region (in natural px) with optional focal pan/zoom override. */
export function coverCrop(
  nw: number,
  nh: number,
  w: number,
  h: number,
  override?: StudioCropOverride,
): { x: number; y: number; width: number; height: number } {
  const scale = clampScale(override?.scale ?? 1);
  const { zw, zh, rangeX, rangeY } = coverGeometry(nw, nh, w, h, scale);
  const fx = clamp01(0.5 + (override?.x ?? 0));
  const fy = clamp01(0.5 + (override?.y ?? 0));
  return { x: rangeX * fx, y: rangeY * fy, width: zw, height: zh };
}

/**
 * Apply a drag (in BOX/design px) to a crop, returning the new override. Drag
 * direction is natural: dragging the image content right reveals more of the
 * left edge. Axes with no overflow are pinned.
 */
export function panCrop(
  crop: StudioCropOverride | undefined,
  w: number,
  h: number,
  dragDx: number,
  dragDy: number,
  nw: number,
  nh: number,
): StudioCropOverride {
  const scale = clampScale(crop?.scale ?? 1);
  const { zw, zh, rangeX, rangeY } = coverGeometry(nw, nh, w, h, scale);
  let fx = 0.5 + (crop?.x ?? 0);
  let fy = 0.5 + (crop?.y ?? 0);
  if (rangeX > 0) fx -= (dragDx * (zw / w)) / rangeX;
  if (rangeY > 0) fy -= (dragDy * (zh / h)) / rangeY;
  return { x: clamp01(fx) - 0.5, y: clamp01(fy) - 0.5, scale };
}

/** Set zoom while keeping the focal point, clamped to the allowed range. */
export function zoomCrop(
  crop: StudioCropOverride | undefined,
  nextScale: number,
): StudioCropOverride {
  return {
    x: crop?.x ?? 0,
    y: crop?.y ?? 0,
    scale: clampScale(nextScale),
  };
}

export const IDENTITY_CROP: StudioCropOverride = { x: 0, y: 0, scale: 1 };

/**
 * Per-size crop model. Crops are keyed in a single map by either a shared base
 * key `${fieldId}` (applies to every size) or a per-size composite key
 * `${variantId}:${fieldId}` (wins for that one dimension). fieldIds never
 * contain ":" so the colon is an unambiguous delimiter.
 */
export function compositeCropKey(variantId: string, fieldId: string): string {
  return `${variantId}:${fieldId}`;
}

/** The crop that applies to `fieldId` for a size: composite-then-base. */
export function resolveCropOverride(
  crops: Record<string, StudioCropOverride>,
  fieldId: string,
  variantId?: string,
): StudioCropOverride | undefined {
  return (
    (variantId ? crops[compositeCropKey(variantId, fieldId)] : undefined) ??
    crops[fieldId]
  );
}

/**
 * Where an on-canvas edit is written: the per-size composite key when in
 * per-size mode (and a variant is known), otherwise the shared base key.
 */
export function cropWriteKeyFor(
  fieldId: string,
  variantId: string | undefined,
  perSizeCrop: boolean,
): string {
  return perSizeCrop && variantId
    ? compositeCropKey(variantId, fieldId)
    : fieldId;
}

/** True when a field has a base crop OR any per-size override. */
export function fieldHasCrop(
  crops: Record<string, StudioCropOverride>,
  fieldId: string,
): boolean {
  const suffix = `:${fieldId}`;
  return (
    fieldId in crops || Object.keys(crops).some((k) => k.endsWith(suffix))
  );
}

/** Remove a field's base crop and every per-size override for it. */
export function clearFieldCrops(
  crops: Record<string, StudioCropOverride>,
  fieldId: string,
): Record<string, StudioCropOverride> {
  const suffix = `:${fieldId}`;
  const next: Record<string, StudioCropOverride> = {};
  for (const [k, v] of Object.entries(crops)) {
    if (k === fieldId || k.endsWith(suffix)) continue;
    next[k] = v;
  }
  return next;
}

/** Count of per-size overrides set for a field (excludes the base crop). */
export function perSizeCropCount(
  crops: Record<string, StudioCropOverride>,
  fieldId: string,
): number {
  const suffix = `:${fieldId}`;
  return Object.keys(crops).filter((k) => k.endsWith(suffix)).length;
}
