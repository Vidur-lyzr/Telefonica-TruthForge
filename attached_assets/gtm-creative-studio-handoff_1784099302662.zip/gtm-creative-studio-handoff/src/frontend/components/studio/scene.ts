/**
 * Creative Studio scene helpers — token resolution, asset/render URL builders,
 * layer value resolution and layer factory helpers shared by the editor,
 * thumbnails and the export pipeline.
 */
import type {
  StudioAnimationClip,
  StudioEasing,
  StudioImageLayer,
  StudioLayer,
  StudioRectLayer,
  StudioScene,
  StudioTextLayer,
} from "./types";
import { EMBER_DISPLAY } from "@/lib/brand-fonts";

const BASE = import.meta.env.BASE_URL || "/";

/** Same-origin URL for an uploaded asset file (so Konva export won't taint). */
export function assetFileUrl(fileName: string): string {
  return `${BASE}api/studio/assets/file/${fileName}`;
}

/** Same-origin URL for a persisted render file. */
export function renderFileUrl(fileName: string): string {
  return `${BASE}api/studio/renders/file/${fileName}`;
}

/** Zip-export download URL for every stored render of a feed. */
export function feedExportUrl(feedId: string): string {
  return `${BASE}api/studio/renders/export?feedId=${encodeURIComponent(feedId)}`;
}

// Amazon Ember Display is the real self-hosted brand face (registered at startup
// via the FontFace API); self-hosted "Open Sans" is the only true fallback. The
// plain "Amazon Ember" family is NOT in the bundle, so it must not lead the stack.
export const STUDIO_FONT_FAMILY = `"${EMBER_DISPLAY}", "Open Sans", Arial, sans-serif`;

export const STUDIO_BRAND = {
  navy: "#161E2D",
  blue: "#0972D3",
  // Amazon Orange is reserved for the AWS Smile logo ONLY — never a CTA/accent
  // fill. New rectangles default to AWS Interactive Blue (`STUDIO_BRAND.blue`).
  orange: "#FF9900",
  ink: "#0B1F33",
  paper: "#FFFFFF",
} as const;

/** Replace %field_id% tokens with the creative row's values. */
export function resolveTokens(
  text: string,
  values: Record<string, string>,
): string {
  return text.replace(/%([a-z][a-z0-9_]*)%/g, (_m, key: string) => {
    const v = values[key];
    return typeof v === "string" && v.length > 0 ? v : "";
  });
}

/** Final display text for a text layer: bound field value wins, then static. */
export function resolveLayerText(
  layer: StudioTextLayer,
  values: Record<string, string>,
): string {
  const bound =
    layer.fieldId && values[layer.fieldId] != null && values[layer.fieldId] !== ""
      ? values[layer.fieldId]
      : undefined;
  const raw = bound ?? layer.text ?? "";
  const resolved = resolveTokens(raw, values);
  return layer.upper ? resolved.toUpperCase() : resolved;
}

/** Asset id to draw for an image layer: bound field value wins, then default. */
export function resolveLayerAssetId(
  layer: StudioImageLayer,
  values: Record<string, string>,
): string | undefined {
  if (layer.fieldId) {
    const v = values[layer.fieldId];
    if (v) return v;
  }
  return layer.assetId;
}

/** Merge a creative row's values over the template's schema defaults. */
export function mergeValues(
  defaults: Record<string, string>,
  rowValues: Record<string, string>,
): Record<string, string> {
  const out: Record<string, string> = { ...defaults };
  for (const [k, v] of Object.entries(rowValues)) {
    if (v != null && v !== "") out[k] = v;
  }
  return out;
}

let layerSeq = 0;
function lid(prefix: string): string {
  layerSeq += 1;
  return `ly_${Date.now().toString(36)}_${layerSeq}_${Math.random()
    .toString(36)
    .slice(2, 6)}`;
}

export function makeTextLayer(partial: Partial<StudioTextLayer> = {}): StudioTextLayer {
  return {
    id: lid("tx"),
    name: partial.name ?? "Text",
    type: "text",
    x: partial.x ?? 24,
    y: partial.y ?? 24,
    w: partial.w ?? 240,
    h: partial.h ?? 64,
    text: partial.text ?? "Text",
    fontSize: partial.fontSize ?? 28,
    fontWeight: partial.fontWeight ?? 700,
    lineHeight: partial.lineHeight ?? 1.1,
    color: partial.color ?? STUDIO_BRAND.paper,
    align: partial.align ?? "left",
    valign: partial.valign ?? "top",
    ...partial,
  };
}

export function makeImageLayer(
  partial: Partial<StudioImageLayer> = {},
): StudioImageLayer {
  return {
    id: lid("im"),
    name: partial.name ?? "Image",
    type: "image",
    imageKind: partial.imageKind ?? "image",
    x: partial.x ?? 0,
    y: partial.y ?? 0,
    w: partial.w ?? 200,
    h: partial.h ?? 200,
    fit: partial.fit ?? "cover",
    ...partial,
  };
}

export function makeRectLayer(partial: Partial<StudioRectLayer> = {}): StudioRectLayer {
  return {
    id: lid("rc"),
    name: partial.name ?? "Rectangle",
    type: "rect",
    x: partial.x ?? 0,
    y: partial.y ?? 0,
    w: partial.w ?? 120,
    h: partial.h ?? 48,
    fill: partial.fill ?? STUDIO_BRAND.blue,
    ...partial,
  };
}

/** Clone a layer with a fresh id (for editor duplicate). */
export function cloneLayer(layer: StudioLayer): StudioLayer {
  return { ...structuredClone(layer), id: lid("cp"), name: `${layer.name} copy` };
}

/* ------------------------------- animation ------------------------------- */

/** Default scene duration (ms) when a dynamic timeline is first enabled. */
export const STUDIO_DEFAULT_DURATION_MS = 4000;
export const STUDIO_DEFAULT_FPS = 24;
/** Default slide distance (px) and pop start-scale when a clip omits from/to. */
const DEFAULT_SLIDE_PX = 64;
const DEFAULT_POP_SCALE = 0.6;
const DEFAULT_PULSE_PEAK = 1.08;

function clamp01n(n: number): number {
  return Math.max(0, Math.min(1, n));
}

function ease(p: number, kind?: StudioEasing): number {
  const t = clamp01n(p);
  switch (kind) {
    case "easeIn":
      return t * t;
    case "easeOut":
      return 1 - (1 - t) * (1 - t);
    case "easeInOut":
      return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
    case "linear":
    default:
      return t;
  }
}

/** Resolved per-frame transform applied on top of a layer's resting state. */
export interface LayerAnimState {
  opacity: number;
  dx: number;
  dy: number;
  scale: number;
}

const REST: LayerAnimState = { opacity: 1, dx: 0, dy: 0, scale: 1 };

function slideOffset(
  clip: StudioAnimationClip,
  dist: number,
): { x: number; y: number } {
  const d = clip.direction ?? "left";
  if (d === "left") return { x: -dist, y: 0 };
  if (d === "right") return { x: dist, y: 0 };
  if (d === "up") return { x: 0, y: -dist };
  return { x: 0, y: dist };
}

/**
 * Evaluate the combined animation transform for a single layer at time `t` (ms).
 * Returns the resting state (no change) when the layer has no clips. Multiple
 * clips compose: opacity multiplies, translation adds, scale multiplies. The
 * caller applies this on top of the layer's own opacity / position so STATIC
 * scenes (no clips, or no frameMs) render exactly as before.
 */
export function evalLayerAnimation(
  layer: StudioLayer,
  t: number,
): LayerAnimState {
  const clips = layer.animation?.clips;
  if (!clips || clips.length === 0) return REST;
  let opacity = 1;
  let dx = 0;
  let dy = 0;
  let scale = 1;
  for (const clip of clips) {
    const start = clip.startMs;
    const end = clip.startMs + Math.max(1, clip.durationMs);
    const raw = (t - start) / Math.max(1, clip.durationMs);
    const before = t < start;
    const after = t >= end;
    const p = ease(raw, clip.easing);
    switch (clip.type) {
      case "fadeIn":
        opacity *= before ? 0 : after ? 1 : p;
        break;
      case "fadeOut":
        opacity *= before ? 1 : after ? 0 : 1 - p;
        break;
      case "slideIn": {
        const off = slideOffset(clip, clip.from ?? DEFAULT_SLIDE_PX);
        const k = before ? 1 : after ? 0 : 1 - p;
        dx += off.x * k;
        dy += off.y * k;
        break;
      }
      case "slideOut": {
        const off = slideOffset(clip, clip.to ?? DEFAULT_SLIDE_PX);
        const k = before ? 0 : after ? 1 : p;
        dx += off.x * k;
        dy += off.y * k;
        break;
      }
      case "popIn": {
        const fromS = clip.from ?? DEFAULT_POP_SCALE;
        scale *= before ? fromS : after ? 1 : fromS + (1 - fromS) * p;
        break;
      }
      case "pulse": {
        const peak = clip.to ?? DEFAULT_PULSE_PEAK;
        const amp = peak - 1;
        scale *=
          before || after ? 1 : 1 + amp * Math.sin(clamp01n(raw) * Math.PI * 2);
        break;
      }
    }
  }
  return { opacity: clamp01n(opacity), dx, dy, scale };
}

/** Whether a scene carries an animation timeline (⇒ dynamic playback). */
export function isAnimatedScene(scene: StudioScene): boolean {
  if (!scene.timeline) return false;
  return scene.layers.some((l) => (l.animation?.clips?.length ?? 0) > 0);
}

/** Total timeline duration (ms); 0 when the scene is static. */
export function sceneDurationMs(scene: StudioScene): number {
  return scene.timeline?.durationMs ?? 0;
}

/** Frame (ms) at which a static poster / thumbnail is sampled. */
export function effectiveCaptureMs(scene: StudioScene): number {
  return scene.timeline?.captureMs ?? 0;
}
