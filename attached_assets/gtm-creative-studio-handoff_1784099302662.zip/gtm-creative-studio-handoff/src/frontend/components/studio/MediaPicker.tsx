/**
 * Creative Studio — reusable media picker modal. Lists studio assets (optionally
 * filtered to a single kind), supports search, and calls `onPick(assetId)` when
 * an asset is chosen. Used by the asset library and, later, the feeds editor.
 */
import { useEffect, useMemo, useState } from "react";
import { Search, X, ImageOff, Sparkles } from "lucide-react";
import { useAssets } from "@/lib/studio-api";
import { assetFileUrl } from "@/components/studio/scene";
import type { StudioAsset, StudioAssetKind } from "@/components/studio/types";

const CHECKER: React.CSSProperties = {
  backgroundImage:
    "linear-gradient(45deg, rgba(0,0,0,0.06) 25%, transparent 25%), linear-gradient(-45deg, rgba(0,0,0,0.06) 25%, transparent 25%), linear-gradient(45deg, transparent 75%, rgba(0,0,0,0.06) 75%), linear-gradient(-45deg, transparent 75%, rgba(0,0,0,0.06) 75%)",
  backgroundSize: "14px 14px",
  backgroundPosition: "0 0, 0 7px, 7px -7px, -7px 0",
};

export function MediaPicker({
  open,
  onClose,
  onPick,
  kind,
  title = "Select media",
  suggestedIds,
}: {
  open: boolean;
  onClose: () => void;
  onPick: (assetId: string) => void;
  kind?: StudioAssetKind;
  title?: string;
  suggestedIds?: string[];
}) {
  const { data: assets = [], isLoading } = useAssets();
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return assets.filter((a) => {
      if (kind && a.kind !== kind) return false;
      if (!q) return true;
      return (
        a.originalName.toLowerCase().includes(q) ||
        a.tags.some((t) => t.toLowerCase().includes(q))
      );
    });
  }, [assets, kind, query]);

  // Resolve suggestions to real assets (preserve given order), shown only when
  // the user has not started searching so they stay a clear default starting point.
  const suggested = useMemo(() => {
    if (!suggestedIds?.length) return [];
    const byId = new Map(assets.map((a) => [a.id, a]));
    return suggestedIds
      .map((id) => byId.get(id))
      .filter((a): a is StudioAsset => !!a && (!kind || a.kind === kind));
  }, [assets, kind, suggestedIds]);
  const showSuggested = suggested.length > 0 && query.trim() === "";

  // Reset search each time the picker opens so suggestions are always the
  // prominent starting point for a fresh slot, not hidden behind a stale query.
  useEffect(() => {
    if (open) setQuery("");
  }, [open]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      onClick={onClose}
      data-testid="media-picker-overlay"
    >
      <div
        className="flex max-h-[80vh] w-[760px] max-w-[94vw] flex-col border border-card-border bg-card"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex flex-shrink-0 items-center gap-3 border-b border-card-border px-4 py-3">
          <h2 className="text-[13px] font-semibold text-foreground">{title}</h2>
          <span className="text-[11.5px] text-muted-foreground">
            {filtered.length} {filtered.length === 1 ? "asset" : "assets"}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="ml-auto flex h-7 w-7 items-center justify-center text-muted-foreground hover:text-foreground"
            data-testid="media-picker-close"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Search */}
        <div className="flex-shrink-0 border-b border-card-border px-4 py-2.5">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name or tag…"
              className="w-full border border-card-border bg-background py-1.5 pl-8 pr-3 text-[12.5px] text-foreground placeholder:text-muted-foreground focus:border-[hsl(var(--primary))] focus:outline-none"
              data-testid="media-picker-search"
            />
          </div>
        </div>

        {/* Body */}
        <div className="min-h-0 flex-1 overflow-auto p-4">
          {showSuggested && (
            <div className="mb-4 border border-[hsl(var(--primary))]/25 bg-[hsl(var(--primary))]/[0.04] p-3">
              <div className="mb-2 flex items-center gap-1.5">
                <Sparkles className="h-3.5 w-3.5 text-[hsl(var(--primary))]" />
                <span className="text-[11px] font-semibold uppercase tracking-wide text-[hsl(var(--primary))]">
                  Suggested for this slot
                </span>
                <span className="text-[10.5px] text-muted-foreground">
                  {suggested.length}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4">
                {suggested.map((a) => (
                  <PickerCard
                    key={a.id}
                    asset={a}
                    onPick={() => {
                      onPick(a.id);
                      onClose();
                    }}
                  />
                ))}
              </div>
            </div>
          )}
          {isLoading ? (
            <div className="py-12 text-center text-[12.5px] text-muted-foreground">
              Loading assets…
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-12 text-center">
              <ImageOff className="h-6 w-6 text-muted-foreground" />
              <div className="text-[12.5px] text-muted-foreground">
                No matching assets.
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4">
              {filtered.map((a) => (
                <PickerCard
                  key={a.id}
                  asset={a}
                  onPick={() => {
                    onPick(a.id);
                    onClose();
                  }}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function PickerCard({
  asset,
  onPick,
}: {
  asset: StudioAsset;
  onPick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onPick}
      className="group flex flex-col border border-card-border bg-card text-left transition-colors hover:border-[hsl(var(--primary))]"
      data-testid={`media-picker-item-${asset.id}`}
    >
      <div
        className="flex aspect-[4/3] items-center justify-center bg-muted p-2"
        style={CHECKER}
      >
        <img
          src={assetFileUrl(asset.fileName)}
          crossOrigin="anonymous"
          alt={asset.originalName}
          className="max-h-full max-w-full object-contain"
          loading="lazy"
        />
      </div>
      <div className="min-w-0 px-2 py-1.5">
        <div className="truncate text-[11.5px] font-medium text-foreground">
          {asset.originalName}
        </div>
        <div className="mt-0.5 text-[10.5px] text-muted-foreground">
          {asset.width ?? "?"}×{asset.height ?? "?"} · {asset.ext.toUpperCase()}
        </div>
      </div>
    </button>
  );
}

export default MediaPicker;
