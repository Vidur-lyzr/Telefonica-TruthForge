/**
 * Creative Studio — offscreen render queue. Mounts ONE StudioKonva stage at a
 * time at full resolution (scale = 1), waits for its images to settle, then
 * produces every requested output format from the live Konva stage:
 *
 *   - static (png / jpg / webp): a single stage.toDataURL() bitmap. For an
 *     animated scene the still is captured at the timeline's `captureMs` poster
 *     frame; for a plain static scene behaviour is unchanged (resting state).
 *   - gif: N animation frames captured by stepping `frameMs` across the
 *     timeline, quantised per-frame and encoded to a real looping GIF (gifenc).
 *   - html5: the same frames baked into a self-contained, dependency-free HTML
 *     document that replays them in any browser.
 *
 * Each spec is handled by its own <SpecCapture> (remounted per spec via `key`)
 * so its capture state machine starts clean. Capture is gated on StudioKonva's
 * `onReady` so exports are never blank or partial, and each frame waits two
 * RAFs so Konva has flushed the draw before we read pixels. The stage lives
 * off-screen (not display:none, which would zero its size) so Konva still
 * rasterises it.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import type Konva from "konva";
import { GIFEncoder, quantize, applyPalette } from "gifenc";
import StudioKonva from "./StudioKonva";
import type {
  StudioAsset,
  StudioCropOverride,
  StudioStyleOverride,
  StudioScene,
} from "./types";
import {
  STUDIO_DYNAMIC_FORMATS,
  STUDIO_STATIC_FORMATS,
} from "./types";
import {
  STUDIO_DEFAULT_FPS,
  effectiveCaptureMs,
  isAnimatedScene,
  sceneDurationMs,
} from "./scene";
import type { RenderUploadItem } from "@/lib/studio-api";

export interface RenderSpec {
  rowId: string;
  variantId: string;
  width: number;
  height: number;
  scene: StudioScene;
  values: Record<string, string>;
  crops?: Record<string, StudioCropOverride>;
  styleOverrides?: Record<string, StudioStyleOverride>;
  formats: string[];
}

const STATIC_SET = new Set<string>(STUDIO_STATIC_FORMATS);
const DYNAMIC_SET = new Set<string>(STUDIO_DYNAMIC_FORMATS);

/** Upper bound on captured frames per animated render (memory + GIF size). */
const MAX_CAPTURE_FRAMES = 30;
/** Cap the capture frame-rate so exports stay light regardless of design fps. */
const MAX_CAPTURE_FPS = 20;

function mimeFor(format: string): string {
  const f = format.toLowerCase();
  if (f === "jpg" || f === "jpeg") return "image/jpeg";
  if (f === "webp") return "image/webp";
  return "image/png";
}

/** Uint8Array → base64 (chunked to stay under the call-stack arg limit). */
function bytesToBase64(bytes: Uint8Array): string {
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}

/** UTF-8 safe string → base64 for the html5 data URL. */
function textToBase64(text: string): string {
  return btoa(unescape(encodeURIComponent(text)));
}

/** Frame playhead times (ms) to sample across an animated scene. */
function frameTimesFor(scene: StudioScene): number[] {
  const duration = Math.max(1, sceneDurationMs(scene));
  const fps = Math.min(scene.timeline?.fps ?? STUDIO_DEFAULT_FPS, MAX_CAPTURE_FPS);
  const n = Math.max(
    2,
    Math.min(MAX_CAPTURE_FRAMES, Math.round((duration / 1000) * fps)),
  );
  const step = duration / n;
  return Array.from({ length: n }, (_, i) => Math.round(i * step));
}

/** Self-contained looping flipbook HTML that replays captured PNG frames. */
function buildHtml5(
  frames: string[],
  width: number,
  height: number,
  delayMs: number,
): string {
  // Frames are embedded as data URLs; a tiny script swaps <img src> on a timer.
  const json = JSON.stringify(frames);
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Creative replay ${width}x${height}</title>
<style>
  html,body{margin:0;background:#0b0f14;height:100%;}
  .wrap{display:flex;align-items:center;justify-content:center;min-height:100%;}
  img{max-width:100%;height:auto;display:block;image-rendering:auto;}
</style>
</head>
<body>
<div class="wrap"><img id="frame" width="${width}" height="${height}" alt="creative" /></div>
<script>
(function(){
  var frames = ${json};
  var delay = ${Math.max(20, Math.round(delayMs))};
  var el = document.getElementById('frame');
  var i = 0;
  if(!frames.length){return;}
  function tick(){ el.src = frames[i]; i = (i + 1) % frames.length; setTimeout(tick, delay); }
  tick();
})();
</script>
</body>
</html>`;
}

/** Split a spec's requested formats into the static and dynamic subsets. */
function splitFormats(formats: string[]): {
  staticFormats: string[];
  dynamicFormats: string[];
} {
  const staticFormats: string[] = [];
  const dynamicFormats: string[] = [];
  for (const raw of formats) {
    const f = raw.toLowerCase();
    if (STATIC_SET.has(f)) staticFormats.push(f);
    else if (DYNAMIC_SET.has(f)) dynamicFormats.push(f);
  }
  return { staticFormats, dynamicFormats };
}

type CapTask =
  | { kind: "frame"; ms: number }
  | { kind: "static"; ms: number | null }
  | { kind: "finish" };

/**
 * Captures one spec: builds an ordered task plan (animation frames → poster
 * still → finish), advances it one step per render, and reports the produced
 * upload items. Remounted per spec so its state machine is always fresh.
 */
function SpecCapture({
  spec,
  assetsById,
  onDone,
}: {
  spec: RenderSpec;
  assetsById: Record<string, StudioAsset>;
  onDone: (items: RenderUploadItem[]) => void;
}) {
  const stageRef = useRef<Konva.Stage>(null);
  const mountedRef = useRef(true);
  const rafRef = useRef<number[]>([]);
  const onDoneRef = useRef(onDone);
  onDoneRef.current = onDone;

  const { staticFormats, dynamicFormats } = useMemo(
    () => splitFormats(spec.formats),
    [spec.formats],
  );
  const animated = isAnimatedScene(spec.scene);
  const wantsDynamic = dynamicFormats.length > 0 && animated;

  // Frame times we sample for dynamic outputs; the poster still is captured at
  // the timeline's capture point for animated scenes (else resting state).
  const frameTimes = useMemo(
    () => (wantsDynamic ? frameTimesFor(spec.scene) : []),
    [wantsDynamic, spec.scene],
  );
  const posterMs = animated ? effectiveCaptureMs(spec.scene) : null;
  const delayMs = useMemo(() => {
    if (frameTimes.length < 2) return 1000;
    return Math.round(sceneDurationMs(spec.scene) / frameTimes.length);
  }, [frameTimes.length, spec.scene]);

  const plan = useMemo<CapTask[]>(() => {
    const tasks: CapTask[] = [];
    if (wantsDynamic) {
      for (const ms of frameTimes) tasks.push({ kind: "frame", ms });
    }
    if (staticFormats.length > 0) tasks.push({ kind: "static", ms: posterMs });
    tasks.push({ kind: "finish" });
    return tasks;
  }, [wantsDynamic, frameTimes, staticFormats.length, posterMs]);

  // Accumulators (refs so they survive re-renders without retriggering effects).
  const gifFramesRef = useRef<{ index: Uint8Array; palette: number[][] }[]>([]);
  const htmlFramesRef = useRef<string[]>([]);
  const staticItemsRef = useRef<RenderUploadItem[]>([]);

  const [ready, setReady] = useState(false);
  const [step, setStep] = useState(-1);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      rafRef.current.forEach((id) => cancelAnimationFrame(id));
      rafRef.current = [];
    };
  }, []);

  // Drive the task plan once images have settled. Each capture step waits two
  // RAFs so Konva has flushed the frame before we read pixels.
  useEffect(() => {
    if (!ready) return;
    if (step < 0) {
      setStep(0);
      return;
    }
    const task = plan[step];
    if (!task) return;

    if (task.kind === "finish") {
      const items: RenderUploadItem[] = [...staticItemsRef.current];
      if (dynamicFormats.includes("gif") && gifFramesRef.current.length > 0) {
        try {
          const enc = GIFEncoder();
          for (const f of gifFramesRef.current) {
            enc.writeFrame(f.index, spec.width, spec.height, {
              palette: f.palette,
              delay: delayMs,
            });
          }
          enc.finish();
          items.push({
            rowId: spec.rowId,
            variantId: spec.variantId,
            format: "gif",
            width: spec.width,
            height: spec.height,
            dataUrl: `data:image/gif;base64,${bytesToBase64(enc.bytes())}`,
          });
        } catch {
          // Encoding can fail on extreme sizes; skip GIF rather than abort.
        }
      }
      if (dynamicFormats.includes("html5") && htmlFramesRef.current.length > 0) {
        const html = buildHtml5(
          htmlFramesRef.current,
          spec.width,
          spec.height,
          delayMs,
        );
        items.push({
          rowId: spec.rowId,
          variantId: spec.variantId,
          format: "html5",
          width: spec.width,
          height: spec.height,
          dataUrl: `data:text/html;base64,${textToBase64(html)}`,
        });
      }
      onDoneRef.current(items);
      return;
    }

    const r1 = requestAnimationFrame(() => {
      const r2 = requestAnimationFrame(() => {
        if (!mountedRef.current) return;
        const stage = stageRef.current;
        if (stage) {
          try {
            if (task.kind === "frame") {
              if (dynamicFormats.includes("gif")) {
                const canvas = stage.toCanvas({ pixelRatio: 1 });
                const ctx = canvas.getContext("2d");
                if (ctx) {
                  const { data } = ctx.getImageData(
                    0,
                    0,
                    canvas.width,
                    canvas.height,
                  );
                  const palette = quantize(data, 256, { format: "rgb565" });
                  const index = applyPalette(data, palette, "rgb565");
                  gifFramesRef.current.push({ index, palette });
                }
              }
              if (dynamicFormats.includes("html5")) {
                htmlFramesRef.current.push(
                  stage.toDataURL({ pixelRatio: 1, mimeType: "image/png" }),
                );
              }
            } else {
              for (const fmt of staticFormats) {
                staticItemsRef.current.push({
                  rowId: spec.rowId,
                  variantId: spec.variantId,
                  format: fmt,
                  width: spec.width,
                  height: spec.height,
                  dataUrl: stage.toDataURL({
                    pixelRatio: 1,
                    mimeType: mimeFor(fmt),
                    quality: 0.92,
                  }),
                });
              }
            }
          } catch {
            // toDataURL/getImageData can throw on a zero-size stage; skip.
          }
        }
        setStep((s) => s + 1);
      });
      rafRef.current.push(r2);
    });
    rafRef.current.push(r1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, step]);

  // The playhead for the current step (animation frame or poster still).
  const currentTask = step >= 0 ? plan[step] : undefined;
  const frameMs =
    currentTask?.kind === "frame"
      ? currentTask.ms
      : currentTask?.kind === "static"
        ? (currentTask.ms ?? undefined)
        : posterMs ?? undefined;

  return (
    <StudioKonva
      ref={stageRef}
      scene={spec.scene}
      width={spec.width}
      height={spec.height}
      scale={1}
      values={spec.values}
      assetsById={assetsById}
      crops={spec.crops}
      variantId={spec.variantId}
      styleOverrides={spec.styleOverrides}
      frameMs={frameMs}
      onReady={() => setReady(true)}
    />
  );
}

export function StudioRenderQueue({
  specs,
  assetsById,
  onComplete,
  onProgress,
}: {
  specs: RenderSpec[];
  assetsById: Record<string, StudioAsset>;
  onComplete: (items: RenderUploadItem[]) => void;
  onProgress?: (done: number, total: number) => void;
}) {
  const [idx, setIdx] = useState(0);
  const itemsRef = useRef<RenderUploadItem[]>([]);
  const completedRef = useRef(false);

  const spec = idx < specs.length ? specs[idx] : null;

  // Fire onComplete exactly once when every spec has been captured — including
  // the empty-specs case, so callers never hang waiting for nothing.
  useEffect(() => {
    if (idx >= specs.length && !completedRef.current) {
      completedRef.current = true;
      onComplete(itemsRef.current);
    }
  }, [idx, specs.length, onComplete]);

  if (!spec) return null;

  return (
    <div
      aria-hidden
      style={{
        position: "fixed",
        left: -100000,
        top: 0,
        width: spec.width,
        height: spec.height,
        opacity: 0,
        pointerEvents: "none",
        zIndex: -1,
      }}
    >
      <SpecCapture
        key={`${spec.rowId}:${spec.variantId}:${idx}`}
        spec={spec}
        assetsById={assetsById}
        onDone={(items) => {
          itemsRef.current.push(...items);
          onProgress?.(idx + 1, specs.length);
          setIdx((i) => i + 1);
        }}
      />
    </div>
  );
}

export default StudioRenderQueue;
