/**
 * Creative Studio — agent proposal review modals (T004). Every agent endpoint
 * returns PROPOSALS that are diffed against current state and only persisted on
 * an explicit confirm via the existing row/crop/asset mutations. These modals
 * are shared between the studio pages and the StudioAgentPanel so the confirm
 * flow lives in exactly one place.
 *
 * Cloudscape light, 0px corners — no rounded-*.
 */
import {
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { Link } from "wouter";
import {
  X,
  Sparkles,
  Loader2,
  Crop as CropIcon,
  Tag as TagIcon,
  Wand2,
  AlertTriangle,
  ArrowRight,
} from "lucide-react";
import {
  useGenerateVariants,
  useFeedAutofill,
  useImproveCreative,
  useSmartCrop,
  useAutoTag,
  useAddRow,
  useUpdateRow,
  usePatchAsset,
  useAssets,
  type StudioVariantProposal,
  type StudioAutofillProposal,
  type StudioCropProposal,
} from "@/lib/studio-api";
import type {
  StudioAsset,
  StudioCreativeRow,
  StudioCropOverride,
  StudioTemplate,
  StudioVariant,
} from "@/components/studio/types";

/* --------------------------------- modal -------------------------------- */

function Modal({
  open,
  onClose,
  title,
  icon,
  children,
  footer,
  testId,
  maxWidthClass = "max-w-lg",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  icon?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  testId?: string;
  maxWidthClass?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4"
      data-testid={testId}
    >
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div
        className={`relative w-full ${maxWidthClass} border border-card-border bg-card shadow-lg max-h-[90vh] flex flex-col`}
      >
        <div className="flex items-center justify-between border-b border-card-border px-4 py-3 flex-shrink-0">
          <h3 className="text-[14px] font-semibold text-foreground inline-flex items-center gap-1.5">
            {icon}
            {title}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-agent-modal-close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4 overflow-auto">{children}</div>
        {footer && (
          <div className="flex items-center gap-2 border-t border-card-border px-4 py-3 flex-shrink-0">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

const inputCls =
  "w-full border border-card-border bg-background px-2.5 py-1.5 text-[13px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]";
const labelCls =
  "block text-[11px] uppercase tracking-wide text-muted-foreground mb-1";
const primaryBtn =
  "inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50";
const ghostBtn =
  "inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:bg-muted/40 disabled:opacity-50";

function TraceLink({ skillCallId }: { skillCallId: string | null }) {
  if (!skillCallId) return null;
  return (
    <Link
      href="/observability"
      className="text-[11.5px] text-[hsl(var(--primary))] hover:underline inline-flex items-center gap-1"
      data-testid="link-skill-trace"
      title={skillCallId}
    >
      View trace →
    </Link>
  );
}

function ErrorNote({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div
      className="flex items-start gap-1.5 border border-red-200 bg-red-50 px-2.5 py-2 text-[11.5px] text-red-700"
      data-testid="agent-error"
    >
      <AlertTriangle className="w-3.5 h-3.5 mt-px flex-shrink-0" />
      <span>{message}</span>
    </div>
  );
}

/** Display the field label + resolved value for a proposal values map. */
function ValueList({
  values,
  template,
  assetsById,
}: {
  values: Record<string, string>;
  template: StudioTemplate;
  assetsById: Record<string, StudioAsset>;
}) {
  const fieldsById = useMemo(
    () => Object.fromEntries(template.schemaFields.map((f) => [f.id, f])),
    [template],
  );
  const entries = Object.entries(values).filter(([, v]) => v != null && v !== "");
  if (entries.length === 0) {
    return <div className="text-[11.5px] text-muted-foreground">No values.</div>;
  }
  return (
    <dl className="grid grid-cols-[auto_1fr] gap-x-2 gap-y-0.5">
      {entries.map(([fieldId, value]) => {
        const field = fieldsById[fieldId];
        const isMedia = field?.type === "media";
        const display = isMedia
          ? assetsById[value]?.originalName ?? value
          : value;
        return (
          <div key={fieldId} className="contents">
            <dt className="text-[11px] text-muted-foreground truncate">
              {field?.label ?? fieldId}
            </dt>
            <dd className="text-[11.5px] text-foreground truncate" title={display}>
              {display}
            </dd>
          </div>
        );
      })}
    </dl>
  );
}

/* ----------------------- generate-with-ai (variants) ---------------------- */

export function GenerateVariantsModal({
  open,
  onClose,
  templateId,
  feedId,
  template,
  defaultLocale = "en-US",
}: {
  open: boolean;
  onClose: () => void;
  templateId: string;
  feedId: string;
  template: StudioTemplate;
  defaultLocale?: string;
}) {
  const generate = useGenerateVariants();
  const addRow = useAddRow(feedId);
  const { data: assets = [] } = useAssets();
  const assetsById = useMemo(
    () => Object.fromEntries(assets.map((a) => [a.id, a])),
    [assets],
  );

  const [brief, setBrief] = useState("");
  const [count, setCount] = useState(3);
  const [locale, setLocale] = useState(defaultLocale);
  const [proposals, setProposals] = useState<StudioVariantProposal[] | null>(
    null,
  );
  const [accepted, setAccepted] = useState<Set<number>>(new Set());
  const [skillCallId, setSkillCallId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [applying, setApplying] = useState(false);

  useEffect(() => {
    if (!open) {
      setBrief("");
      setCount(3);
      setLocale(defaultLocale);
      setProposals(null);
      setAccepted(new Set());
      setSkillCallId(null);
      setError(null);
      setApplying(false);
    }
  }, [open, defaultLocale]);

  const run = async () => {
    setError(null);
    try {
      const res = await generate.mutateAsync({
        templateId,
        feedId,
        brief: brief.trim(),
        count: Math.max(1, Math.min(12, Math.round(count))),
        locale: locale.trim() || undefined,
      });
      setProposals(res.proposals);
      setSkillCallId(res.skillCallId);
      setAccepted(new Set(res.proposals.map((_, i) => i)));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Generation failed.");
    }
  };

  const toggle = (i: number) =>
    setAccepted((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });

  const apply = async () => {
    if (!proposals) return;
    setApplying(true);
    setError(null);
    try {
      for (let i = 0; i < proposals.length; i += 1) {
        if (!accepted.has(i)) continue;
        const p = proposals[i];
        await addRow.mutateAsync({
          uid: p.uid,
          locale: p.locale,
          tags: [],
          values: p.values,
        });
      }
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not add creatives.");
    } finally {
      setApplying(false);
    }
  };

  const reviewing = !!proposals;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Generate creatives with AI"
      icon={<Sparkles className="w-4 h-4 text-[hsl(var(--primary))]" />}
      testId="modal-generate-variants"
      maxWidthClass="max-w-2xl"
      footer={
        reviewing ? (
          <>
            <TraceLink skillCallId={skillCallId} />
            <div className="ml-auto flex items-center gap-2">
              <button
                type="button"
                onClick={() => setProposals(null)}
                className={ghostBtn}
                data-testid="button-generate-back"
              >
                Back
              </button>
              <button
                type="button"
                onClick={apply}
                disabled={applying || accepted.size === 0}
                className={primaryBtn}
                data-testid="button-generate-apply"
              >
                {applying && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                Add {accepted.size} creative{accepted.size === 1 ? "" : "s"}
              </button>
            </div>
          </>
        ) : (
          <>
            <span className="text-[11.5px] text-muted-foreground">
              Proposals are reviewed before anything is added.
            </span>
            <div className="ml-auto flex items-center gap-2">
              <button type="button" onClick={onClose} className={ghostBtn}>
                Cancel
              </button>
              <button
                type="button"
                onClick={run}
                disabled={generate.isPending || !brief.trim()}
                className={primaryBtn}
                data-testid="button-generate-run"
              >
                {generate.isPending ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                Generate
              </button>
            </div>
          </>
        )
      }
    >
      {!reviewing ? (
        <div className="space-y-3">
          <ErrorNote message={error} />
          <div>
            <label className={labelCls}>Creative brief</label>
            <textarea
              autoFocus
              value={brief}
              onChange={(e) => setBrief(e.target.value)}
              rows={4}
              placeholder="e.g. 3 banner variants for FS Canada decision-makers focused on cost reduction and migration confidence."
              className={`${inputCls} resize-y`}
              data-testid="input-generate-brief"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelCls}>How many</label>
              <input
                type="number"
                min={1}
                max={12}
                value={count}
                onChange={(e) => setCount(Number(e.target.value))}
                className={inputCls}
                data-testid="input-generate-count"
              />
            </div>
            <div>
              <label className={labelCls}>Locale</label>
              <input
                value={locale}
                onChange={(e) => setLocale(e.target.value)}
                placeholder="en-US"
                className={inputCls}
                data-testid="input-generate-locale"
              />
            </div>
          </div>
          <p className="text-[11px] text-muted-foreground">
            Bound to template <span className="text-foreground">{template.name}</span>{" "}
            ({template.schemaFields.length} fields).
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          <ErrorNote message={error} />
          <div className="flex items-center justify-between">
            <p className="text-[12px] text-muted-foreground">
              {proposals.length} proposed creative
              {proposals.length === 1 ? "" : "s"} · pick which to add.
            </p>
            <div className="flex items-center gap-2 text-[11.5px]">
              <button
                type="button"
                className="text-[hsl(var(--primary))] hover:underline"
                onClick={() =>
                  setAccepted(new Set(proposals.map((_, i) => i)))
                }
                data-testid="button-generate-select-all"
              >
                Select all
              </button>
              <button
                type="button"
                className="text-muted-foreground hover:text-foreground"
                onClick={() => setAccepted(new Set())}
                data-testid="button-generate-select-none"
              >
                None
              </button>
            </div>
          </div>
          {proposals.map((p, i) => (
            <label
              key={`${p.uid}-${i}`}
              className={`block border bg-card p-3 cursor-pointer transition-colors ${
                accepted.has(i)
                  ? "border-[hsl(var(--primary))]"
                  : "border-card-border hover:border-muted-foreground/40"
              }`}
              data-testid={`proposal-variant-${i}`}
            >
              <div className="flex items-start gap-2.5">
                <input
                  type="checkbox"
                  checked={accepted.has(i)}
                  onChange={() => toggle(i)}
                  className="mt-0.5 accent-[hsl(var(--primary))]"
                  data-testid={`checkbox-proposal-${i}`}
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[12.5px] font-medium text-foreground truncate">
                      {p.uid}
                    </span>
                    <span className="text-[10px] uppercase tracking-wide border border-card-border px-1.5 py-0.5 text-muted-foreground">
                      {p.locale}
                    </span>
                  </div>
                  {p.rationale && (
                    <p className="text-[11px] text-muted-foreground mt-1">
                      {p.rationale}
                    </p>
                  )}
                  <div className="mt-2">
                    <ValueList
                      values={p.values}
                      template={template}
                      assetsById={assetsById}
                    />
                  </div>
                </div>
              </div>
            </label>
          ))}
        </div>
      )}
    </Modal>
  );
}

/* ------------------------------- autofill -------------------------------- */

export function AutofillModal({
  open,
  onClose,
  feedId,
  template,
  rows,
}: {
  open: boolean;
  onClose: () => void;
  feedId: string;
  template: StudioTemplate;
  rows: StudioCreativeRow[];
}) {
  const autofill = useFeedAutofill();
  const addRow = useAddRow(feedId);
  const updateRow = useUpdateRow(feedId);
  const { data: assets = [] } = useAssets();
  const assetsById = useMemo(
    () => Object.fromEntries(assets.map((a) => [a.id, a])),
    [assets],
  );
  const rowsById = useMemo(
    () => Object.fromEntries(rows.map((r) => [r.id, r])),
    [rows],
  );

  const [brief, setBrief] = useState("");
  const [datasetText, setDatasetText] = useState("");
  const [proposals, setProposals] = useState<StudioAutofillProposal[] | null>(
    null,
  );
  const [accepted, setAccepted] = useState<Set<number>>(new Set());
  const [skillCallId, setSkillCallId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [applying, setApplying] = useState(false);

  useEffect(() => {
    if (!open) {
      setBrief("");
      setDatasetText("");
      setProposals(null);
      setAccepted(new Set());
      setSkillCallId(null);
      setError(null);
      setApplying(false);
    }
  }, [open]);

  const run = async () => {
    setError(null);
    let dataset: Record<string, unknown>[] | undefined;
    const raw = datasetText.trim();
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed)) {
          setError("Dataset must be a JSON array of row objects.");
          return;
        }
        dataset = parsed as Record<string, unknown>[];
      } catch {
        setError("Dataset isn't valid JSON.");
        return;
      }
    }
    try {
      const res = await autofill.mutateAsync({
        feedId,
        brief: brief.trim() || undefined,
        dataset,
      });
      setProposals(res.proposals);
      setSkillCallId(res.skillCallId);
      setAccepted(new Set(res.proposals.map((_, i) => i)));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Autofill failed.");
    }
  };

  const toggle = (i: number) =>
    setAccepted((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });

  const apply = async () => {
    if (!proposals) return;
    setApplying(true);
    setError(null);
    try {
      for (let i = 0; i < proposals.length; i += 1) {
        if (!accepted.has(i)) continue;
        const p = proposals[i];
        if (p.rowId && rowsById[p.rowId]) {
          const existing = rowsById[p.rowId];
          await updateRow.mutateAsync({
            rowId: p.rowId,
            uid: p.uid,
            locale: p.locale,
            values: { ...existing.values, ...p.values },
          });
        } else {
          await addRow.mutateAsync({
            uid: p.uid,
            locale: p.locale,
            tags: [],
            values: p.values,
          });
        }
      }
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not apply autofill.");
    } finally {
      setApplying(false);
    }
  };

  const reviewing = !!proposals;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Autofill feed with AI"
      icon={<Wand2 className="w-4 h-4 text-[hsl(var(--primary))]" />}
      testId="modal-autofill"
      maxWidthClass="max-w-2xl"
      footer={
        reviewing ? (
          <>
            <TraceLink skillCallId={skillCallId} />
            <div className="ml-auto flex items-center gap-2">
              <button
                type="button"
                onClick={() => setProposals(null)}
                className={ghostBtn}
                data-testid="button-autofill-back"
              >
                Back
              </button>
              <button
                type="button"
                onClick={apply}
                disabled={applying || accepted.size === 0}
                className={primaryBtn}
                data-testid="button-autofill-apply"
              >
                {applying && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                Apply {accepted.size} change{accepted.size === 1 ? "" : "s"}
              </button>
            </div>
          </>
        ) : (
          <>
            <span className="text-[11.5px] text-muted-foreground">
              Updates and new rows are reviewed before writing.
            </span>
            <div className="ml-auto flex items-center gap-2">
              <button type="button" onClick={onClose} className={ghostBtn}>
                Cancel
              </button>
              <button
                type="button"
                onClick={run}
                disabled={autofill.isPending}
                className={primaryBtn}
                data-testid="button-autofill-run"
              >
                {autofill.isPending ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Wand2 className="w-3.5 h-3.5" />
                )}
                Autofill
              </button>
            </div>
          </>
        )
      }
    >
      {!reviewing ? (
        <div className="space-y-3">
          <ErrorNote message={error} />
          <div>
            <label className={labelCls}>Brief (optional)</label>
            <textarea
              value={brief}
              onChange={(e) => setBrief(e.target.value)}
              rows={3}
              placeholder="Fill empty fields and tighten copy for a financial-services audience."
              className={`${inputCls} resize-y`}
              data-testid="input-autofill-brief"
            />
          </div>
          <div>
            <label className={labelCls}>Dataset JSON (optional)</label>
            <textarea
              value={datasetText}
              onChange={(e) => setDatasetText(e.target.value)}
              rows={4}
              placeholder='[{ "uid": "acme", "headline": "Cut costs by 30%" }]'
              className={`${inputCls} resize-y font-mono text-[11.5px]`}
              data-testid="input-autofill-dataset"
            />
            <p className="text-[11px] text-muted-foreground mt-1">
              Provide a row-per-record dataset, or leave empty to let the agent
              draft values from the brief.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-2.5">
          <ErrorNote message={error} />
          <p className="text-[12px] text-muted-foreground">
            {proposals.length} proposed change
            {proposals.length === 1 ? "" : "s"} · pick which to apply.
          </p>
          {proposals.map((p, i) => {
            const existing = p.rowId ? rowsById[p.rowId] : undefined;
            const isUpdate = !!existing;
            return (
              <label
                key={`${p.uid}-${i}`}
                className={`block border bg-card p-3 cursor-pointer transition-colors ${
                  accepted.has(i)
                    ? "border-[hsl(var(--primary))]"
                    : "border-card-border hover:border-muted-foreground/40"
                }`}
                data-testid={`proposal-autofill-${i}`}
              >
                <div className="flex items-start gap-2.5">
                  <input
                    type="checkbox"
                    checked={accepted.has(i)}
                    onChange={() => toggle(i)}
                    className="mt-0.5 accent-[hsl(var(--primary))]"
                    data-testid={`checkbox-autofill-${i}`}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[12.5px] font-medium text-foreground truncate">
                        {p.uid}
                      </span>
                      <span
                        className={`text-[10px] uppercase tracking-wide px-1.5 py-0.5 ${
                          isUpdate
                            ? "bg-amber-100 text-amber-800"
                            : "bg-emerald-100 text-emerald-800"
                        }`}
                      >
                        {isUpdate ? "Update" : "New"}
                      </span>
                      <span className="text-[10px] uppercase tracking-wide border border-card-border px-1.5 py-0.5 text-muted-foreground">
                        {p.source}
                      </span>
                    </div>
                    <div className="mt-2">
                      <ValueList
                        values={p.values}
                        template={template}
                        assetsById={assetsById}
                      />
                    </div>
                  </div>
                </div>
              </label>
            );
          })}
        </div>
      )}
    </Modal>
  );
}

/* -------------------------- improve one creative -------------------------- */

export function ImproveCreativeModal({
  open,
  onClose,
  feedId,
  template,
  row,
}: {
  open: boolean;
  onClose: () => void;
  feedId: string;
  template: StudioTemplate;
  row: StudioCreativeRow;
}) {
  const improve = useImproveCreative();
  const updateRow = useUpdateRow(feedId);
  const fieldsById = useMemo(
    () => Object.fromEntries(template.schemaFields.map((f) => [f.id, f])),
    [template],
  );

  const [instruction, setInstruction] = useState("");
  const [values, setValues] = useState<Record<string, string> | null>(null);
  const [accepted, setAccepted] = useState<Set<string>>(new Set());
  const [skillCallId, setSkillCallId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [applying, setApplying] = useState(false);

  useEffect(() => {
    if (!open) {
      setInstruction("");
      setValues(null);
      setAccepted(new Set());
      setSkillCallId(null);
      setError(null);
      setApplying(false);
    }
  }, [open]);

  const run = async () => {
    setError(null);
    try {
      const res = await improve.mutateAsync({
        feedId,
        rowId: row.id,
        instruction: instruction.trim() || undefined,
      });
      const next = res.proposal.values ?? {};
      setValues(next);
      setSkillCallId(res.skillCallId);
      setAccepted(new Set(Object.keys(next)));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Improve failed.");
    }
  };

  const toggle = (fid: string) =>
    setAccepted((prev) => {
      const next = new Set(prev);
      if (next.has(fid)) next.delete(fid);
      else next.add(fid);
      return next;
    });

  const apply = async () => {
    if (!values) return;
    setApplying(true);
    setError(null);
    try {
      const patch: Record<string, string> = {};
      for (const fid of accepted) patch[fid] = values[fid];
      // Send only the accepted fields — the server merges values, so a full
      // merged map built from a stale `row.values` snapshot could overwrite a
      // concurrent edit to a field the user did not change here.
      await updateRow.mutateAsync({
        rowId: row.id,
        values: patch,
      });
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not apply changes.");
    } finally {
      setApplying(false);
    }
  };

  const entries = values ? Object.entries(values) : [];
  const reviewing = !!values;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Improve this creative with AI"
      icon={<Sparkles className="w-4 h-4 text-[hsl(var(--primary))]" />}
      testId="modal-improve-creative"
      maxWidthClass="max-w-2xl"
      footer={
        reviewing ? (
          <>
            <TraceLink skillCallId={skillCallId} />
            <div className="ml-auto flex items-center gap-2">
              <button
                type="button"
                onClick={() => setValues(null)}
                className={ghostBtn}
                data-testid="button-improve-back"
              >
                Back
              </button>
              <button
                type="button"
                onClick={apply}
                disabled={applying || accepted.size === 0}
                className={primaryBtn}
                data-testid="button-improve-apply"
              >
                {applying && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                Apply {accepted.size} change{accepted.size === 1 ? "" : "s"}
              </button>
            </div>
          </>
        ) : (
          <>
            <span className="text-[11.5px] text-muted-foreground">
              Changes are reviewed before writing to this creative.
            </span>
            <div className="ml-auto flex items-center gap-2">
              <button type="button" onClick={onClose} className={ghostBtn}>
                Cancel
              </button>
              <button
                type="button"
                onClick={run}
                disabled={improve.isPending}
                className={primaryBtn}
                data-testid="button-improve-run"
              >
                {improve.isPending ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                Improve copy
              </button>
            </div>
          </>
        )
      }
    >
      {!reviewing ? (
        <div className="space-y-3">
          <ErrorNote message={error} />
          <p className="text-[12px] text-muted-foreground">
            The agent refines the copy for{" "}
            <span className="font-medium text-foreground">{row.uid}</span> only.
            Add optional guidance to steer tone or emphasis.
          </p>
          <div>
            <label className={labelCls}>Guidance (optional)</label>
            <textarea
              value={instruction}
              onChange={(e) => setInstruction(e.target.value)}
              rows={3}
              placeholder="Make the headline punchier and lead with the ROI stat."
              className={`${inputCls} resize-y`}
              data-testid="input-improve-instruction"
            />
          </div>
        </div>
      ) : (
        <div className="space-y-2.5">
          <ErrorNote message={error} />
          {entries.length === 0 ? (
            <p className="text-[12px] text-muted-foreground">
              The agent didn't suggest any copy changes for this creative.
            </p>
          ) : (
            <>
              <p className="text-[12px] text-muted-foreground">
                {entries.length} proposed change
                {entries.length === 1 ? "" : "s"} · pick which to apply.
              </p>
              {entries.map(([fid, after]) => {
                const before = row.values[fid] ?? "";
                const label = fieldsById[fid]?.label ?? fid;
                return (
                  <label
                    key={fid}
                    className={`block border bg-card p-3 cursor-pointer transition-colors ${
                      accepted.has(fid)
                        ? "border-[hsl(var(--primary))]"
                        : "border-card-border hover:border-muted-foreground/40"
                    }`}
                    data-testid={`proposal-improve-${fid}`}
                  >
                    <div className="flex items-start gap-2.5">
                      <input
                        type="checkbox"
                        checked={accepted.has(fid)}
                        onChange={() => toggle(fid)}
                        className="mt-0.5 accent-[hsl(var(--primary))]"
                        data-testid={`checkbox-improve-${fid}`}
                      />
                      <div className="min-w-0 flex-1">
                        <div className="text-[11px] uppercase tracking-wide text-muted-foreground">
                          {label}
                        </div>
                        <div className="mt-1.5 space-y-1">
                          {before && (
                            <div className="text-[11.5px] text-muted-foreground line-through">
                              {before}
                            </div>
                          )}
                          <div className="flex items-start gap-1.5 text-[12.5px] text-foreground">
                            <ArrowRight className="w-3.5 h-3.5 mt-0.5 flex-shrink-0 text-[hsl(var(--primary))]" />
                            <span>{after}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </label>
                );
              })}
            </>
          )}
        </div>
      )}
    </Modal>
  );
}

/* ------------------------------ smart crop ------------------------------- */

export function SmartCropModal({
  open,
  onClose,
  templateId,
  fieldId,
  fieldLabel,
  assetId,
  variants,
  onApply,
}: {
  open: boolean;
  onClose: () => void;
  templateId: string;
  fieldId: string;
  fieldLabel: string;
  assetId: string;
  variants: StudioVariant[];
  onApply: (crop: StudioCropOverride) => void;
}) {
  const smartCrop = useSmartCrop();
  const variantsById = useMemo(
    () => Object.fromEntries(variants.map((v) => [v.id, v])),
    [variants],
  );

  const [proposals, setProposals] = useState<StudioCropProposal[] | null>(null);
  const [skillCallId, setSkillCallId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) {
      setProposals(null);
      setSkillCallId(null);
      setError(null);
    }
  }, [open]);

  const run = async () => {
    setError(null);
    if (!assetId) {
      setError("Pick a source image for this field first.");
      return;
    }
    try {
      const res = await smartCrop.mutateAsync({
        templateId,
        assetId,
        fieldId,
        variantIds: variants.map((v) => v.id),
      });
      setProposals(res.proposals);
      setSkillCallId(res.skillCallId);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Smart-crop failed.");
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={`Suggest crops · ${fieldLabel}`}
      icon={<CropIcon className="w-4 h-4 text-[hsl(var(--primary))]" />}
      testId="modal-smart-crop"
      maxWidthClass="max-w-lg"
      footer={
        <>
          <TraceLink skillCallId={skillCallId} />
          <div className="ml-auto flex items-center gap-2">
            <button type="button" onClick={onClose} className={ghostBtn}>
              Close
            </button>
            <button
              type="button"
              onClick={run}
              disabled={smartCrop.isPending || !assetId}
              className={primaryBtn}
              data-testid="button-smart-crop-run"
            >
              {smartCrop.isPending ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <CropIcon className="w-3.5 h-3.5" />
              )}
              {proposals ? "Re-run" : "Suggest crops"}
            </button>
          </div>
        </>
      }
    >
      <div className="space-y-2.5">
        <ErrorNote message={error} />
        <p className="text-[11.5px] text-muted-foreground">
          The editor stores one focal crop per field that applies to every
          cover-fit dimension. Apply the suggestion that frames the subject best.
        </p>
        {!proposals ? (
          <div className="border border-dashed border-card-border bg-muted/30 p-6 text-center text-[12px] text-muted-foreground">
            Run smart-crop to get focal suggestions across{" "}
            {variants.length} dimension{variants.length === 1 ? "" : "s"}.
          </div>
        ) : proposals.length === 0 ? (
          <div className="border border-dashed border-card-border bg-muted/30 p-6 text-center text-[12px] text-muted-foreground">
            No crop suggestions returned.
          </div>
        ) : (
          <div className="space-y-2">
            {proposals.map((p, i) => {
              const v = variantsById[p.variantId];
              return (
                <div
                  key={p.cropKey || `${p.variantId}-${i}`}
                  className="flex items-center gap-3 border border-card-border bg-card p-2.5"
                  data-testid={`proposal-crop-${i}`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="text-[12.5px] font-medium text-foreground truncate">
                      {v ? v.name : p.variantId}
                      {v && (
                        <span className="ml-1.5 text-[11px] text-muted-foreground tabular-nums">
                          {v.width}×{v.height}
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-muted-foreground tabular-nums">
                      x {p.x.toFixed(2)} · y {p.y.toFixed(2)} · zoom{" "}
                      {p.scale.toFixed(2)}
                    </div>
                    {p.rationale && (
                      <div className="text-[11px] text-muted-foreground mt-0.5">
                        {p.rationale}
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onApply({ x: p.x, y: p.y, scale: p.scale });
                      onClose();
                    }}
                    className={primaryBtn}
                    data-testid={`button-apply-crop-${i}`}
                  >
                    Apply <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </Modal>
  );
}

/* ------------------------------- auto tag -------------------------------- */

export function AutoTagModal({
  open,
  onClose,
  asset,
}: {
  open: boolean;
  onClose: () => void;
  asset: StudioAsset;
}) {
  const autoTag = useAutoTag();
  const patch = usePatchAsset();

  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [skillCallId, setSkillCallId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [ran, setRan] = useState(false);

  const suggestions = useMemo(() => {
    const p = autoTag.data?.proposal;
    if (!p) return [] as string[];
    const set = new Set<string>();
    for (const t of p.tags ?? []) set.add(t);
    for (const a of p.audience ?? []) set.add(a);
    if (p.idp) set.add(p.idp);
    if (p.funnelStage) set.add(p.funnelStage);
    return Array.from(set);
  }, [autoTag.data]);

  useEffect(() => {
    if (open) {
      setRan(false);
      setError(null);
      setSelected(new Set());
      setSkillCallId(null);
      autoTag.reset();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, asset.id]);

  useEffect(() => {
    if (open && !ran) {
      setRan(true);
      autoTag
        .mutateAsync(asset.id)
        .then((res) => {
          setSkillCallId(res.skillCallId);
          const p = res.proposal;
          const set = new Set<string>();
          for (const t of p.tags ?? []) set.add(t);
          for (const a of p.audience ?? []) set.add(a);
          if (p.idp) set.add(p.idp);
          if (p.funnelStage) set.add(p.funnelStage);
          setSelected(set);
        })
        .catch((e) =>
          setError(e instanceof Error ? e.message : "Auto-tag failed."),
        );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, ran, asset.id]);

  const toggle = (t: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(t)) next.delete(t);
      else next.add(t);
      return next;
    });

  const apply = async () => {
    setError(null);
    const merged = Array.from(new Set([...asset.tags, ...selected]));
    try {
      await patch.mutateAsync({ id: asset.id, tags: merged });
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save tags.");
    }
  };

  const proposal = autoTag.data?.proposal;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Auto-tag asset"
      icon={<TagIcon className="w-4 h-4 text-[hsl(var(--primary))]" />}
      testId="modal-auto-tag"
      maxWidthClass="max-w-md"
      footer={
        <>
          <TraceLink skillCallId={skillCallId} />
          <div className="ml-auto flex items-center gap-2">
            <button type="button" onClick={onClose} className={ghostBtn}>
              Cancel
            </button>
            <button
              type="button"
              onClick={apply}
              disabled={patch.isPending || selected.size === 0}
              className={primaryBtn}
              data-testid="button-auto-tag-apply"
            >
              {patch.isPending && (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              )}
              Apply {selected.size} tag{selected.size === 1 ? "" : "s"}
            </button>
          </div>
        </>
      }
    >
      <div className="space-y-3">
        <div
          className="truncate text-[12px] text-muted-foreground"
          title={asset.originalName}
        >
          {asset.originalName}
        </div>
        <ErrorNote message={error} />
        {autoTag.isPending ? (
          <div className="flex items-center gap-2 py-6 text-[12.5px] text-muted-foreground">
            <Loader2 className="w-4 h-4 animate-spin" /> Analysing image…
          </div>
        ) : proposal ? (
          <>
            <div>
              <span className={labelCls}>Suggested tags</span>
              <div className="flex flex-wrap gap-1.5">
                {suggestions.map((t) => {
                  const on = selected.has(t);
                  return (
                    <button
                      key={t}
                      type="button"
                      onClick={() => toggle(t)}
                      className={`border px-2 py-0.5 text-[11px] transition-colors ${
                        on
                          ? "border-[hsl(var(--primary))] bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]"
                          : "border-card-border text-muted-foreground hover:text-foreground"
                      }`}
                      data-testid={`auto-tag-chip-${t}`}
                    >
                      {t}
                    </button>
                  );
                })}
                {suggestions.length === 0 && (
                  <span className="text-[11.5px] text-muted-foreground">
                    No tags suggested.
                  </span>
                )}
              </div>
            </div>
            <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-[11.5px]">
              {proposal.idp && (
                <>
                  <dt className="text-muted-foreground">IDP</dt>
                  <dd className="text-foreground">{proposal.idp}</dd>
                </>
              )}
              {proposal.funnelStage && (
                <>
                  <dt className="text-muted-foreground">Funnel stage</dt>
                  <dd className="text-foreground">{proposal.funnelStage}</dd>
                </>
              )}
              {proposal.audience.length > 0 && (
                <>
                  <dt className="text-muted-foreground">Audience</dt>
                  <dd className="text-foreground">
                    {proposal.audience.join(", ")}
                  </dd>
                </>
              )}
            </dl>
            <p className="text-[11px] text-muted-foreground">
              Selected tags are merged with the asset's existing tags.
            </p>
          </>
        ) : (
          !error && (
            <div className="text-[12px] text-muted-foreground py-4">
              Waiting for suggestions…
            </div>
          )
        )}
      </div>
    </Modal>
  );
}
