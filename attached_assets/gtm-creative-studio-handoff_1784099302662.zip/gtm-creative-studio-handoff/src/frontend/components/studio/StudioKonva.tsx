/**
 * Shared Konva renderer for the Creative Studio. One component renders a
 * StudioScene from the stored layer model and is reused by:
 *   - the canvas editor (interactive, selection),
 *   - template/feed thumbnails (static, small scale),
 *   - the export pipeline (full-resolution via the forwarded Stage ref).
 *
 * Images are preloaded at the top level so a parent can wait on `onReady`
 * before calling stage.toDataURL() — this guarantees no blank/partial export.
 * All asset files are served same-origin, so toDataURL never taints.
 */
import {
  forwardRef,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  Stage,
  Layer,
  Rect,
  Text as KText,
  Image as KImage,
  Group,
  Line,
} from "react-konva";
import Konva from "konva";
import type {
  StudioAsset,
  StudioCropOverride,
  StudioStyleOverride,
  StudioImageLayer,
  StudioLayer,
  StudioRectLayer,
  StudioScene,
  StudioTextLayer,
} from "./types";
import {
  STUDIO_FONT_FAMILY,
  assetFileUrl,
  evalLayerAnimation,
  resolveLayerAssetId,
  resolveLayerText,
} from "./scene";
import { useStudioFontsReady } from "../../lib/studio-fonts";
import {
  coverCrop,
  panCrop,
  zoomCrop,
  IDENTITY_CROP,
  resolveCropOverride,
  cropWriteKeyFor,
} from "./cropMath";

/** Konva's filter signature isn't exported by name in this version. */
type KonvaFilter = (this: Konva.Node, imageData: ImageData) => void;

/**
 * Custom unsharp-style convolution sharpen filter. The strength is read from the
 * node's `sharpenAmount` attr (0–1) so the same filter instance serves every
 * image layer. A plus-shaped kernel keeps total energy ~1 (center 1+4a, sides
 * -a) so amount 0 is identity and higher amounts crisp edges without recolour.
 */
const sharpenFilter: KonvaFilter = function (imageData) {
  const amount = (this.getAttr("sharpenAmount") as number) || 0;
  if (amount <= 0) return;
  const data = imageData.data;
  const w = imageData.width;
  const h = imageData.height;
  const src = new Uint8ClampedArray(data);
  const center = 1 + 4 * amount;
  const side = -amount;
  const stride = w * 4;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = (y * w + x) * 4;
      for (let c = 0; c < 3; c++) {
        const k = i + c;
        data[k] =
          center * src[k] +
          side * (src[k - 4] + src[k + 4] + src[k - stride] + src[k + stride]);
      }
    }
  }
};

function weightToStyle(weight?: number): string {
  return String(weight ?? 400);
}

/**
 * High-quality separable Gaussian blur (replaces Konva's blocky box blur for
 * full-bleed `imageKind:"blur"` backgrounds). Reads the radius (in cached-canvas
 * pixels) from the node attr `gaussianRadius`. The cache is taken at a reduced
 * pixelRatio (see SceneImage) so the heavy pass stays fast and the bilinear
 * upscale on draw smooths it further — giving a soft, banding-free wash.
 */
function gaussianKernel(radius: number): Float32Array {
  const sigma = Math.max(1, radius / 2);
  const size = radius * 2 + 1;
  const k = new Float32Array(size);
  const s2 = 2 * sigma * sigma;
  let sum = 0;
  for (let i = -radius; i <= radius; i++) {
    const v = Math.exp(-(i * i) / s2);
    k[i + radius] = v;
    sum += v;
  }
  for (let i = 0; i < size; i++) k[i] /= sum;
  return k;
}

const gaussianBlurFilter: KonvaFilter = function (imageData) {
  const radius = Math.round((this.getAttr("gaussianRadius") as number) || 0);
  if (radius <= 0) return;
  const data = imageData.data;
  const w = imageData.width;
  const h = imageData.height;
  if (w < 2 || h < 2) return;
  const kernel = gaussianKernel(Math.min(radius, 120));
  const r = (kernel.length - 1) / 2;
  const tmp = new Float32Array(data.length);
  // Horizontal pass -> tmp
  for (let y = 0; y < h; y++) {
    const row = y * w;
    for (let x = 0; x < w; x++) {
      let cr = 0;
      let cg = 0;
      let cb = 0;
      let ca = 0;
      for (let k = -r; k <= r; k++) {
        let sx = x + k;
        if (sx < 0) sx = 0;
        else if (sx >= w) sx = w - 1;
        const wgt = kernel[k + r];
        const si = (row + sx) * 4;
        cr += data[si] * wgt;
        cg += data[si + 1] * wgt;
        cb += data[si + 2] * wgt;
        ca += data[si + 3] * wgt;
      }
      const di = (row + x) * 4;
      tmp[di] = cr;
      tmp[di + 1] = cg;
      tmp[di + 2] = cb;
      tmp[di + 3] = ca;
    }
  }
  // Vertical pass -> data
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let cr = 0;
      let cg = 0;
      let cb = 0;
      let ca = 0;
      for (let k = -r; k <= r; k++) {
        let sy = y + k;
        if (sy < 0) sy = 0;
        else if (sy >= h) sy = h - 1;
        const wgt = kernel[k + r];
        const si = ((sy * w + x) * 4) | 0;
        cr += tmp[si] * wgt;
        cg += tmp[si + 1] * wgt;
        cb += tmp[si + 2] * wgt;
        ca += tmp[si + 3] * wgt;
      }
      const di = (y * w + x) * 4;
      data[di] = cr;
      data[di + 1] = cg;
      data[di + 2] = cb;
      data[di + 3] = ca;
    }
  }
};

/**
 * Shared 2D context used only to MEASURE text for shrink-to-fit. Never painted.
 */
const measureCtx: CanvasRenderingContext2D | null =
  typeof document !== "undefined"
    ? document.createElement("canvas").getContext("2d")
    : null;

function measuredWidth(s: string, letterSpacing: number): number {
  if (!measureCtx) return 0;
  const base = measureCtx.measureText(s).width;
  return letterSpacing > 0 && s.length > 1
    ? base + letterSpacing * (s.length - 1)
    : base;
}

/** Count wrapped lines for `text` at the current measureCtx font, matching Konva's word-wrap (break a word only when it alone exceeds the width). */
function countWrappedLines(
  text: string,
  maxWidth: number,
  letterSpacing: number,
): number {
  if (maxWidth <= 0) return 1;
  let lines = 0;
  for (const para of text.split("\n")) {
    if (para.length === 0) {
      lines += 1;
      continue;
    }
    const words = para.split(/\s+/).filter(Boolean);
    let line = "";
    for (const word of words) {
      const trial = line ? `${line} ${word}` : word;
      if (measuredWidth(trial, letterSpacing) <= maxWidth) {
        line = trial;
        continue;
      }
      if (line) {
        lines += 1;
        line = "";
      }
      if (measuredWidth(word, letterSpacing) <= maxWidth) {
        line = word;
        continue;
      }
      // Single word longer than the box — break it character by character.
      let chunk = "";
      for (const ch of word) {
        const t2 = chunk + ch;
        if (chunk && measuredWidth(t2, letterSpacing) > maxWidth) {
          lines += 1;
          chunk = ch;
        } else {
          chunk = t2;
        }
      }
      line = chunk;
    }
    if (line) lines += 1;
  }
  return Math.max(1, lines);
}

/**
 * Largest font size in [minFs, baseFs] at which `text` wraps inside the layer
 * box height. Returns baseFs when it already fits. This is what keeps headlines
 * / CTAs from ever clipping or spilling over neighbours regardless of copy
 * length — the studio's equivalent of adtune's auto-fit type.
 */
function fitFontSize(
  text: string,
  width: number,
  height: number,
  fontFamily: string,
  fontWeight: number,
  lineHeight: number,
  letterSpacing: number,
  baseFs: number,
  minFs: number,
): number {
  if (!measureCtx || !text || height <= 0 || width <= 0) return baseFs;
  const heightAt = (fs: number): number => {
    measureCtx.font = `${fontWeight} ${fs}px ${fontFamily}`;
    const lines = countWrappedLines(text, width, letterSpacing);
    return lines * fs * lineHeight;
  };
  if (heightAt(baseFs) <= height) return baseFs;
  let lo = minFs;
  let hi = baseFs;
  let best = minFs;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (heightAt(mid) <= height) {
      best = mid;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  return best;
}

/** Preload every url into HTMLImageElements; `ready` flips once all settle. */
function useImages(urls: string[]): {
  images: Record<string, HTMLImageElement | null>;
  ready: boolean;
} {
  const key = useMemo(
    () => Array.from(new Set(urls.filter(Boolean))).sort().join("|"),
    [urls],
  );
  const [images, setImages] = useState<Record<string, HTMLImageElement | null>>(
    {},
  );
  useEffect(() => {
    let live = true;
    const unique = key ? key.split("|") : [];
    if (unique.length === 0) {
      setImages({});
      return;
    }
    const acc: Record<string, HTMLImageElement | null> = {};
    let done = 0;
    const finish = (u: string, el: HTMLImageElement | null) => {
      if (!live) return;
      acc[u] = el;
      done += 1;
      if (done >= unique.length) setImages({ ...acc });
    };
    for (const u of unique) {
      const img = new window.Image();
      img.crossOrigin = "anonymous";
      img.onload = () => finish(u, img);
      img.onerror = () => finish(u, null);
      img.src = u;
    }
    return () => {
      live = false;
    };
  }, [key]);
  const ready = useMemo(() => {
    const unique = key ? key.split("|") : [];
    return unique.every((u) => u in images);
  }, [key, images]);
  return { images, ready };
}


/** Contain rect (offset + size) centered within w×h, no crop. */
function containRect(
  img: HTMLImageElement,
  w: number,
  h: number,
): { x: number; y: number; w: number; h: number } {
  const nw = img.naturalWidth || img.width;
  const nh = img.naturalHeight || img.height;
  const s = Math.min(w / nw, h / nh);
  const dw = nw * s;
  const dh = nh * s;
  return { x: (w - dw) / 2, y: (h - dh) / 2, w: dw, h: dh };
}

function SceneImage({
  layer,
  img,
  crop,
  interactive,
  onSelect,
}: {
  layer: StudioImageLayer;
  img: HTMLImageElement | null;
  crop?: StudioCropOverride;
  interactive: boolean;
  onSelect?: () => void;
}) {
  const ref = useRef<Konva.Image>(null);
  // Blur applies to ANY image layer that carries a blur value — the dedicated
  // `imageKind:"blur"` full-bleed background AND a per-creative blur override on
  // a foreground image/logo. Sharpen stays limited to non-blur layers. Both can
  // be active at once (compose), e.g. a sharpened photo with a soft backdrop.
  const blur = layer.blur ?? 0;
  const sharpen = layer.imageKind !== "blur" ? layer.sharpen ?? 0 : 0;
  useEffect(() => {
    const node = ref.current;
    if (!node || !img) return;
    try {
      const filters: (KonvaFilter | string)[] = [];
      if (blur > 0) {
        // Cache the heavy blur at a reduced resolution: the Gaussian pass runs
        // on far fewer pixels and the bilinear upscale on draw makes the wash
        // even smoother. The radius is converted to cached-canvas px. A sharpen
        // pass, when present, composes on top of this same reduced cache.
        const longEdge = Math.max(layer.w, layer.h, 1);
        const pixelRatio = Math.min(1, Math.max(0.18, 420 / longEdge));
        node.cache({ pixelRatio });
        filters.push(gaussianBlurFilter);
        node.setAttr("gaussianRadius", Math.max(1, Math.round(blur * pixelRatio)));
      } else if (sharpen > 0) {
        node.cache();
      }
      if (sharpen > 0) {
        filters.push(sharpenFilter);
        node.setAttr("sharpenAmount", sharpen / 100);
      }
      if (filters.length > 0) {
        node.filters(filters);
      } else {
        node.filters([]);
        node.clearCache();
      }
      node.getLayer()?.batchDraw();
    } catch {
      // caching can throw on zero-size nodes; ignore.
    }
  }, [img, blur, sharpen, layer.w, layer.h, layer.x, layer.y]);

  if (!img) {
    return (
      <Rect
        x={layer.x}
        y={layer.y}
        width={layer.w}
        height={layer.h}
        fill="#0B1F33"
        opacity={0.18}
        onClick={onSelect}
        onTap={onSelect}
        listening={interactive}
      />
    );
  }

  const fit = layer.imageKind === "blur" ? "cover" : layer.fit ?? "cover";
  let props: {
    x: number;
    y: number;
    width: number;
    height: number;
    crop?: { x: number; y: number; width: number; height: number };
  };
  if (fit === "cover") {
    props = {
      x: layer.x,
      y: layer.y,
      width: layer.w,
      height: layer.h,
      crop: coverCrop(
        img.naturalWidth || img.width,
        img.naturalHeight || img.height,
        layer.w,
        layer.h,
        crop,
      ),
    };
  } else if (fit === "contain") {
    const r = containRect(img, layer.w, layer.h);
    props = { x: layer.x + r.x, y: layer.y + r.y, width: r.w, height: r.h };
  } else {
    props = { x: layer.x, y: layer.y, width: layer.w, height: layer.h };
  }
  return (
    <KImage
      ref={ref}
      image={img}
      {...props}
      cornerRadius={layer.cornerRadius}
      opacity={layer.opacity ?? 1}
      rotation={layer.rotation}
      onClick={onSelect}
      onTap={onSelect}
      listening={interactive}
    />
  );
}

function SceneRect({
  layer,
  interactive,
  onSelect,
}: {
  layer: StudioRectLayer;
  interactive: boolean;
  onSelect?: () => void;
}) {
  const grad = layer.gradient;
  const gradProps = grad
    ? {
        fillLinearGradientStartPoint: { x: 0, y: 0 },
        fillLinearGradientEndPoint: { x: 0, y: layer.h },
        fillLinearGradientColorStops: grad.flatMap(([stop, color]) => [
          stop,
          color,
        ]),
      }
    : { fill: layer.fill ?? "#000000" };
  return (
    <Rect
      x={layer.x}
      y={layer.y}
      width={layer.w}
      height={layer.h}
      cornerRadius={layer.cornerRadius}
      stroke={layer.stroke}
      strokeWidth={layer.strokeWidth}
      opacity={layer.opacity ?? 1}
      rotation={layer.rotation}
      onClick={onSelect}
      onTap={onSelect}
      listening={interactive}
      {...gradProps}
    />
  );
}

function SceneText({
  layer,
  values,
  interactive,
  fontsReady,
  onSelect,
}: {
  layer: StudioTextLayer;
  values: Record<string, string>;
  interactive: boolean;
  fontsReady: boolean;
  onSelect?: () => void;
}) {
  const text = resolveLayerText(layer, values);
  const baseFs = layer.fontSize ?? 24;
  const fontFamily = layer.fontFamily ?? STUDIO_FONT_FAMILY;
  const fontWeight = layer.fontWeight ?? 400;
  const lineHeight = layer.lineHeight ?? 1.15;
  const letterSpacing = layer.letterSpacing ?? 0;

  // Shrink the font so the wrapped copy always fits the layer box — never clip
  // or overflow into neighbouring layers, whatever the row's copy length is.
  // `fontsReady` is a dependency so the size is recomputed against the real
  // Amazon Ember metrics once the webfont loads (export waits on the same flag).
  const fontSize = useMemo(
    () =>
      fitFontSize(
        text,
        layer.w,
        layer.h,
        fontFamily,
        fontWeight,
        lineHeight,
        letterSpacing,
        baseFs,
        Math.max(9, Math.round(baseFs * 0.42)),
      ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      text,
      layer.w,
      layer.h,
      fontFamily,
      fontWeight,
      lineHeight,
      letterSpacing,
      baseFs,
      fontsReady,
    ],
  );

  return (
    <KText
      x={layer.x}
      y={layer.y}
      width={layer.w}
      height={layer.h}
      text={text}
      fontSize={fontSize}
      fontFamily={fontFamily}
      fontStyle={weightToStyle(layer.fontWeight)}
      lineHeight={lineHeight}
      letterSpacing={letterSpacing}
      fill={layer.color ?? "#FFFFFF"}
      align={layer.align ?? "left"}
      verticalAlign={layer.valign ?? "top"}
      opacity={layer.opacity ?? 1}
      rotation={layer.rotation}
      wrap="word"
      onClick={onSelect}
      onTap={onSelect}
      listening={interactive}
    />
  );
}

/**
 * Direct on-canvas crop frame for a cover image. Drag anywhere inside to pan the
 * focal point; wheel to zoom. Shows a rule-of-thirds frame with corner handles —
 * the adtune-style "grab the picture and move it" interaction, no sliders.
 */
function CropOverlay({
  fieldId,
  x,
  y,
  w,
  h,
  nw,
  nh,
  crop,
  scale,
  onCropDraft,
}: {
  fieldId: string;
  x: number;
  y: number;
  w: number;
  h: number;
  nw: number;
  nh: number;
  crop: StudioCropOverride;
  scale: number;
  onCropDraft: (fieldId: string, crop: StudioCropOverride) => void;
}) {
  const cropRef = useRef<StudioCropOverride>(crop);
  cropRef.current = crop;
  const dragBaseRef = useRef<StudioCropOverride>(cropRef.current);
  const sw = 1.5 / scale;
  const handle = 9 / scale;
  const thirds = [
    [x + w / 3, y, x + w / 3, y + h],
    [x + (2 * w) / 3, y, x + (2 * w) / 3, y + h],
    [x, y + h / 3, x + w, y + h / 3],
    [x, y + (2 * h) / 3, x + w, y + (2 * h) / 3],
  ];
  const corners: Array<[number, number]> = [
    [x, y],
    [x + w, y],
    [x, y + h],
    [x + w, y + h],
  ];
  const setCursor = (node: Konva.Node, cursor: string) => {
    const stage = node.getStage();
    if (stage) stage.container().style.cursor = cursor;
  };
  return (
    <>
      <Rect
        x={x}
        y={y}
        width={w}
        height={h}
        fill="rgba(8,15,30,0.05)"
        stroke="#FFFFFF"
        strokeWidth={sw}
        shadowColor="#000000"
        shadowBlur={6 / scale}
        shadowOpacity={0.45}
        draggable
        onMouseEnter={(e) => setCursor(e.target, "move")}
        onMouseLeave={(e) => setCursor(e.target, "default")}
        onDragStart={() => {
          dragBaseRef.current = cropRef.current;
        }}
        onDragMove={(e) => {
          const node = e.target;
          const dx = node.x() - x;
          const dy = node.y() - y;
          const next = panCrop(dragBaseRef.current, w, h, dx, dy, nw, nh);
          cropRef.current = next;
          node.position({ x, y });
          onCropDraft(fieldId, next);
        }}
        onWheel={(e) => {
          e.evt.preventDefault();
          // Proportional zoom: small trackpad deltas nudge gently, a mouse
          // notch steps ~12%. Clamped so a fast flick can't jump the scale.
          const factor = Math.min(
            1.25,
            Math.max(0.8, Math.exp(-e.evt.deltaY * 0.0015)),
          );
          const next = zoomCrop(
            cropRef.current,
            (cropRef.current.scale ?? 1) * factor,
          );
          cropRef.current = next;
          onCropDraft(fieldId, next);
        }}
      />
      {thirds.map((pts, i) => (
        <Line
          key={`t${i}`}
          points={pts}
          stroke="#FFFFFF"
          strokeWidth={0.75 / scale}
          opacity={0.5}
          listening={false}
        />
      ))}
      {corners.map(([cxp, cyp], i) => (
        <Rect
          key={`c${i}`}
          x={cxp - handle / 2}
          y={cyp - handle / 2}
          width={handle}
          height={handle}
          fill="#FFFFFF"
          stroke="#0972D3"
          strokeWidth={1 / scale}
          listening={false}
        />
      ))}
    </>
  );
}

export interface StudioKonvaProps {
  scene: StudioScene;
  width: number;
  height: number;
  /** On-screen scale factor; design coordinates stay at full size. */
  scale?: number;
  /** Resolved creative values (row values merged over schema defaults). */
  values?: Record<string, string>;
  /** Asset lookup for resolving image layers to file urls. */
  assetsById?: Record<string, StudioAsset>;
  /**
   * Crop overrides. Keyed by `fieldId` for the BASE crop (shared across every
   * dimension) and by `${variantId}:${fieldId}` for a per-size override that
   * wins for that one dimension. Resolution is composite-then-base.
   */
  crops?: Record<string, StudioCropOverride>;
  /** This stage's variant id — enables per-size crop resolution and writes. */
  variantId?: string;
  /**
   * When true (and `variantId` is set), on-canvas crop edits write a per-size
   * override (`${variantId}:${fieldId}`) instead of the shared base crop, so
   * each banner size can be reframed independently in the multi-slice view.
   */
  perSizeCrop?: boolean;
  /**
   * Per-creative layer-style overrides keyed by image fieldId. Each override is
   * merged over the template layer's opacity / corner radius / blur at render
   * so a single creative can restyle its image without touching the template.
   */
  styleOverrides?: Record<string, StudioStyleOverride>;
  interactive?: boolean;
  selectedLayerId?: string | null;
  onSelectLayer?: (id: string | null) => void;
  /** Drag-to-move callback (editor only); reports new absolute x/y. */
  onLayerChange?: (id: string, patch: { x: number; y: number }) => void;
  /**
   * Field id whose cover image is in DIRECT crop mode. When set (and the scene
   * has a matching cover image), that image renders a draggable focal frame:
   * drag to pan, wheel to zoom. Works even when `interactive` is false so the
   * read-only feed/multi-slice previews can be cropped in place.
   */
  cropFieldId?: string | null;
  /** Live crop update during on-canvas pan/zoom. */
  onCropDraft?: (fieldId: string, crop: StudioCropOverride) => void;
  /** Double-click a cover image to request crop mode for its field. */
  onEnterCrop?: (fieldId: string) => void;
  /**
   * Layer id whose cover image is in TEMPLATE crop mode (editor only). When set
   * and that layer is a cover image, it renders an always-on draggable focal
   * frame writing to the per-LAYER `crop` (not the per-fieldId row crop), so the
   * blurred background and the sharp foreground card — even bound to the same
   * media field — frame independently. Works for blur images too.
   */
  cropLayerId?: string | null;
  /** Live per-layer crop update during template-mode pan/zoom. */
  onLayerCropDraft?: (layerId: string, crop: StudioCropOverride) => void;
  /** Fires once every image layer has settled (loaded or errored). */
  onReady?: () => void;
  /**
   * Playhead time (ms). When provided, each layer's animation clips are applied
   * on top of its resting state (opacity / translate / scale-about-center).
   * When OMITTED the scene renders statically — identical to before animation.
   */
  frameMs?: number;
}

/** Forwarded ref is the Konva Stage, used by callers for toDataURL export. */
const StudioKonva = forwardRef<Konva.Stage, StudioKonvaProps>(
  function StudioKonva(
    {
      scene,
      width,
      height,
      scale = 1,
      values = {},
      assetsById = {},
      crops = {},
      variantId,
      perSizeCrop = false,
      styleOverrides = {},
      interactive = false,
      selectedLayerId = null,
      onSelectLayer,
      onLayerChange,
      cropFieldId = null,
      onCropDraft,
      onEnterCrop,
      cropLayerId = null,
      onLayerCropDraft,
      onReady,
      frameMs,
    },
    ref,
  ) {
    const urlByLayer = useMemo(() => {
      const m: Record<string, string> = {};
      for (const ly of scene.layers) {
        if (ly.type === "image") {
          const assetId = resolveLayerAssetId(ly, values);
          const asset = assetId ? assetsById[assetId] : undefined;
          if (asset) m[ly.id] = assetFileUrl(asset.fileName);
        }
      }
      return m;
    }, [scene, values, assetsById]);

    const { images, ready } = useImages(useMemo(() => Object.values(urlByLayer), [urlByLayer]));

    // Re-renders when the real webfont finishes loading so Konva re-measures
    // text with the loaded face; export waits on it (no mid-load substitute).
    const fontsReady = useStudioFontsReady();

    useEffect(() => {
      if (ready && fontsReady) onReady?.();
    }, [ready, fontsReady, onReady]);

    const stageW = Math.max(1, Math.round(width * scale));
    const stageH = Math.max(1, Math.round(height * scale));

    // Per-size crop resolution: a `${variantId}:${fieldId}` override wins for
    // this dimension, else the shared base `fieldId` crop applies everywhere.
    const resolveCrop = (fid: string): StudioCropOverride | undefined =>
      resolveCropOverride(crops, fid, variantId);
    // Where an on-canvas edit is written: per-size key in multi-slice per-size
    // mode, otherwise the shared base key.
    const cropWriteKey = (fid: string): string =>
      cropWriteKeyFor(fid, variantId, perSizeCrop);

    return (
      <Stage
        ref={ref}
        width={stageW}
        height={stageH}
        scaleX={scale}
        scaleY={scale}
        onMouseDown={
          interactive
            ? (e) => {
                if (e.target === e.target.getStage()) onSelectLayer?.(null);
              }
            : undefined
        }
      >
        <Layer>
          <Rect
            x={0}
            y={0}
            width={width}
            height={height}
            fill={scene.bg}
            listening={false}
          />
          {scene.layers
            .filter((l) => l.visible !== false)
            .map((ly) => {
              const onSelect = interactive
                ? () => onSelectLayer?.(ly.id)
                : undefined;
              const selected = interactive && selectedLayerId === ly.id;
              // In template crop mode the group must NOT drag-to-move — the crop
              // overlay claims drag to pan the focal frame instead.
              const draggable =
                interactive && !ly.locked && cropLayerId !== ly.id;
              // Animation transforms apply ONLY when a playhead is supplied.
              // Scale is about the layer centre (offset = centre, position =
              // centre + translate) so pop/pulse don't drift the layer.
              const anim =
                frameMs != null ? evalLayerAnimation(ly, frameMs) : null;
              const cx = ly.x + ly.w / 2;
              const cy = ly.y + ly.h / 2;
              const groupTransform = anim
                ? {
                    x: cx + anim.dx,
                    y: cy + anim.dy,
                    offsetX: cx,
                    offsetY: cy,
                    scaleX: anim.scale,
                    scaleY: anim.scale,
                    opacity: anim.opacity,
                  }
                : undefined;
              return (
                <Group
                  key={ly.id}
                  {...groupTransform}
                  draggable={draggable}
                  onDragStart={
                    draggable ? () => onSelectLayer?.(ly.id) : undefined
                  }
                  onDragEnd={
                    draggable
                      ? (e) => {
                          const node = e.target;
                          const nx = Math.round(ly.x + node.x());
                          const ny = Math.round(ly.y + node.y());
                          node.position({ x: 0, y: 0 });
                          onLayerChange?.(ly.id, { x: nx, y: ny });
                        }
                      : undefined
                  }
                >
                  {ly.type === "image" ? (
                    (() => {
                      const img = images[urlByLayer[ly.id] ?? ""] ?? null;
                      const fid = ly.fieldId;
                      // Merge any per-creative style override (opacity / corner
                      // radius / blur) over the template layer; undefined fields
                      // fall back to the layer's authored values.
                      const sov = fid ? styleOverrides[fid] : undefined;
                      const effLayer: StudioImageLayer = sov
                        ? {
                            ...ly,
                            opacity: sov.opacity ?? ly.opacity,
                            cornerRadius: sov.cornerRadius ?? ly.cornerRadius,
                            blur: sov.blur ?? ly.blur,
                          }
                        : ly;
                      const cropEligible =
                        !!fid &&
                        !!img &&
                        ly.imageKind !== "blur" &&
                        (ly.fit ?? "cover") === "cover";
                      // Template per-LAYER crop is eligible for ANY cover image,
                      // including the blurred background (so background AND the
                      // sharp foreground card crop independently).
                      const effFit =
                        ly.imageKind === "blur" ? "cover" : ly.fit ?? "cover";
                      const layerCropEligible = !!img && effFit === "cover";
                      const layerCropActive =
                        layerCropEligible && cropLayerId === ly.id;
                      // Effective base crop: a per-creative row crop (by fieldId)
                      // wins, else the template per-layer crop. Single render
                      // path → flows through editor, thumbnails, feed AND export.
                      const baseCrop =
                        (fid ? resolveCrop(fid) : undefined) ?? ly.crop;
                      return (
                        <>
                          <SceneImage
                            layer={effLayer}
                            img={img}
                            crop={baseCrop}
                            interactive={interactive}
                            onSelect={onSelect}
                          />
                          {layerCropActive && img && (
                            <CropOverlay
                              fieldId={ly.id}
                              x={ly.x}
                              y={ly.y}
                              w={ly.w}
                              h={ly.h}
                              nw={img.naturalWidth || img.width}
                              nh={img.naturalHeight || img.height}
                              crop={ly.crop ?? IDENTITY_CROP}
                              scale={scale}
                              onCropDraft={(id, c) =>
                                onLayerCropDraft?.(id, c)
                              }
                            />
                          )}
                          {cropEligible &&
                            fid &&
                            img &&
                            !layerCropActive &&
                            cropFieldId === fid && (
                              <CropOverlay
                                fieldId={cropWriteKey(fid)}
                                x={ly.x}
                                y={ly.y}
                                w={ly.w}
                                h={ly.h}
                                nw={img.naturalWidth || img.width}
                                nh={img.naturalHeight || img.height}
                                crop={resolveCrop(fid) ?? IDENTITY_CROP}
                                scale={scale}
                                onCropDraft={onCropDraft ?? (() => {})}
                              />
                            )}
                          {cropEligible &&
                            fid &&
                            cropFieldId !== fid &&
                            onEnterCrop && (
                              <Rect
                                x={ly.x}
                                y={ly.y}
                                width={ly.w}
                                height={ly.h}
                                fill="rgba(0,0,0,0.001)"
                                onDblClick={() => onEnterCrop(fid)}
                                onDblTap={() => onEnterCrop(fid)}
                                onMouseEnter={(e) => {
                                  const s = e.target.getStage();
                                  if (s) s.container().style.cursor = "zoom-in";
                                }}
                                onMouseLeave={(e) => {
                                  const s = e.target.getStage();
                                  if (s) s.container().style.cursor = "default";
                                }}
                              />
                            )}
                        </>
                      );
                    })()
                  ) : ly.type === "rect" ? (
                    <SceneRect
                      layer={ly}
                      interactive={interactive}
                      onSelect={onSelect}
                    />
                  ) : (
                    <SceneText
                      layer={ly}
                      values={values}
                      interactive={interactive}
                      fontsReady={fontsReady}
                      onSelect={onSelect}
                    />
                  )}
                  {selected && (
                    <Rect
                      x={ly.x - 2}
                      y={ly.y - 2}
                      width={ly.w + 4}
                      height={ly.h + 4}
                      stroke="#0972D3"
                      strokeWidth={2 / scale}
                      dash={[6 / scale, 4 / scale]}
                      listening={false}
                    />
                  )}
                </Group>
              );
            })}
        </Layer>
      </Stage>
    );
  },
);

export default StudioKonva;
