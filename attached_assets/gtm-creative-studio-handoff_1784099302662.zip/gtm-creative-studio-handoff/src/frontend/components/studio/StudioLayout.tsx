/**
 * Creative Studio chrome — a browser-tab style top bar with the studio
 * sections, rendered inside the main AbmLayout shell. The full-screen canvas
 * editor bypasses this layout (like the GTM canvas) and renders edge-to-edge.
 */
import { useEffect, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Images,
  LayoutTemplate,
  Rows3,
  GalleryHorizontalEnd,
} from "lucide-react";

export type StudioTab =
  | "dashboard"
  | "assets"
  | "templates"
  | "feeds"
  | "library";

const TABS: {
  key: StudioTab;
  label: string;
  href: string;
  icon: ReactNode;
  match: (loc: string) => boolean;
}[] = [
  {
    key: "dashboard",
    label: "Dashboard",
    href: "/studio",
    icon: <LayoutDashboard className="w-3.5 h-3.5" />,
    match: (l) => l === "/studio",
  },
  {
    key: "assets",
    label: "Asset Library",
    href: "/studio/assets",
    icon: <Images className="w-3.5 h-3.5" />,
    match: (l) => l.startsWith("/studio/assets"),
  },
  {
    key: "templates",
    label: "Templates",
    href: "/studio/templates",
    icon: <LayoutTemplate className="w-3.5 h-3.5" />,
    match: (l) => l.startsWith("/studio/templates"),
  },
  {
    key: "feeds",
    label: "Feeds",
    href: "/studio/feeds",
    icon: <Rows3 className="w-3.5 h-3.5" />,
    match: (l) => l.startsWith("/studio/feeds"),
  },
  {
    key: "library",
    label: "Creative Library",
    href: "/studio/library",
    icon: <GalleryHorizontalEnd className="w-3.5 h-3.5" />,
    match: (l) => l.startsWith("/studio/library"),
  },
];

/**
 * Lazy-chunk warmers for the sibling studio routes. These import the exact same
 * specifiers App.tsx lazy-loads, so warming them on studio entry (and on tab
 * hover) means switching tabs no longer trips the Suspense fallback after the
 * first visit. Best-effort — failures are swallowed.
 */
const STUDIO_PRELOADERS: Record<StudioTab, () => Promise<unknown>> = {
  dashboard: () => import("@/pages/studio/dashboard"),
  assets: () => import("@/pages/studio/assets"),
  templates: () => import("@/pages/studio/templates"),
  feeds: () => import("@/pages/studio/feeds"),
  library: () => import("@/pages/studio/library"),
};

function warmStudioChunk(key: StudioTab) {
  void STUDIO_PRELOADERS[key]?.().catch(() => {
    /* prefetch is best-effort */
  });
}

export function StudioLayout({
  active,
  children,
  actions,
}: {
  active: StudioTab;
  children: ReactNode;
  actions?: ReactNode;
}) {
  const [location] = useLocation();
  useEffect(() => {
    // Warm sibling studio chunks shortly after entry so later tab switches are
    // instant. Deferred so it never competes with the current page's first paint.
    const t = setTimeout(() => {
      (Object.keys(STUDIO_PRELOADERS) as StudioTab[]).forEach(warmStudioChunk);
    }, 600);
    return () => clearTimeout(t);
  }, []);
  return (
    <div className="flex-1 min-h-0 flex flex-col bg-background">
      {/* Header — title + section tabs */}
      <div className="flex-shrink-0 border-b border-card-border bg-card">
        <div className="px-6 pt-3.5 flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-[hsl(var(--primary))] flex items-center justify-center text-white">
              <LayoutTemplate className="w-3.5 h-3.5" />
            </div>
            <div>
              <h1 className="text-[15px] font-semibold leading-none text-foreground">
                GTM Creative Studio
              </h1>
            </div>
            <span className="text-[10px] uppercase tracking-wide text-muted-foreground border border-card-border px-1.5 py-0.5 ml-1">
              GTM production
            </span>
          </div>
          <div className="ml-auto flex items-center gap-2">{actions}</div>
        </div>
        <div className="px-4 mt-2.5 flex items-end gap-0.5">
          {TABS.map((t) => {
            const isActive = active
              ? t.key === active
              : t.match(location);
            return (
              <Link
                key={t.key}
                href={t.href}
                onMouseEnter={() => warmStudioChunk(t.key)}
                className={cn(
                  "inline-flex items-center gap-1.5 px-3.5 py-2 text-[12.5px] border-b-2 -mb-px transition-colors",
                  isActive
                    ? "border-[hsl(var(--primary))] text-foreground font-medium"
                    : "border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/40",
                )}
                data-testid={`studio-tab-${t.key}`}
              >
                {t.icon}
                {t.label}
              </Link>
            );
          })}
        </div>
      </div>
      <div className="flex-1 min-h-0 overflow-auto">{children}</div>
    </div>
  );
}
