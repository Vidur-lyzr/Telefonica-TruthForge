/**
 * Creative Studio — agent assistant panel (T005). A right-edge collapsible
 * drawer scoped to the current feed/template that combines:
 *   - an action launcher (Generate / Autofill / Smart-crop / QA) wired to the
 *     same confirm flows the pages own (callbacks are passed in by each page),
 *   - a concise chat via `useStudioChat` that returns SUGGESTIONS only — it
 *     never mutates state. Each reply surfaces its skillCallId as a trace link.
 *
 * One self-contained component. Pages pass `feedId` / `templateId` plus the
 * action callbacks that apply to that surface. Cloudscape light, 0px corners.
 */
import { useRef, useState, type ReactNode } from "react";
import { Link } from "wouter";
import { Streamdown } from "streamdown";
import {
  Sparkles,
  Wand2,
  Crop as CropIcon,
  ShieldCheck,
  Bot,
  Send,
  Loader2,
  X,
  PanelRightOpen,
  CornerDownLeft,
  Wrench,
  CheckCircle2,
  AlertTriangle,
  Terminal,
} from "lucide-react";
import {
  useStudioChat,
  streamStudioChat,
  type StudioChatTurn,
  type StudioChatSuggestion,
  type StudioChatAction,
} from "@/lib/studio-api";

interface ChatMessage extends StudioChatTurn {
  suggestions?: StudioChatSuggestion[];
  skillCallId?: string;
}

const actionBtn =
  "inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[12px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))] hover:text-[hsl(var(--primary))] disabled:opacity-50 disabled:hover:border-card-border disabled:hover:text-foreground w-full";

/** Human-readable label for a live agent action row in the streaming timeline. */
function actionText(a: StudioChatAction): string {
  const tool = a.toolName || "tool";
  switch (a.kind) {
    case "tool_use":
      return a.detail ? `${tool} · ${a.detail}` : `Using ${tool}`;
    case "tool_result":
      return a.isError ? `${tool} failed` : `${tool} done`;
    case "system":
      return a.detail ?? "Working…";
    case "error":
      return a.detail ?? "Error";
    default:
      return "Working…";
  }
}

function ActionIcon({ a }: { a: StudioChatAction }) {
  if (a.kind === "error" || (a.kind === "tool_result" && a.isError))
    return <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0 mt-0.5" />;
  if (a.kind === "tool_result")
    return <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0 mt-0.5" />;
  if (a.kind === "system")
    return <Terminal className="w-3 h-3 text-muted-foreground shrink-0 mt-0.5" />;
  return <Wrench className="w-3 h-3 text-muted-foreground shrink-0 mt-0.5" />;
}

export function StudioAgentPanel({
  feedId,
  templateId,
  scopeLabel,
  onGenerate,
  onAutofill,
  onSmartCrop,
  qaHref,
}: {
  feedId?: string;
  templateId?: string;
  scopeLabel?: string;
  onGenerate?: () => void;
  onAutofill?: () => void;
  onSmartCrop?: () => void;
  qaHref?: string;
}) {
  const [open, setOpen] = useState(false);
  const chat = useStudioChat(); // non-streaming fallback if SSE fails to open

  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [streaming, setStreaming] = useState(false);
  const [liveActions, setLiveActions] = useState<StudioChatAction[]>([]);
  const traceRef = useRef<string | undefined>(undefined);
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    requestAnimationFrame(() => {
      scrollRef.current?.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: "smooth",
      });
    });
  };

  const actions: { node: ReactNode }[] = [];
  if (onGenerate)
    actions.push({
      node: (
        <button
          key="generate"
          type="button"
          onClick={onGenerate}
          className={actionBtn}
          data-testid="agent-action-generate"
        >
          <Sparkles className="w-3.5 h-3.5" /> Generate creatives
        </button>
      ),
    });
  if (onAutofill)
    actions.push({
      node: (
        <button
          key="autofill"
          type="button"
          onClick={onAutofill}
          className={actionBtn}
          data-testid="agent-action-autofill"
        >
          <Wand2 className="w-3.5 h-3.5" /> Autofill feed
        </button>
      ),
    });
  if (onSmartCrop)
    actions.push({
      node: (
        <button
          key="smartcrop"
          type="button"
          onClick={onSmartCrop}
          className={actionBtn}
          data-testid="agent-action-smartcrop"
        >
          <CropIcon className="w-3.5 h-3.5" /> Suggest crops
        </button>
      ),
    });
  if (qaHref)
    actions.push({
      node: (
        <Link
          key="qa"
          href={qaHref}
          className={actionBtn}
          data-testid="agent-action-qa"
        >
          <ShieldCheck className="w-3.5 h-3.5" /> Run matrix QA
        </Link>
      ),
    });

  const send = async () => {
    const message = input.trim();
    if (!message || streaming) return;
    const history: StudioChatTurn[] = messages.map((m) => ({
      role: m.role,
      content: m.content,
    }));
    setMessages((prev) => [...prev, { role: "user", content: message }]);
    setInput("");
    setStreaming(true);
    setLiveActions([]);
    traceRef.current = undefined;
    scrollToBottom();

    let answered = false;
    const pushAssistant = (msg: ChatMessage) => {
      answered = true;
      setMessages((prev) => [...prev, msg]);
      scrollToBottom();
    };

    try {
      await streamStudioChat(
        { feedId, templateId, message, history },
        {
          onStart: (id) => {
            traceRef.current = id;
          },
          onAction: (a) => {
            setLiveActions((prev) => [...prev, a]);
            scrollToBottom();
          },
          onDone: ({ reply, suggestions, skillCallId }) => {
            pushAssistant({
              role: "assistant",
              content: reply,
              suggestions,
              skillCallId: skillCallId ?? traceRef.current,
            });
          },
          onError: (msg) => {
            pushAssistant({ role: "assistant", content: `Sorry — ${msg}` });
          },
        },
      );
      // Stream closed before delivering a reply — drop to the fallback below.
      if (!answered) throw new Error("stream ended without a reply");
    } catch {
      if (!answered) {
        try {
          const res = await chat.mutateAsync({
            feedId,
            templateId,
            message,
            history,
          });
          pushAssistant({
            role: "assistant",
            content: res.reply,
            suggestions: res.suggestions,
            skillCallId: res.skillCallId,
          });
        } catch (e) {
          pushAssistant({
            role: "assistant",
            content:
              e instanceof Error
                ? `Sorry — ${e.message}`
                : "Sorry, something went wrong.",
          });
        }
      }
    } finally {
      setStreaming(false);
      setLiveActions([]);
      scrollToBottom();
    }
  };

  const runSuggestion = (s: StudioChatSuggestion) => {
    switch (s.action) {
      case "generate":
      case "generate-variants":
        onGenerate?.();
        break;
      case "autofill":
      case "feed-autofill":
        onAutofill?.();
        break;
      case "smart-crop":
      case "smartcrop":
        onSmartCrop?.();
        break;
      default:
        // Unknown / informational suggestion — drop it into the composer so the
        // user can ask the assistant to elaborate. The panel never mutates.
        setInput(s.label);
        break;
    }
  };

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="fixed right-0 top-1/2 z-40 -translate-y-1/2 inline-flex items-center gap-1.5 border border-r-0 border-card-border bg-card px-2 py-3 text-[11.5px] text-foreground shadow-sm hover:text-[hsl(var(--primary))] [writing-mode:vertical-rl]"
        data-testid="button-open-agent-panel"
        title="Open studio assistant"
      >
        <Bot className="w-4 h-4 rotate-90" />
        Assistant
      </button>
    );
  }

  return (
    <div
      className="fixed right-0 top-0 z-40 h-screen w-[340px] max-w-[90vw] flex flex-col border-l border-card-border bg-card shadow-xl"
      data-testid="studio-agent-panel"
    >
      {/* Header */}
      <div className="flex-shrink-0 flex items-center gap-2 border-b border-card-border px-3 py-2.5">
        <div className="w-6 h-6 bg-[hsl(var(--primary))] flex items-center justify-center text-white">
          <Bot className="w-3.5 h-3.5" />
        </div>
        <div className="min-w-0">
          <div className="text-[13px] font-semibold leading-none text-foreground">
            Studio assistant
          </div>
          <div className="text-[10.5px] text-muted-foreground truncate mt-0.5">
            {scopeLabel ?? "GTM Creative Studio"}
          </div>
        </div>
        <button
          type="button"
          onClick={() => setOpen(false)}
          className="ml-auto text-muted-foreground hover:text-foreground"
          data-testid="button-close-agent-panel"
          title="Collapse"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Action launcher */}
      {actions.length > 0 && (
        <div className="flex-shrink-0 border-b border-card-border p-3 space-y-1.5">
          <div className="text-[10px] uppercase tracking-wide text-muted-foreground mb-1">
            Actions
          </div>
          {actions.map((a) => a.node)}
        </div>
      )}

      {/* Chat transcript */}
      <div
        ref={scrollRef}
        className="flex-1 min-h-0 overflow-auto p-3 space-y-2.5"
        data-testid="agent-chat-transcript"
      >
        {messages.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-10 text-center">
            <div className="w-9 h-9 bg-muted flex items-center justify-center text-muted-foreground">
              <Sparkles className="w-4 h-4" />
            </div>
            <p className="text-[12px] text-muted-foreground max-w-[220px]">
              Ask about this {feedId ? "feed" : templateId ? "template" : "studio"}
              {" "}— variant ideas, copy tightening, QA risks. Replies are
              suggestions only.
            </p>
          </div>
        ) : (
          messages.map((m, i) => (
            <div
              key={i}
              className={m.role === "user" ? "flex justify-end" : "flex justify-start"}
              data-testid={`agent-message-${m.role}`}
            >
              <div
                className={`max-w-[85%] px-2.5 py-1.5 text-[12px] ${
                  m.role === "user"
                    ? "bg-[hsl(var(--primary))] text-white whitespace-pre-wrap"
                    : "bg-muted text-foreground"
                }`}
              >
                {m.role === "assistant" ? (
                  <div className="text-[12px] leading-relaxed [&_p]:my-1 [&_ul]:my-1 [&_ul]:list-disc [&_ul]:pl-4 [&_ol]:my-1 [&_ol]:list-decimal [&_ol]:pl-4 [&_code]:text-[11px] [&_h1]:text-[13px] [&_h2]:text-[12.5px] [&_h3]:text-[12px] [&_h1]:font-semibold [&_h2]:font-semibold [&_h3]:font-semibold [&_a]:text-[hsl(var(--primary))] [&_a]:underline">
                    <Streamdown>{m.content}</Streamdown>
                  </div>
                ) : (
                  m.content
                )}
                {m.role === "assistant" &&
                  m.suggestions &&
                  m.suggestions.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {m.suggestions.map((s, j) => (
                        <button
                          key={j}
                          type="button"
                          onClick={() => runSuggestion(s)}
                          title={s.note}
                          className="inline-flex items-center gap-1 border border-card-border bg-card px-1.5 py-0.5 text-[11px] text-foreground hover:border-[hsl(var(--primary))] hover:text-[hsl(var(--primary))]"
                          data-testid={`agent-suggestion-${j}`}
                        >
                          <CornerDownLeft className="w-3 h-3" />
                          {s.label}
                        </button>
                      ))}
                    </div>
                  )}
                {m.role === "assistant" && m.skillCallId && (
                  <div className="mt-1.5">
                    <Link
                      href="/observability"
                      className="text-[10.5px] text-[hsl(var(--primary))] hover:underline"
                      title={m.skillCallId}
                      data-testid={`agent-trace-${i}`}
                    >
                      View trace →
                    </Link>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
        {streaming && (
          <div className="flex justify-start">
            <div className="bg-muted text-foreground px-2.5 py-2 text-[12px] w-[85%] space-y-1.5">
              <div className="inline-flex items-center gap-1.5 text-muted-foreground">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                {liveActions.length === 0 ? "Thinking…" : "Working…"}
              </div>
              {liveActions.length > 0 && (
                <ul className="space-y-1" data-testid="agent-live-actions">
                  {liveActions.map((a, i) => (
                    <li
                      key={i}
                      className="flex items-start gap-1.5 text-[11px] text-muted-foreground"
                    >
                      <ActionIcon a={a} />
                      <span className="break-words">{actionText(a)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Composer */}
      <div className="flex-shrink-0 border-t border-card-border p-2.5">
        <div className="flex items-end gap-1.5">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            rows={2}
            placeholder="Ask the studio assistant…"
            className="flex-1 resize-none border border-card-border bg-background px-2.5 py-1.5 text-[12.5px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
            data-testid="input-agent-chat"
          />
          <button
            type="button"
            onClick={send}
            disabled={streaming || !input.trim()}
            className="inline-flex items-center justify-center w-9 h-9 bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
            data-testid="button-agent-send"
            title="Send"
          >
            {streaming ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </button>
        </div>
        <div className="mt-1 flex items-center gap-1 text-[10px] text-muted-foreground">
          <PanelRightOpen className="w-3 h-3" />
          Suggestions only — actions above apply with confirm.
        </div>
      </div>
    </div>
  );
}

export default StudioAgentPanel;
