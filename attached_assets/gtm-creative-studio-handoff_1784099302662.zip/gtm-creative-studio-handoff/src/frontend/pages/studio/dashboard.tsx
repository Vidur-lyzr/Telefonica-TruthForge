/**
 * Creative Studio dashboard — the landing surface for the GTM creative
 * production pipeline. Surfaces the Creative → Review → Distribution tracker,
 * pipeline counts and quick links into templates, feeds and the asset library.
 */
import { Link } from "wouter";
import {
  LayoutTemplate,
  Rows3,
  Images,
  ImageIcon,
  PenLine,
  ShieldCheck,
  Send,
  ArrowRight,
  Plus,
} from "lucide-react";
import { StudioLayout } from "@/components/studio/StudioLayout";
import { renderFileUrl } from "@/components/studio/scene";
import {
  useTemplates,
  useFeeds,
  useAssets,
  useRenders,
  useReviewsSummary,
} from "@/lib/studio-api";

function StatCard({
  icon,
  label,
  value,
  href,
  testId,
}: {
  icon: React.ReactNode;
  label: string;
  value: number | string;
  href: string;
  testId: string;
}) {
  return (
    <Link
      href={href}
      className="group border border-card-border bg-card p-4 flex items-center gap-3 hover:border-[hsl(var(--primary))] transition-colors"
      data-testid={testId}
    >
      <div className="w-9 h-9 bg-muted flex items-center justify-center text-muted-foreground group-hover:text-[hsl(var(--primary))]">
        {icon}
      </div>
      <div className="min-w-0">
        <div className="text-[22px] leading-none font-semibold text-foreground tabular-nums">
          {value}
        </div>
        <div className="text-[12px] text-muted-foreground mt-1">{label}</div>
      </div>
      <ArrowRight className="w-4 h-4 ml-auto text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
    </Link>
  );
}

function StageCard({
  icon,
  stage,
  title,
  desc,
  count,
}: {
  icon: React.ReactNode;
  stage: string;
  title: string;
  desc: string;
  count: number;
}) {
  return (
    <div className="flex-1 border border-card-border bg-card p-4">
      <div className="flex items-center gap-2">
        <div className="w-7 h-7 bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))] flex items-center justify-center">
          {icon}
        </div>
        <span className="text-[10px] uppercase tracking-wide text-muted-foreground font-medium">
          {stage}
        </span>
        <span className="ml-auto text-[18px] font-semibold tabular-nums text-foreground">
          {count}
        </span>
      </div>
      <div className="mt-3 text-[13px] font-medium text-foreground">{title}</div>
      <p className="text-[12px] text-muted-foreground mt-0.5 leading-snug">
        {desc}
      </p>
    </div>
  );
}

export default function StudioDashboardPage() {
  const { data: templates = [] } = useTemplates();
  const { data: feeds = [] } = useFeeds();
  const { data: assets = [] } = useAssets();
  const { data: renders = [] } = useRenders();
  const { data: reviewSummary } = useReviewsSummary();

  const totalVariants = templates.reduce((n, t) => n + t.variants.length, 0);
  const approvedPacks = reviewSummary?.approvedPacks ?? 0;
  const totalHandoffs = reviewSummary?.totalHandoffs ?? 0;

  return (
    <StudioLayout
      active="dashboard"
      actions={
        <Link
          href="/studio/templates"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95"
          data-testid="button-studio-new"
        >
          <Plus className="w-3.5 h-3.5" /> New template
        </Link>
      }
    >
      <div className="p-6 space-y-6">
        {/* Pipeline tracker */}
        <section>
          <h2 className="text-[13px] font-semibold text-foreground mb-2.5">
            Production pipeline
          </h2>
          <div className="flex flex-col sm:flex-row gap-3 items-stretch">
            <StageCard
              icon={<PenLine className="w-4 h-4" />}
              stage="Creative"
              title="Author & assemble"
              desc="Build templates, bind schema fields and lay out every ad dimension."
              count={totalVariants}
            />
            <div className="hidden sm:flex items-center text-muted-foreground">
              <ArrowRight className="w-4 h-4" />
            </div>
            <StageCard
              icon={<ShieldCheck className="w-4 h-4" />}
              stage="Review"
              title="QA & sign-off"
              desc="Run matrix QA, approve every creative×dimension and clear the pack."
              count={approvedPacks}
            />
            <div className="hidden sm:flex items-center text-muted-foreground">
              <ArrowRight className="w-4 h-4" />
            </div>
            <StageCard
              icon={<Send className="w-4 h-4" />}
              stage="Distribution"
              title="Render & ship"
              desc={`Render real bitmaps (${renders.length} stored), export the zip and hand off to the DAM.`}
              count={totalHandoffs}
            />
          </div>
        </section>

        {/* Counts */}
        <section>
          <h2 className="text-[13px] font-semibold text-foreground mb-2.5">
            Library
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard
              icon={<LayoutTemplate className="w-4 h-4" />}
              label="Templates"
              value={templates.length}
              href="/studio/templates"
              testId="stat-templates"
            />
            <StatCard
              icon={<Rows3 className="w-4 h-4" />}
              label="Creative feeds"
              value={feeds.length}
              href="/studio/feeds"
              testId="stat-feeds"
            />
            <StatCard
              icon={<Images className="w-4 h-4" />}
              label="Assets"
              value={assets.length}
              href="/studio/assets"
              testId="stat-assets"
            />
            <StatCard
              icon={<ImageIcon className="w-4 h-4" />}
              label="Stored renders"
              value={renders.length}
              href="/studio/feeds"
              testId="stat-renders"
            />
          </div>
        </section>

        {/* Latest renders strip */}
        {renders.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-2.5">
              <h2 className="text-[13px] font-semibold text-foreground">
                Latest renders
              </h2>
              <Link
                href="/studio/library"
                className="text-[12px] text-[hsl(var(--primary))] hover:underline inline-flex items-center gap-1"
                data-testid="link-all-renders"
              >
                Creative Library <ArrowRight className="w-3 h-3" />
              </Link>
            </div>
            <div className="flex gap-3 overflow-x-auto pb-1">
              {[...renders]
                .sort((a, b) => b.createdAt - a.createdAt)
                .slice(0, 12)
                .map((r) => (
                  <div
                    key={r.id}
                    className="flex-shrink-0 border border-card-border bg-muted"
                    title={`${r.width}×${r.height} · ${r.format.toUpperCase()}`}
                    data-testid={`render-thumb-${r.id}`}
                  >
                    <div className="w-[120px] h-[90px] flex items-center justify-center overflow-hidden">
                      <img
                        src={renderFileUrl(r.fileName)}
                        alt={`${r.variantId} ${r.format}`}
                        className="max-w-full max-h-full object-contain"
                      />
                    </div>
                    <div className="px-2 py-1 text-[10px] text-muted-foreground tabular-nums border-t border-card-border bg-card">
                      {r.width}×{r.height} · {r.format.toUpperCase()}
                    </div>
                  </div>
                ))}
            </div>
          </section>
        )}

        {/* Templates quick list */}
        <section>
          <div className="flex items-center justify-between mb-2.5">
            <h2 className="text-[13px] font-semibold text-foreground">
              Templates
            </h2>
            <Link
              href="/studio/templates"
              className="text-[12px] text-[hsl(var(--primary))] hover:underline inline-flex items-center gap-1"
              data-testid="link-all-templates"
            >
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          {templates.length === 0 ? (
            <div className="border border-dashed border-card-border bg-card p-8 text-center text-[13px] text-muted-foreground">
              No templates yet.
            </div>
          ) : (
            <div className="border border-card-border bg-card divide-y divide-card-border">
              {templates.map((t) => (
                <Link
                  key={t.id}
                  href={`/studio/templates/${t.id}`}
                  className="flex items-center gap-3 px-4 py-3 hover:bg-muted/40 transition-colors"
                  data-testid={`row-template-${t.id}`}
                >
                  <div className="w-8 h-8 bg-muted flex items-center justify-center text-muted-foreground">
                    <LayoutTemplate className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[13px] font-medium text-foreground truncate">
                      {t.name}
                    </div>
                    <div className="text-[11.5px] text-muted-foreground">
                      {t.brand ? `${t.brand} · ` : ""}
                      {t.variants.length}{" "}
                      {t.variants.length === 1 ? "dimension" : "dimensions"} ·{" "}
                      {t.schemaFields.length} fields
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 ml-auto text-muted-foreground" />
                </Link>
              ))}
            </div>
          )}
        </section>
      </div>
    </StudioLayout>
  );
}
