/**
 * Creative Studio — Template detail. Three stacked sub-sections behind an
 * underline sub-tab row:
 *   1. Variants  — real Konva thumbnails grouped Static / Dynamic, with
 *                  add / duplicate / delete and a link into the canvas editor.
 *   2. Schema    — the field model (media / rich text) with an add/edit modal.
 *   3. Output    — per-variant png/jpg/webp matrix + export-as-JSON.
 */
import {
  Suspense,
  lazy,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { Link, useParams } from "wouter";
import {
  ArrowLeft,
  Plus,
  Trash2,
  Copy,
  Pencil,
  X,
  Download,
  Layers,
  ListTree,
  FileOutput,
  FileUp,
  EyeOff,
} from "lucide-react";
import { StudioLayout } from "@/components/studio/StudioLayout";
import { StudioAgentPanel } from "@/components/studio/StudioAgentPanel";
import {
  useTemplate,
  useUpdateTemplate,
  useUpdateSchema,
  useUpdateOutput,
  useAddVariant,
  useDuplicateVariant,
  useDeleteVariant,
  useAssets,
} from "@/lib/studio-api";
import {
  STUDIO_STATIC_FORMATS,
  STUDIO_DYNAMIC_FORMATS,
  type StudioAsset,
  type StudioSchemaField,
  type StudioTemplate,
  type StudioVariant,
} from "@/components/studio/types";

const StudioKonva = lazy(() => import("@/components/studio/StudioKonva"));

const PRESET_DIMENSIONS: {
  name: string;
  width: number;
  height: number;
  type: "static" | "dynamic";
}[] = [
  { name: "Skyscraper", width: 160, height: 600, type: "static" },
  { name: "Wide Skyscraper", width: 300, height: 600, type: "static" },
  { name: "Halfpage", width: 300, height: 600, type: "static" },
  { name: "Leaderboard", width: 728, height: 90, type: "static" },
  { name: "Billboard", width: 970, height: 250, type: "static" },
  { name: "Medium Rectangle", width: 300, height: 250, type: "static" },
  { name: "Large Rectangle", width: 336, height: 280, type: "static" },
  { name: "Mobile Leaderboard", width: 320, height: 50, type: "static" },
  { name: "Square", width: 1080, height: 1080, type: "static" },
  { name: "Animated", width: 1200, height: 626, type: "dynamic" },
];

const FORMAT_OPTIONS = ["jpeg", "jpg", "png", "svg", "webp", "gif"] as const;

function slugify(s: string): string {
  return s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

/* --------------------------------- modal -------------------------------- */

function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  testId,
  maxWidthClass = "max-w-md",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  testId?: string;
  maxWidthClass?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      data-testid={testId}
    >
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div
        className={`relative w-full ${maxWidthClass} border border-card-border bg-card shadow-lg max-h-[90vh] flex flex-col`}
      >
        <div className="flex items-center justify-between border-b border-card-border px-4 py-3 flex-shrink-0">
          <h3 className="text-[14px] font-semibold text-foreground">{title}</h3>
          <button
            type="button"
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-modal-close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4 overflow-auto">{children}</div>
        {footer && (
          <div className="flex justify-end gap-2 border-t border-card-border px-4 py-3 flex-shrink-0">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

const inputCls =
  "w-full border border-card-border bg-background px-2.5 py-1.5 text-[13px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]";
const labelCls = "block text-[12px] font-medium text-foreground mb-1";

/* ------------------------------ variant thumb --------------------------- */

function VariantThumb({
  variant,
  values,
  assetsById,
}: {
  variant: StudioVariant;
  values: Record<string, string>;
  assetsById: Record<string, StudioAsset>;
}) {
  const scale = Math.min(168 / variant.width, 180 / variant.height);
  return (
    <div className="h-[188px] bg-muted flex items-center justify-center overflow-hidden border-b border-card-border">
      <Suspense
        fallback={
          <span className="text-[11px] text-muted-foreground">Rendering…</span>
        }
      >
        <StudioKonva
          scene={variant.scene}
          width={variant.width}
          height={variant.height}
          scale={scale}
          values={values}
          assetsById={assetsById}
        />
      </Suspense>
    </div>
  );
}

/* ------------------------------ variants tab ---------------------------- */

function VariantsTab({
  template,
  values,
  assetsById,
}: {
  template: StudioTemplate;
  values: Record<string, string>;
  assetsById: Record<string, StudioAsset>;
}) {
  const addVariant = useAddVariant(template.id);
  const duplicateVariant = useDuplicateVariant(template.id);
  const deleteVariant = useDeleteVariant(template.id);

  const [open, setOpen] = useState(false);
  const [presetIdx, setPresetIdx] = useState(0);
  const [name, setName] = useState(PRESET_DIMENSIONS[0].name);
  const [type, setType] = useState<"static" | "dynamic">("static");
  const [width, setWidth] = useState(PRESET_DIMENSIONS[0].width);
  const [height, setHeight] = useState(PRESET_DIMENSIONS[0].height);

  const openModal = () => {
    const p = PRESET_DIMENSIONS[0];
    setPresetIdx(0);
    setName(p.name);
    setType(p.type);
    setWidth(p.width);
    setHeight(p.height);
    setOpen(true);
  };

  const applyPreset = (idx: number) => {
    setPresetIdx(idx);
    if (idx >= 0) {
      const p = PRESET_DIMENSIONS[idx];
      setName(p.name);
      setType(p.type);
      setWidth(p.width);
      setHeight(p.height);
    }
  };

  const submit = async () => {
    const trimmed = name.trim() || "Variant";
    await addVariant.mutateAsync({
      name: trimmed,
      type,
      width: Math.max(1, Math.round(width)),
      height: Math.max(1, Math.round(height)),
    });
    setOpen(false);
  };

  const groups: { key: "static" | "dynamic"; label: string }[] = [
    { key: "static", label: "Static" },
    { key: "dynamic", label: "Dynamic" },
  ];

  const renderCard = (v: StudioVariant) => (
    <div
      key={v.id}
      className="border border-card-border bg-card hover:border-[hsl(var(--primary))] transition-colors"
      data-testid={`card-variant-${v.id}`}
    >
      <VariantThumb variant={v} values={values} assetsById={assetsById} />
      <div className="p-3">
        <div className="flex items-center gap-2">
          <div className="min-w-0">
            <div className="text-[13px] font-medium text-foreground truncate">
              {v.name}
            </div>
            <div className="text-[11.5px] text-muted-foreground tabular-nums">
              {v.width}×{v.height}
            </div>
          </div>
          <span className="ml-auto text-[9.5px] uppercase tracking-wide border border-card-border px-1.5 py-0.5 text-muted-foreground">
            {v.type}
          </span>
        </div>
        <div className="flex items-center gap-1.5 mt-3">
          <Link
            href={`/studio/editor/${template.id}/${v.id}`}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95"
            data-testid={`button-edit-variant-${v.id}`}
          >
            <Pencil className="w-3 h-3" /> Edit
          </Link>
          <button
            type="button"
            onClick={() => duplicateVariant.mutate(v.id)}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11.5px] border border-card-border bg-card text-foreground hover:bg-muted/40"
            data-testid={`button-duplicate-variant-${v.id}`}
          >
            <Copy className="w-3 h-3" /> Duplicate
          </button>
          <button
            type="button"
            onClick={() => {
              if (window.confirm(`Delete dimension “${v.name}”?`))
                deleteVariant.mutate(v.id);
            }}
            className="ml-auto inline-flex items-center justify-center w-7 h-7 text-muted-foreground hover:text-red-600 hover:bg-red-50"
            title="Delete dimension"
            data-testid={`button-delete-variant-${v.id}`}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <p className="text-[12px] text-muted-foreground">
          {template.variants.length}{" "}
          {template.variants.length === 1 ? "dimension" : "dimensions"} · live
          Konva previews use schema defaults.
        </p>
        <button
          type="button"
          onClick={openModal}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95"
          data-testid="button-new-variant"
        >
          <Plus className="w-3.5 h-3.5" /> New variant
        </button>
      </div>

      {groups.map((g) => {
        const list = template.variants.filter((v) => v.type === g.key);
        if (list.length === 0) return null;
        return (
          <div key={g.key} className="mb-6">
            <h3 className="text-[11px] uppercase tracking-wide text-muted-foreground font-medium mb-2">
              {g.label} · {list.length}
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {list.map(renderCard)}
            </div>
          </div>
        );
      })}

      {template.variants.length === 0 && (
        <div className="border border-dashed border-card-border bg-card p-10 text-center text-[13px] text-muted-foreground">
          No dimensions yet. Add one to start laying out the creative.
        </div>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="New variant"
        testId="modal-new-variant"
        footer={
          <>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:bg-muted/40"
              data-testid="button-cancel-variant"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={submit}
              disabled={addVariant.isPending}
              className="px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
              data-testid="button-confirm-variant"
            >
              {addVariant.isPending ? "Adding…" : "Add variant"}
            </button>
          </>
        }
      >
        <div className="space-y-3">
          <div>
            <label className={labelCls}>Preset size</label>
            <select
              value={presetIdx}
              onChange={(e) => applyPreset(Number(e.target.value))}
              className={inputCls}
              data-testid="select-variant-preset"
            >
              {PRESET_DIMENSIONS.map((p, i) => (
                <option key={p.name} value={i}>
                  {p.name} — {p.width}×{p.height} ({p.type})
                </option>
              ))}
              <option value={-1}>Custom…</option>
            </select>
          </div>
          <div>
            <label className={labelCls}>Name</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className={inputCls}
              data-testid="input-variant-name"
            />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className={labelCls}>Width</label>
              <input
                type="number"
                value={width}
                min={1}
                onChange={(e) => {
                  setWidth(Number(e.target.value));
                  setPresetIdx(-1);
                }}
                className={inputCls}
                data-testid="input-variant-width"
              />
            </div>
            <div>
              <label className={labelCls}>Height</label>
              <input
                type="number"
                value={height}
                min={1}
                onChange={(e) => {
                  setHeight(Number(e.target.value));
                  setPresetIdx(-1);
                }}
                className={inputCls}
                data-testid="input-variant-height"
              />
            </div>
            <div>
              <label className={labelCls}>Type</label>
              <select
                value={type}
                onChange={(e) =>
                  setType(e.target.value as "static" | "dynamic")
                }
                className={inputCls}
                data-testid="select-variant-type"
              >
                <option value="static">Static</option>
                <option value="dynamic">Dynamic</option>
              </select>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}

/* ------------------------------- schema tab ----------------------------- */

const emptyField: StudioSchemaField = {
  id: "",
  label: "",
  type: "rich_text",
};

function SchemaTab({ template }: { template: StudioTemplate }) {
  const updateSchema = useUpdateSchema(template.id);
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<StudioSchemaField>(emptyField);
  const [idTouched, setIdTouched] = useState(false);

  // Import-parameters workflow (paste JSON / load a .json file).
  const [importOpen, setImportOpen] = useState(false);
  const [importText, setImportText] = useState("");
  const [importError, setImportError] = useState<string | null>(null);

  const openAdd = () => {
    setEditingId(null);
    setDraft({ ...emptyField });
    setIdTouched(false);
    setOpen(true);
  };

  const openImport = () => {
    setImportText("");
    setImportError(null);
    setImportOpen(true);
  };

  // Accept either a full StudioTemplate JSON ({ schemaFields: [...] }) or a
  // bare array of fields. Validate, slugify ids, and merge by id (incoming
  // fields replace existing ones, new fields are appended).
  const runImport = () => {
    let parsed: unknown;
    try {
      parsed = JSON.parse(importText);
    } catch {
      setImportError("That isn't valid JSON.");
      return;
    }
    const raw = Array.isArray(parsed)
      ? parsed
      : (parsed as { schemaFields?: unknown })?.schemaFields;
    if (!Array.isArray(raw)) {
      setImportError(
        'Expected an array of fields, or an object with a "schemaFields" array.',
      );
      return;
    }
    const incoming: StudioSchemaField[] = [];
    for (const item of raw) {
      const f = item as Partial<StudioSchemaField>;
      const id = slugify(String(f.id ?? f.label ?? ""));
      const label = String(f.label ?? "").trim();
      if (!id || !label) {
        setImportError("Every field needs a label (and an id or label slug).");
        return;
      }
      const type: StudioSchemaField["type"] =
        f.type === "media" ? "media" : "rich_text";
      const cleaned: StudioSchemaField = {
        id,
        label,
        type,
        description: f.description?.trim() || undefined,
        multi: f.multi || undefined,
        defaultValue: f.defaultValue?.trim() || undefined,
        preselectedAssetIds: f.preselectedAssetIds,
        allowedFormats: type === "media" ? f.allowedFormats : undefined,
        maxSizeMB: type === "media" ? f.maxSizeMB : undefined,
        hidden: f.hidden || undefined,
      };
      if (incoming.some((x) => x.id === id)) {
        setImportError(`Duplicate field id "${id}" in the imported set.`);
        return;
      }
      incoming.push(cleaned);
    }
    if (incoming.length === 0) {
      setImportError("No fields found to import.");
      return;
    }
    const byId = new Map(template.schemaFields.map((f) => [f.id, f]));
    for (const f of incoming) byId.set(f.id, f);
    updateSchema.mutate(Array.from(byId.values()), {
      onSuccess: () => setImportOpen(false),
    });
  };

  const onImportFile = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setImportText(String(reader.result ?? ""));
    reader.readAsText(file);
  };

  const openEdit = (f: StudioSchemaField) => {
    setEditingId(f.id);
    setDraft({ ...f });
    setIdTouched(true);
    setOpen(true);
  };

  const setLabel = (label: string) => {
    setDraft((d) => ({
      ...d,
      label,
      id: idTouched ? d.id : slugify(label),
    }));
  };

  const toggleFormat = (fmt: string) => {
    setDraft((d) => {
      const cur = d.allowedFormats ?? [];
      const next = cur.includes(fmt)
        ? cur.filter((x) => x !== fmt)
        : [...cur, fmt];
      return { ...d, allowedFormats: next.length ? next : undefined };
    });
  };

  const save = () => {
    const id = slugify(draft.id || draft.label);
    if (!id || !draft.label.trim()) return;
    const cleaned: StudioSchemaField = {
      ...draft,
      id,
      label: draft.label.trim(),
      description: draft.description?.trim() || undefined,
      defaultValue: draft.defaultValue?.trim() || undefined,
      allowedFormats:
        draft.type === "media" ? draft.allowedFormats : undefined,
      maxSizeMB: draft.type === "media" ? draft.maxSizeMB : undefined,
    };
    let next: StudioSchemaField[];
    if (editingId) {
      next = template.schemaFields.map((f) =>
        f.id === editingId ? cleaned : f,
      );
    } else {
      if (template.schemaFields.some((f) => f.id === id)) {
        window.alert(`A field with id “${id}” already exists.`);
        return;
      }
      next = [...template.schemaFields, cleaned];
    }
    updateSchema.mutate(next, { onSuccess: () => setOpen(false) });
  };

  const removeField = (id: string, label: string) => {
    if (!window.confirm(`Delete field “${label}”?`)) return;
    updateSchema.mutate(template.schemaFields.filter((f) => f.id !== id));
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <p className="text-[12px] text-muted-foreground">
          {template.schemaFields.length}{" "}
          {template.schemaFields.length === 1 ? "field" : "fields"} bound into
          the creative layers.
        </p>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={openImport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:bg-muted/40"
            data-testid="button-import-fields"
          >
            <FileUp className="w-3.5 h-3.5" /> Import
          </button>
          <button
            type="button"
            onClick={openAdd}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95"
            data-testid="button-add-field"
          >
            <Plus className="w-3.5 h-3.5" /> Add field
          </button>
        </div>
      </div>

      {template.schemaFields.length === 0 ? (
        <div className="border border-dashed border-card-border bg-card p-10 text-center text-[13px] text-muted-foreground">
          No schema fields yet.
        </div>
      ) : (
        <div className="border border-card-border bg-card overflow-x-auto">
          <table className="w-full text-[12.5px]">
            <thead>
              <tr className="border-b border-card-border text-left text-muted-foreground">
                <th className="px-3 py-2 font-medium">Identifier</th>
                <th className="px-3 py-2 font-medium">Label</th>
                <th className="px-3 py-2 font-medium">Type</th>
                <th className="px-3 py-2 font-medium">Cardinality</th>
                <th className="px-3 py-2 font-medium">Default</th>
                <th className="px-3 py-2 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {template.schemaFields.map((f) => (
                <tr
                  key={f.id}
                  className="border-b border-card-border last:border-0 hover:bg-muted/30"
                  data-testid={`row-field-${f.id}`}
                >
                  <td className="px-3 py-2">
                    <code className="text-[11.5px] text-foreground">
                      %{f.id}%
                    </code>
                  </td>
                  <td className="px-3 py-2 text-foreground">
                    <span className="inline-flex items-center gap-1.5">
                      {f.label}
                      {f.hidden && (
                        <EyeOff className="w-3 h-3 text-muted-foreground" />
                      )}
                    </span>
                  </td>
                  <td className="px-3 py-2">
                    <span className="text-[10px] uppercase tracking-wide border border-card-border px-1.5 py-0.5 text-muted-foreground">
                      {f.type === "media" ? "Media" : "Rich text"}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-muted-foreground">
                    {f.multi ? "Multi" : "Single"}
                  </td>
                  <td className="px-3 py-2 text-muted-foreground max-w-[220px] truncate">
                    {f.defaultValue || "—"}
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        type="button"
                        onClick={() => openEdit(f)}
                        className="w-7 h-7 inline-flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/40"
                        title="Edit field"
                        data-testid={`button-edit-field-${f.id}`}
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => removeField(f.id, f.label)}
                        className="w-7 h-7 inline-flex items-center justify-center text-muted-foreground hover:text-red-600 hover:bg-red-50"
                        title="Delete field"
                        data-testid={`button-delete-field-${f.id}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editingId ? "Edit field" : "Add field"}
        testId="modal-field"
        maxWidthClass="max-w-lg"
        footer={
          <>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:bg-muted/40"
              data-testid="button-cancel-field"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={save}
              disabled={
                !draft.label.trim() ||
                !(draft.id || draft.label).trim() ||
                updateSchema.isPending
              }
              className="px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
              data-testid="button-save-field"
            >
              {updateSchema.isPending ? "Saving…" : "Save field"}
            </button>
          </>
        }
      >
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelCls}>Label</label>
              <input
                autoFocus
                value={draft.label}
                onChange={(e) => setLabel(e.target.value)}
                className={inputCls}
                placeholder="e.g. Headline"
                data-testid="input-field-label"
              />
            </div>
            <div>
              <label className={labelCls}>Identifier</label>
              <input
                value={draft.id}
                onChange={(e) => {
                  setIdTouched(true);
                  setDraft((d) => ({ ...d, id: e.target.value }));
                }}
                className={`${inputCls} font-mono`}
                placeholder="headline"
                data-testid="input-field-id"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelCls}>Type</label>
              <select
                value={draft.type}
                onChange={(e) =>
                  setDraft((d) => ({
                    ...d,
                    type: e.target.value as "media" | "rich_text",
                  }))
                }
                className={inputCls}
                data-testid="select-field-type"
              >
                <option value="rich_text">Rich Text</option>
                <option value="media">Media</option>
              </select>
            </div>
            <div>
              <label className={labelCls}>Cardinality</label>
              <select
                value={draft.multi ? "multi" : "single"}
                onChange={(e) =>
                  setDraft((d) => ({
                    ...d,
                    multi: e.target.value === "multi",
                  }))
                }
                className={inputCls}
                data-testid="select-field-multi"
              >
                <option value="single">Single</option>
                <option value="multi">Multi</option>
              </select>
            </div>
          </div>
          <div>
            <label className={labelCls}>Semantic description</label>
            <textarea
              value={draft.description ?? ""}
              onChange={(e) =>
                setDraft((d) => ({ ...d, description: e.target.value }))
              }
              rows={2}
              className={inputCls}
              placeholder="What this field represents and how it is used."
              data-testid="input-field-description"
            />
          </div>
          <div>
            <label className={labelCls}>Default value</label>
            <input
              value={draft.defaultValue ?? ""}
              onChange={(e) =>
                setDraft((d) => ({ ...d, defaultValue: e.target.value }))
              }
              className={inputCls}
              placeholder={
                draft.type === "media"
                  ? "Asset id (optional)"
                  : "Default copy (supports %tokens%)"
              }
              data-testid="input-field-default"
            />
          </div>

          {draft.type === "media" && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className={labelCls}>Allowed formats</label>
                <div className="flex flex-wrap gap-1.5">
                  {FORMAT_OPTIONS.map((fmt) => {
                    const on = (draft.allowedFormats ?? []).includes(fmt);
                    return (
                      <button
                        key={fmt}
                        type="button"
                        onClick={() => toggleFormat(fmt)}
                        className={`px-2 py-1 text-[11px] uppercase border ${
                          on
                            ? "border-[hsl(var(--primary))] bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]"
                            : "border-card-border bg-card text-muted-foreground hover:bg-muted/40"
                        }`}
                        data-testid={`toggle-format-${fmt}`}
                      >
                        {fmt}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div>
                <label className={labelCls}>Max media size (MB)</label>
                <input
                  type="number"
                  min={0}
                  value={draft.maxSizeMB ?? ""}
                  onChange={(e) =>
                    setDraft((d) => ({
                      ...d,
                      maxSizeMB: e.target.value
                        ? Number(e.target.value)
                        : undefined,
                    }))
                  }
                  className={inputCls}
                  placeholder="e.g. 8"
                  data-testid="input-field-maxsize"
                />
              </div>
            </div>
          )}

          <label
            className="flex items-center gap-2 text-[12.5px] text-foreground cursor-pointer"
            data-testid="toggle-field-hidden"
          >
            <input
              type="checkbox"
              checked={!!draft.hidden}
              onChange={(e) =>
                setDraft((d) => ({ ...d, hidden: e.target.checked }))
              }
              className="accent-[hsl(var(--primary))]"
            />
            Hide field from the creative editor
          </label>
        </div>
      </Modal>

      <Modal
        open={importOpen}
        onClose={() => setImportOpen(false)}
        title="Import parameters"
        testId="modal-import-fields"
        maxWidthClass="max-w-lg"
        footer={
          <>
            <button
              type="button"
              onClick={() => setImportOpen(false)}
              className="px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:bg-muted/40"
              data-testid="button-cancel-import"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={runImport}
              disabled={!importText.trim() || updateSchema.isPending}
              className="px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
              data-testid="button-run-import"
            >
              {updateSchema.isPending ? "Importing…" : "Import fields"}
            </button>
          </>
        }
      >
        <div className="space-y-3">
          <p className="text-[12px] text-muted-foreground">
            Paste a parameter set as JSON — either a full template export (with a{" "}
            <code className="text-foreground">schemaFields</code> array) or a
            bare array of fields. Fields are merged by id; matching ids are
            overwritten and new ones appended.
          </p>
          <div>
            <label className={labelCls}>Load from .json file</label>
            <input
              type="file"
              accept="application/json,.json"
              onChange={(e) => onImportFile(e.target.files?.[0])}
              className="text-[12px] text-foreground file:mr-2 file:border file:border-card-border file:bg-card file:px-2 file:py-1 file:text-[12px] file:text-foreground"
              data-testid="input-import-file"
            />
          </div>
          <div>
            <label className={labelCls}>Or paste JSON</label>
            <textarea
              value={importText}
              onChange={(e) => {
                setImportText(e.target.value);
                if (importError) setImportError(null);
              }}
              rows={9}
              spellCheck={false}
              placeholder={'[\n  { "id": "headline", "label": "Headline", "type": "rich_text" }\n]'}
              className="w-full border border-card-border bg-background px-2.5 py-1.5 text-[12px] font-mono text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
              data-testid="textarea-import-json"
            />
          </div>
          {importError && (
            <p
              className="text-[12px] text-red-600"
              data-testid="text-import-error"
            >
              {importError}
            </p>
          )}
        </div>
      </Modal>
    </div>
  );
}

/* ------------------------------- output tab ----------------------------- */

function OutputTab({ template }: { template: StudioTemplate }) {
  const updateOutput = useUpdateOutput(template.id);
  const [formats, setFormats] = useState<Record<string, string[]>>(
    template.output.formatsByVariant ?? {},
  );

  useEffect(() => {
    setFormats(template.output.formatsByVariant ?? {});
  }, [template.output.formatsByVariant]);

  const persist = (next: Record<string, string[]>) => {
    setFormats(next);
    updateOutput.mutate(next);
  };

  // Static formats apply to every dimension; dynamic formats (gif/html5) are
  // only meaningful for animated (dynamic) variants.
  const applicableFormats = (v: StudioVariant): string[] =>
    v.type === "dynamic"
      ? [...STUDIO_STATIC_FORMATS, ...STUDIO_DYNAMIC_FORMATS]
      : [...STUDIO_STATIC_FORMATS];

  const toggle = (variantId: string, fmt: string) => {
    const cur = formats[variantId] ?? [];
    const has = cur.includes(fmt);
    const nextList = has ? cur.filter((f) => f !== fmt) : [...cur, fmt];
    persist({ ...formats, [variantId]: nextList });
  };

  const toggleAll = (v: StudioVariant) => {
    const cur = formats[v.id] ?? [];
    const applicable = applicableFormats(v);
    const all = applicable.every((f) => cur.includes(f));
    persist({
      ...formats,
      [v.id]: all ? [] : applicable,
    });
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(template, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${slugify(template.name) || "template"}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <p className="text-[12px] text-muted-foreground">
          Choose the export formats produced for each dimension.
        </p>
        <button
          type="button"
          onClick={exportJson}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:bg-muted/40"
          data-testid="button-export-template-json"
        >
          <Download className="w-3.5 h-3.5" /> Export template JSON
        </button>
      </div>

      {template.variants.length === 0 ? (
        <div className="border border-dashed border-card-border bg-card p-10 text-center text-[13px] text-muted-foreground">
          Add a dimension to configure outputs.
        </div>
      ) : (
        <div className="border border-card-border bg-card overflow-x-auto">
          <table className="w-full text-[12.5px]">
            <thead>
              <tr className="border-b border-card-border text-left text-muted-foreground">
                <th className="px-3 py-2 font-medium">Dimension</th>
                {STUDIO_STATIC_FORMATS.map((f) => (
                  <th
                    key={f}
                    className="px-3 py-2 font-medium text-center uppercase"
                  >
                    {f}
                  </th>
                ))}
                {STUDIO_DYNAMIC_FORMATS.map((f) => (
                  <th
                    key={f}
                    className="px-3 py-2 font-medium text-center uppercase border-l border-card-border"
                    title="Animated outputs (dynamic dimensions only)"
                  >
                    {f}
                  </th>
                ))}
                <th className="px-3 py-2 font-medium text-center">All</th>
              </tr>
            </thead>
            <tbody>
              {template.variants.map((v) => {
                const cur = formats[v.id] ?? [];
                const isDynamic = v.type === "dynamic";
                const all = applicableFormats(v).every((f) =>
                  cur.includes(f),
                );
                return (
                  <tr
                    key={v.id}
                    className="border-b border-card-border last:border-0 hover:bg-muted/30"
                    data-testid={`row-output-${v.id}`}
                  >
                    <td className="px-3 py-2">
                      <div className="text-foreground">{v.name}</div>
                      <div className="text-[11px] text-muted-foreground tabular-nums">
                        {v.width}×{v.height} · {v.type}
                      </div>
                    </td>
                    {STUDIO_STATIC_FORMATS.map((f) => (
                      <td key={f} className="px-3 py-2 text-center">
                        <input
                          type="checkbox"
                          checked={cur.includes(f)}
                          onChange={() => toggle(v.id, f)}
                          className="accent-[hsl(var(--primary))]"
                          data-testid={`checkbox-output-${v.id}-${f}`}
                        />
                      </td>
                    ))}
                    {STUDIO_DYNAMIC_FORMATS.map((f) => (
                      <td
                        key={f}
                        className="px-3 py-2 text-center border-l border-card-border"
                      >
                        {isDynamic ? (
                          <input
                            type="checkbox"
                            checked={cur.includes(f)}
                            onChange={() => toggle(v.id, f)}
                            className="accent-[hsl(var(--primary))]"
                            data-testid={`checkbox-output-${v.id}-${f}`}
                          />
                        ) : (
                          <span
                            className="text-muted-foreground/50"
                            title="Animated formats need a dynamic dimension"
                          >
                            —
                          </span>
                        )}
                      </td>
                    ))}
                    <td className="px-3 py-2 text-center">
                      <input
                        type="checkbox"
                        checked={all}
                        onChange={() => toggleAll(v)}
                        className="accent-[hsl(var(--primary))]"
                        data-testid={`checkbox-output-all-${v.id}`}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* --------------------------------- page --------------------------------- */

type SubTab = "variants" | "schema" | "output";

const SUBTABS: { key: SubTab; label: string; icon: ReactNode }[] = [
  { key: "variants", label: "Variants", icon: <Layers className="w-3.5 h-3.5" /> },
  { key: "schema", label: "Schema", icon: <ListTree className="w-3.5 h-3.5" /> },
  {
    key: "output",
    label: "Output & export",
    icon: <FileOutput className="w-3.5 h-3.5" />,
  },
];

export default function TemplateDetailPage() {
  const params = useParams();
  const id = params.id ?? "";
  const { data: template, isLoading } = useTemplate(id);
  const { data: assets = [] } = useAssets();
  const updateTemplate = useUpdateTemplate(id);

  const [tab, setTab] = useState<SubTab>("variants");
  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");

  useEffect(() => {
    if (template) {
      setName(template.name);
      setBrand(template.brand ?? "");
    }
  }, [template]);

  const assetsById = useMemo(
    () => Object.fromEntries(assets.map((a) => [a.id, a])),
    [assets],
  );

  const values = useMemo(() => {
    if (!template) return {};
    return Object.fromEntries(
      template.schemaFields.map((f) => [
        f.id,
        f.defaultValue ??
          (f.type === "media" ? f.preselectedAssetIds?.[0] ?? "" : ""),
      ]),
    );
  }, [template]);

  const commitName = () => {
    const trimmed = name.trim();
    if (template && trimmed && trimmed !== template.name) {
      updateTemplate.mutate({ name: trimmed });
    } else if (template) {
      setName(template.name);
    }
  };

  const commitBrand = () => {
    if (!template) return;
    const trimmed = brand.trim();
    if (trimmed !== (template.brand ?? "")) {
      updateTemplate.mutate({ brand: trimmed || undefined });
    }
  };

  return (
    <StudioLayout active="templates">
      <div className="p-6">
        <Link
          href="/studio/templates"
          className="inline-flex items-center gap-1.5 text-[12px] text-muted-foreground hover:text-foreground mb-4"
          data-testid="link-back-templates"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Templates
        </Link>

        {isLoading ? (
          <div className="text-[13px] text-muted-foreground">
            Loading template…
          </div>
        ) : !template ? (
          <div className="border border-dashed border-card-border bg-card p-10 text-center text-[13px] text-muted-foreground">
            Template not found.
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="flex flex-wrap items-end gap-x-6 gap-y-3 mb-5">
              <div className="min-w-[240px]">
                <label className="block text-[11px] uppercase tracking-wide text-muted-foreground mb-1">
                  Template name
                </label>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onBlur={commitName}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") e.currentTarget.blur();
                  }}
                  className="text-[18px] font-semibold text-foreground bg-transparent border-b border-transparent hover:border-card-border focus:border-[hsl(var(--primary))] focus:outline-none w-full"
                  data-testid="input-detail-name"
                />
              </div>
              <div className="min-w-[200px]">
                <label className="block text-[11px] uppercase tracking-wide text-muted-foreground mb-1">
                  Connected brand
                </label>
                <input
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                  onBlur={commitBrand}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") e.currentTarget.blur();
                  }}
                  placeholder="No brand connected"
                  className="text-[13px] text-foreground bg-transparent border-b border-transparent hover:border-card-border focus:border-[hsl(var(--primary))] focus:outline-none w-full py-1"
                  data-testid="input-detail-brand"
                />
              </div>
              <div className="flex items-center gap-3 text-[11.5px] text-muted-foreground ml-auto">
                <span className="inline-flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5" />
                  {template.variants.length} dimensions
                </span>
                <span className="inline-flex items-center gap-1">
                  <ListTree className="w-3.5 h-3.5" />
                  {template.schemaFields.length} fields
                </span>
              </div>
            </div>

            {/* Sub-tabs */}
            <div className="flex items-end gap-0.5 border-b border-card-border mb-5">
              {SUBTABS.map((s) => (
                <button
                  key={s.key}
                  type="button"
                  onClick={() => setTab(s.key)}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-[12.5px] border-b-2 -mb-px transition-colors ${
                    tab === s.key
                      ? "border-[hsl(var(--primary))] text-foreground font-medium"
                      : "border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/40"
                  }`}
                  data-testid={`subtab-${s.key}`}
                >
                  {s.icon}
                  {s.label}
                </button>
              ))}
            </div>

            {tab === "variants" && (
              <VariantsTab
                template={template}
                values={values}
                assetsById={assetsById}
              />
            )}
            {tab === "schema" && <SchemaTab template={template} />}
            {tab === "output" && <OutputTab template={template} />}
          </>
        )}
      </div>

      <StudioAgentPanel
        templateId={id}
        scopeLabel={template?.name ?? "Template"}
      />
    </StudioLayout>
  );
}
