/**
 * Creative Studio — Feed detail. A spreadsheet grid of creatives (rows) bound
 * to the feed's template schema:
 *   - inline edit of UID / locale / tags and every rich-text field,
 *   - media cells backed by the shared MediaPicker (real asset thumbnails),
 *   - add / delete creative rows,
 *   - open a single creative in the multi-dimension editor,
 *   - jump to the full preview-all surface.
 * Text edits persist on blur; media picks persist immediately.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "wouter";
import {
  ArrowLeft,
  Plus,
  Trash2,
  Maximize2,
  Image as ImageIcon,
  Eye,
  LayoutTemplate,
  Loader2,
  Sparkles,
  Wand2,
  X,
  Move,
  Crop as CropIcon,
  RotateCcw,
  ExternalLink,
  SlidersHorizontal,
  Lock,
} from "lucide-react";
import { StudioLayout } from "@/components/studio/StudioLayout";
import { MediaPicker } from "@/components/studio/MediaPicker";
import { StudioAgentPanel } from "@/components/studio/StudioAgentPanel";
import StudioKonva from "@/components/studio/StudioKonva";
import {
  GenerateVariantsModal,
  AutofillModal,
  ImproveCreativeModal,
} from "@/components/studio/agent-modals";
import { assetFileUrl, mergeValues } from "@/components/studio/scene";
import {
  useFeed,
  useTemplate,
  useAssets,
  useUpdateFeed,
  useAddRow,
  useUpdateRow,
  useDeleteRow,
} from "@/lib/studio-api";
import type {
  StudioAsset,
  StudioCreativeRow,
  StudioCropOverride,
  StudioStyleOverride,
  StudioImageLayer,
  StudioSchemaField,
  StudioTemplate,
  StudioVariant,
} from "@/components/studio/types";

const cellInput =
  "w-full bg-transparent px-2 py-1.5 text-[12.5px] text-foreground focus:outline-none focus:bg-[hsl(var(--primary))]/5";

interface PickerTarget {
  rowId: string;
  fieldId: string;
}

function MediaCell({
  assetId,
  assetsById,
  onPick,
  onClear,
}: {
  assetId: string | undefined;
  assetsById: Record<string, StudioAsset>;
  onPick: () => void;
  onClear: () => void;
}) {
  const asset = assetId ? assetsById[assetId] : undefined;
  return (
    <div className="flex items-center gap-1.5 px-1.5 py-1">
      <button
        type="button"
        onClick={onPick}
        className="w-9 h-9 flex-shrink-0 bg-muted border border-card-border flex items-center justify-center overflow-hidden hover:border-[hsl(var(--primary))]"
        title={asset ? asset.originalName : "Choose media"}
        data-testid="cell-media-pick"
      >
        {asset ? (
          <img
            src={assetFileUrl(asset.fileName)}
            crossOrigin="anonymous"
            alt={asset.originalName}
            className="w-full h-full object-contain"
          />
        ) : (
          <ImageIcon className="w-4 h-4 text-muted-foreground" />
        )}
      </button>
      <div className="min-w-0">
        {asset ? (
          <>
            <div className="text-[11px] text-foreground truncate max-w-[120px]">
              {asset.originalName}
            </div>
            <button
              type="button"
              onClick={onClear}
              className="text-[10.5px] text-muted-foreground hover:text-red-600"
              data-testid="cell-media-clear"
            >
              Clear
            </button>
          </>
        ) : (
          <button
            type="button"
            onClick={onPick}
            className="text-[11px] text-[hsl(var(--primary))] hover:underline"
          >
            Choose…
          </button>
        )}
      </div>
    </div>
  );
}

function CreativeRow({
  feedId,
  row,
  index,
  fields,
  assetsById,
  onOpenPicker,
  selected,
  onSelect,
}: {
  feedId: string;
  row: StudioCreativeRow;
  index: number;
  fields: StudioSchemaField[];
  assetsById: Record<string, StudioAsset>;
  onOpenPicker: (target: PickerTarget) => void;
  selected: boolean;
  onSelect: (rowId: string) => void;
}) {
  const updateRow = useUpdateRow(feedId);
  const deleteRow = useDeleteRow(feedId);

  // Local draft so typing is smooth; persist on blur.
  const [uid, setUid] = useState(row.uid);
  const [locale, setLocale] = useState(row.locale);
  const [tags, setTags] = useState(row.tags.join(", "));
  const [values, setValues] = useState<Record<string, string>>(row.values);

  const persist = (patch: Partial<StudioCreativeRow>) => {
    updateRow.mutate({ rowId: row.id, ...patch });
  };

  const persistValuesIfChanged = (fieldId: string, next: string) => {
    if ((row.values[fieldId] ?? "") === next) return;
    // Merge into the freshest persisted values (not stale local state) so a
    // concurrently-picked media asset is never dropped.
    persist({ values: { ...row.values, [fieldId]: next } });
  };

  const remove = () => {
    if (!window.confirm(`Delete creative “${row.uid || row.id}”?`)) return;
    deleteRow.mutate(row.id);
  };

  return (
    <tr
      onClick={() => onSelect(row.id)}
      className={`border-b border-card-border cursor-pointer ${
        selected
          ? "bg-[hsl(var(--primary))]/5 outline outline-1 outline-[hsl(var(--primary))]"
          : "hover:bg-muted/30"
      }`}
      data-testid={`feed-row-${row.id}`}
      data-selected={selected ? "true" : "false"}
    >
      <td className="px-2 py-1 text-[11px] text-muted-foreground tabular-nums text-center border-r border-card-border">
        {index + 1}
      </td>
      <td className="border-r border-card-border min-w-[140px]">
        <input
          value={uid}
          onChange={(e) => setUid(e.target.value)}
          onBlur={() => uid !== row.uid && persist({ uid })}
          placeholder="uid"
          className={cellInput}
          data-testid={`cell-uid-${row.id}`}
        />
      </td>
      <td className="border-r border-card-border min-w-[90px]">
        <input
          value={locale}
          onChange={(e) => setLocale(e.target.value)}
          onBlur={() => locale !== row.locale && persist({ locale })}
          placeholder="en-US"
          className={cellInput}
          data-testid={`cell-locale-${row.id}`}
        />
      </td>
      <td className="border-r border-card-border min-w-[140px]">
        <input
          value={tags}
          onChange={(e) => setTags(e.target.value)}
          onBlur={() => {
            const next = tags
              .split(",")
              .map((t) => t.trim())
              .filter(Boolean);
            if (next.join(",") !== row.tags.join(","))
              persist({ tags: next });
          }}
          placeholder="tag1, tag2"
          className={cellInput}
          data-testid={`cell-tags-${row.id}`}
        />
      </td>
      {fields.map((f) => (
        <td
          key={f.id}
          className="border-r border-card-border min-w-[180px] align-middle"
        >
          {f.type === "media" ? (
            <MediaCell
              assetId={row.values[f.id]}
              assetsById={assetsById}
              onPick={() => onOpenPicker({ rowId: row.id, fieldId: f.id })}
              onClear={() =>
                persist({ values: { ...row.values, [f.id]: "" } })
              }
            />
          ) : (
            <input
              value={values[f.id] ?? ""}
              onChange={(e) =>
                setValues((v) => ({ ...v, [f.id]: e.target.value }))
              }
              onBlur={() => persistValuesIfChanged(f.id, values[f.id] ?? "")}
              placeholder={f.label}
              className={cellInput}
              data-testid={`cell-field-${f.id}-${row.id}`}
            />
          )}
        </td>
      ))}
      <td className="px-1.5 py-1 whitespace-nowrap">
        <div className="flex items-center gap-1">
          <Link
            href={`/studio/feeds/${feedId}/creative/${row.id}`}
            className="inline-flex items-center gap-1 px-2 py-1 text-[11.5px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))]"
            data-testid={`button-open-creative-${row.id}`}
          >
            <Maximize2 className="w-3 h-3" /> Open
          </Link>
          <button
            type="button"
            onClick={remove}
            className="w-7 h-7 flex items-center justify-center text-muted-foreground hover:text-red-600 hover:bg-red-50"
            title="Delete creative"
            data-testid={`button-delete-creative-${row.id}`}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </td>
    </tr>
  );
}

const IDENTITY_CROP: StudioCropOverride = { x: 0, y: 0, scale: 1 };

/**
 * In-feed inspector for the selected creative (adtune parity). Shows a live
 * single-dimension preview with DIRECT on-canvas crop (drag focal point, scroll
 * to zoom), an AI "improve copy" entry point, and a read-only view of the
 * template-level layer styles (opacity / corner radius / blur) that deep-links
 * to the template editor where they're authored feed-wide.
 */
function FeedInspector({
  feedId,
  template,
  row,
  assetsById,
  onClose,
  onImprove,
}: {
  feedId: string;
  template: StudioTemplate;
  row: StudioCreativeRow;
  assetsById: Record<string, StudioAsset>;
  onClose: () => void;
  onImprove: () => void;
}) {
  const updateRow = useUpdateRow(feedId);

  const mediaFields = useMemo(
    () => template.schemaFields.filter((f) => f.type === "media"),
    [template],
  );
  const schemaDefaults = useMemo(() => {
    const m: Record<string, string> = {};
    for (const f of template.schemaFields) if (f.defaultValue) m[f.id] = f.defaultValue;
    return m;
  }, [template]);
  const mergedValues = useMemo(
    () => mergeValues(schemaDefaults, row.values),
    [schemaDefaults, row.values],
  );

  const [variantId, setVariantId] = useState(template.variants[0]?.id ?? "");
  const [cropField, setCropField] = useState<string>(mediaFields[0]?.id ?? "");
  const [crops, setCrops] = useState<Record<string, StudioCropOverride>>(
    row.crops ?? {},
  );
  // Per-creative layer-style overrides keyed by fieldId (opacity / corner radius
  // / blur). Mirrors `crops`: one draft, edited a field at a time, applied across
  // every dimension via the preview's `styleOverrides` prop.
  const [styleOverrides, setStyleOverrides] = useState<
    Record<string, StudioStyleOverride>
  >(row.styleOverrides ?? {});

  // Reset the draft + active selections only when a DIFFERENT creative is
  // selected — never on an in-flight crop write coming back through the cache.
  const loadedRef = useRef<string | null>(null);
  useEffect(() => {
    if (loadedRef.current === row.id) return;
    loadedRef.current = row.id;
    setCrops(row.crops ?? {});
    setStyleOverrides(row.styleOverrides ?? {});
    setVariantId((v) => (template.variants.some((x) => x.id === v) ? v : template.variants[0]?.id ?? ""));
    setCropField((f) => (mediaFields.some((x) => x.id === f) ? f : mediaFields[0]?.id ?? ""));
  }, [row.id, row.crops, row.styleOverrides, template.variants, mediaFields]);

  const variant: StudioVariant | undefined =
    template.variants.find((v) => v.id === variantId) ?? template.variants[0];

  const handleCropDraft = useCallback((fieldId: string, crop: StudioCropOverride) => {
    setCrops((c) => ({ ...c, [fieldId]: crop }));
  }, []);
  const handleEnterCrop = useCallback((fieldId: string) => {
    setCropField(fieldId);
  }, []);

  const activeCrop = cropField ? crops[cropField] ?? IDENTITY_CROP : IDENTITY_CROP;
  const cropAssetId = cropField ? mergedValues[cropField] ?? "" : "";
  // Track dirtiness for the ACTIVE field only, against the freshest cache. The
  // inspector edits a single field at a time, so this both keeps the Save button
  // honest and avoids treating a concurrent change to another field as "dirty".
  const serverCrop = cropField ? (row.crops ?? {})[cropField] : undefined;
  const dirty =
    JSON.stringify(crops[cropField] ?? null) !== JSON.stringify(serverCrop ?? null);

  const saveCrops = () => {
    if (!cropField) return;
    const v = crops[cropField];
    if (!v) return;
    // Send only the active field so a concurrent save to a different field is
    // never overwritten by this inspector's (possibly stale) full map.
    updateRow.mutate({ rowId: row.id, crops: { [cropField]: v } });
  };
  const resetCropField = () => {
    if (!cropField) return;
    setCrops((c) => {
      const next = { ...c };
      delete next[cropField];
      return next;
    });
    // null = delete server-side; applies immediately so "Reset" is a real,
    // persisted action rather than a local-only revert.
    updateRow.mutate({ rowId: row.id, crops: { [cropField]: null } });
  };

  // Resolve the image layer bound to the active crop field so we can surface its
  // template-level styles as the editable baseline (the override layers on top).
  const styleLayer: StudioImageLayer | undefined = useMemo(() => {
    if (!variant || !cropField) return undefined;
    return variant.scene.layers.find(
      (l): l is StudioImageLayer => l.type === "image" && l.fieldId === cropField,
    );
  }, [variant, cropField]);

  // Effective per-field style = override merged over the template layer's
  // authored values. These drive both the sliders and the live preview.
  const activeStyle = cropField ? styleOverrides[cropField] : undefined;
  const effOpacity =
    activeStyle?.opacity ?? styleLayer?.opacity ?? 1;
  const effCornerRadius =
    activeStyle?.cornerRadius ?? styleLayer?.cornerRadius ?? 0;
  const effBlur = activeStyle?.blur ?? styleLayer?.blur ?? 0;

  const setStyleField = (patch: Partial<StudioStyleOverride>) => {
    if (!cropField) return;
    setStyleOverrides((s) => ({
      ...s,
      [cropField]: { ...s[cropField], ...patch },
    }));
  };

  const serverStyle = cropField
    ? (row.styleOverrides ?? {})[cropField]
    : undefined;
  const styleDirty =
    JSON.stringify(styleOverrides[cropField] ?? null) !==
    JSON.stringify(serverStyle ?? null);

  const saveStyle = () => {
    if (!cropField) return;
    const v = styleOverrides[cropField];
    if (!v) return;
    // Send only the active field so a concurrent save to a different field is
    // never clobbered by this inspector's (possibly stale) full map.
    updateRow.mutate({ rowId: row.id, styleOverrides: { [cropField]: v } });
  };
  const resetStyleField = () => {
    if (!cropField) return;
    setStyleOverrides((s) => {
      const next = { ...s };
      delete next[cropField];
      return next;
    });
    // null = delete server-side; reverts to the template layer's authored style.
    updateRow.mutate({ rowId: row.id, styleOverrides: { [cropField]: null } });
  };

  const box = 300;
  const scale = variant
    ? Math.min(box / variant.width, 300 / variant.height, 1)
    : 1;
  const w = variant ? Math.round(variant.width * scale) : 0;
  const h = variant ? Math.round(variant.height * scale) : 0;

  return (
    <aside
      className="w-[360px] flex-shrink-0 border border-card-border bg-card self-start sticky top-4 max-h-[calc(100vh-2rem)] overflow-auto"
      data-testid="feed-inspector"
    >
      <div className="flex items-center justify-between border-b border-card-border px-3 py-2.5">
        <div className="min-w-0">
          <div className="text-[10.5px] uppercase tracking-wide text-muted-foreground">
            Inspector
          </div>
          <div className="text-[13px] font-semibold text-foreground truncate">
            {row.uid || row.id}
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="text-muted-foreground hover:text-foreground"
          data-testid="button-inspector-close"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-3 space-y-4">
        {/* Dimension selector + preview */}
        {variant ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10.5px] uppercase tracking-wide text-muted-foreground">
                Preview
              </span>
              <select
                value={variantId}
                onChange={(e) => setVariantId(e.target.value)}
                className="border border-card-border bg-background px-1.5 py-1 text-[11.5px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))] max-w-[180px]"
                data-testid="select-inspector-variant"
              >
                {template.variants.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name} · {v.width}×{v.height}
                  </option>
                ))}
              </select>
            </div>
            <div
              className="bg-muted border border-card-border flex items-center justify-center mx-auto"
              style={{ width: w, height: h }}
            >
              <StudioKonva
                scene={variant.scene}
                width={variant.width}
                height={variant.height}
                scale={scale}
                values={mergedValues}
                assetsById={assetsById}
                crops={crops}
                styleOverrides={styleOverrides}
                cropFieldId={cropField || null}
                onCropDraft={handleCropDraft}
                onEnterCrop={handleEnterCrop}
              />
            </div>
          </div>
        ) : (
          <div className="text-[12px] text-muted-foreground">
            This template has no dimensions to preview.
          </div>
        )}

        {/* Direct crop */}
        {mediaFields.length > 0 && (
          <section className="space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="text-[10.5px] uppercase tracking-wide text-muted-foreground inline-flex items-center gap-1">
                <CropIcon className="w-3 h-3" /> Crop image
              </h3>
              {mediaFields.length > 1 && (
                <select
                  value={cropField}
                  onChange={(e) => setCropField(e.target.value)}
                  className="border border-card-border bg-background px-1.5 py-1 text-[11.5px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
                  data-testid="select-inspector-cropfield"
                >
                  {mediaFields.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.label}
                      {crops[f.id] ? " (cropped)" : ""}
                    </option>
                  ))}
                </select>
              )}
            </div>

            {cropAssetId ? (
              <>
                <div className="flex items-start gap-1.5 border border-card-border bg-muted/40 px-2.5 py-2 text-[11px] text-muted-foreground">
                  <Move className="w-3.5 h-3.5 mt-px flex-shrink-0 text-[hsl(var(--primary))]" />
                  <span>
                    Drag the image in the preview to reposition the focal point;
                    scroll to zoom. One crop applies across every dimension.
                  </span>
                </div>
                <div>
                  <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1">
                    <span>Zoom</span>
                    <span className="tabular-nums">
                      {Math.round((activeCrop.scale ?? 1) * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={100}
                    max={400}
                    value={Math.round((activeCrop.scale ?? 1) * 100)}
                    onChange={(e) =>
                      handleCropDraft(cropField, {
                        ...activeCrop,
                        scale: parseInt(e.target.value, 10) / 100,
                      })
                    }
                    className="w-full accent-[hsl(var(--primary))]"
                    data-testid="slider-inspector-zoom"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={saveCrops}
                    disabled={!dirty || updateRow.isPending}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
                    data-testid="button-inspector-save-crop"
                  >
                    {updateRow.isPending && (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    )}
                    Save crop
                  </button>
                  <button
                    type="button"
                    onClick={resetCropField}
                    disabled={!crops[cropField]}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12px] border border-card-border bg-card text-foreground hover:bg-muted/40 disabled:opacity-50"
                    data-testid="button-inspector-reset-crop"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Reset
                  </button>
                </div>
              </>
            ) : (
              <p className="text-[11.5px] text-muted-foreground">
                Pick a source image for{" "}
                <span className="text-foreground">
                  {mediaFields.find((f) => f.id === cropField)?.label ?? "this field"}
                </span>{" "}
                in the grid to crop it.
              </p>
            )}
          </section>
        )}

        {/* Per-creative layer styles (editable; overrides template defaults) */}
        {styleLayer && variant && (
          <section className="space-y-2.5">
            <h3 className="text-[10.5px] uppercase tracking-wide text-muted-foreground inline-flex items-center gap-1">
              <SlidersHorizontal className="w-3 h-3" /> Layer style
            </h3>
            <div>
              <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1">
                <span>Opacity</span>
                <span className="tabular-nums">
                  {Math.round(effOpacity * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(effOpacity * 100)}
                onChange={(e) =>
                  setStyleField({ opacity: parseInt(e.target.value, 10) / 100 })
                }
                className="w-full accent-[hsl(var(--primary))]"
                data-testid="slider-inspector-opacity"
              />
            </div>
            <div>
              <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1">
                <span>Corner radius</span>
                <span className="tabular-nums">{Math.round(effCornerRadius)}px</span>
              </div>
              <input
                type="range"
                min={0}
                max={120}
                value={Math.round(effCornerRadius)}
                onChange={(e) =>
                  setStyleField({ cornerRadius: parseInt(e.target.value, 10) })
                }
                className="w-full accent-[hsl(var(--primary))]"
                data-testid="slider-inspector-corner"
              />
            </div>
            <div>
              <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1">
                <span>Blur</span>
                <span className="tabular-nums">{Math.round(effBlur)}px</span>
              </div>
              <input
                type="range"
                min={0}
                max={80}
                value={Math.round(effBlur)}
                onChange={(e) =>
                  setStyleField({ blur: parseInt(e.target.value, 10) })
                }
                className="w-full accent-[hsl(var(--primary))]"
                data-testid="slider-inspector-blur"
              />
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={saveStyle}
                disabled={!styleDirty || updateRow.isPending}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
                data-testid="button-inspector-save-style"
              >
                {updateRow.isPending && (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                )}
                Save style
              </button>
              <button
                type="button"
                onClick={resetStyleField}
                disabled={!styleOverrides[cropField]}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12px] border border-card-border bg-card text-foreground hover:bg-muted/40 disabled:opacity-50"
                data-testid="button-inspector-reset-style"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Reset
              </button>
            </div>
            <p className="text-[11px] text-muted-foreground">
              Overrides this creative only, across every dimension. Reset reverts
              to the template default.
            </p>
            <Link
              href={`/studio/editor/${template.id}/${variant.id}`}
              className="inline-flex items-center gap-1 text-[11.5px] text-[hsl(var(--primary))] hover:underline"
              data-testid="link-inspector-template-editor"
            >
              Edit template defaults <ExternalLink className="w-3 h-3" />
            </Link>
          </section>
        )}

        {/* Agent improve */}
        <section className="space-y-2 border-t border-card-border pt-3">
          <button
            type="button"
            onClick={onImprove}
            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))]"
            data-testid="button-inspector-improve"
          >
            <Sparkles className="w-3.5 h-3.5 text-[hsl(var(--primary))]" /> Improve
            copy with AI
          </button>
          <Link
            href={`/studio/feeds/${feedId}/creative/${row.id}`}
            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))]"
            data-testid="button-inspector-open-editor"
          >
            <Maximize2 className="w-3.5 h-3.5" /> Open full editor
          </Link>
        </section>
      </div>
    </aside>
  );
}

export default function FeedDetailPage() {
  const params = useParams();
  const feedId = params.id as string;

  const { data: feed, isLoading } = useFeed(feedId);
  const { data: template } = useTemplate(feed?.templateId, {
    enabled: !!feed?.templateId,
  });
  const { data: assets = [] } = useAssets();

  const updateFeed = useUpdateFeed(feedId);
  const addRow = useAddRow(feedId);

  const [name, setName] = useState<string | null>(null);
  const [picker, setPicker] = useState<PickerTarget | null>(null);
  const [generateOpen, setGenerateOpen] = useState(false);
  const [autofillOpen, setAutofillOpen] = useState(false);
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);
  const [improveOpen, setImproveOpen] = useState(false);

  // Always derive the selected row from the FRESH feed cache so a crop/copy
  // write (or a delete) is reflected immediately; a deleted row auto-closes
  // the inspector because `find` returns undefined.
  const selectedRow = selectedRowId
    ? feed?.rows.find((r) => r.id === selectedRowId) ?? null
    : null;

  const assetsById = useMemo(
    () => Object.fromEntries(assets.map((a) => [a.id, a])),
    [assets],
  );

  const fields = useMemo(
    () => (template?.schemaFields ?? []).filter((f) => !f.hidden),
    [template],
  );

  const updateRowFromPicker = useUpdateRow(feedId);
  const onPickAsset = (assetId: string) => {
    if (!picker || !feed) return;
    const row = feed.rows.find((r) => r.id === picker.rowId);
    if (!row) return;
    updateRowFromPicker.mutate({
      rowId: picker.rowId,
      values: { ...row.values, [picker.fieldId]: assetId },
    });
    setPicker(null);
  };

  const addCreative = () => {
    const n = (feed?.rows.length ?? 0) + 1;
    addRow.mutate({
      uid: `creative-${n}`,
      locale: "en-US",
      tags: [],
      values: {},
    });
  };

  if (isLoading || !feed) {
    return (
      <StudioLayout active="feeds">
        <div className="p-6 text-[13px] text-muted-foreground flex items-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin" /> Loading feed…
        </div>
      </StudioLayout>
    );
  }

  return (
    <StudioLayout
      active="feeds"
      actions={
        <>
          <Link
            href={`/studio/feeds/${feedId}/preview`}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))]"
            data-testid="button-preview-all"
          >
            <Eye className="w-3.5 h-3.5" /> Preview all
          </Link>
          <button
            type="button"
            onClick={() => setAutofillOpen(true)}
            disabled={!template}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))] disabled:opacity-50"
            data-testid="button-autofill"
          >
            <Wand2 className="w-3.5 h-3.5" /> Autofill
          </button>
          <button
            type="button"
            onClick={() => setGenerateOpen(true)}
            disabled={!template}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))] disabled:opacity-50"
            data-testid="button-generate-with-ai"
          >
            <Sparkles className="w-3.5 h-3.5" /> Generate with AI
          </button>
          <button
            type="button"
            onClick={addCreative}
            disabled={addRow.isPending}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
            data-testid="button-add-creative"
          >
            <Plus className="w-3.5 h-3.5" /> Add creative
          </button>
        </>
      }
    >
      <div className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Link
            href="/studio/feeds"
            className="inline-flex items-center gap-1 text-[12.5px] text-muted-foreground hover:text-foreground"
            data-testid="link-back-feeds"
          >
            <ArrowLeft className="w-4 h-4" /> Feeds
          </Link>
        </div>

        <div className="flex flex-wrap items-end gap-x-4 gap-y-2 mb-4">
          <div>
            <span className="block text-[10.5px] uppercase tracking-wide text-muted-foreground mb-1">
              Feed name
            </span>
            <input
              value={name ?? feed.name}
              onChange={(e) => setName(e.target.value)}
              onBlur={() => {
                const trimmed = (name ?? feed.name).trim();
                if (trimmed && trimmed !== feed.name)
                  updateFeed.mutate({ name: trimmed });
                setName(null);
              }}
              className="text-[18px] font-semibold text-foreground bg-transparent border-b border-transparent hover:border-card-border focus:border-[hsl(var(--primary))] focus:outline-none"
              data-testid="input-feed-name"
            />
          </div>
          {template && (
            <Link
              href={`/studio/templates/${template.id}`}
              className="inline-flex items-center gap-1 text-[12px] text-muted-foreground hover:text-[hsl(var(--primary))] pb-1.5"
              data-testid="link-feed-template"
            >
              <LayoutTemplate className="w-3.5 h-3.5" />
              {template.name}
            </Link>
          )}
          <span className="text-[12px] text-muted-foreground pb-1.5 tabular-nums">
            {feed.rows.length} {feed.rows.length === 1 ? "creative" : "creatives"}
            {" · "}
            {template?.variants.length ?? 0} dimensions
          </span>
        </div>

        {feed.rows.length === 0 ? (
          <div className="border border-dashed border-card-border bg-card p-10 text-center">
            <div className="w-10 h-10 mx-auto bg-muted flex items-center justify-center text-muted-foreground mb-3">
              <Plus className="w-5 h-5" />
            </div>
            <div className="text-[13px] font-medium text-foreground">
              No creatives yet
            </div>
            <p className="text-[12px] text-muted-foreground mt-1">
              Add a creative row and fill in the schema fields to drive every
              dimension.
            </p>
            <button
              type="button"
              onClick={addCreative}
              className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95"
              data-testid="button-add-creative-empty"
            >
              <Plus className="w-3.5 h-3.5" /> Add creative
            </button>
          </div>
        ) : (
          <div className="flex items-start gap-4">
            <div className="min-w-0 flex-1 border border-card-border bg-card overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-muted/50 border-b border-card-border text-left">
                    <th className="px-2 py-2 text-[10.5px] uppercase tracking-wide text-muted-foreground border-r border-card-border w-10 text-center">
                      #
                    </th>
                    <th className="px-2 py-2 text-[10.5px] uppercase tracking-wide text-muted-foreground border-r border-card-border">
                      UID
                    </th>
                    <th className="px-2 py-2 text-[10.5px] uppercase tracking-wide text-muted-foreground border-r border-card-border">
                      Locale
                    </th>
                    <th className="px-2 py-2 text-[10.5px] uppercase tracking-wide text-muted-foreground border-r border-card-border">
                      Tags
                    </th>
                    {fields.map((f) => (
                      <th
                        key={f.id}
                        className="px-2 py-2 text-[10.5px] uppercase tracking-wide text-muted-foreground border-r border-card-border"
                      >
                        <span className="inline-flex items-center gap-1">
                          {f.type === "media" && (
                            <ImageIcon className="w-3 h-3" />
                          )}
                          {f.label}
                        </span>
                      </th>
                    ))}
                    <th className="px-2 py-2 text-[10.5px] uppercase tracking-wide text-muted-foreground text-right">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {feed.rows.map((row, i) => (
                    <CreativeRow
                      key={row.id}
                      feedId={feedId}
                      row={row}
                      index={i}
                      fields={fields}
                      assetsById={assetsById}
                      onOpenPicker={setPicker}
                      selected={selectedRowId === row.id}
                      onSelect={setSelectedRowId}
                    />
                  ))}
                </tbody>
              </table>
            </div>

            {template && selectedRow && (
              <FeedInspector
                feedId={feedId}
                template={template}
                row={selectedRow}
                assetsById={assetsById}
                onClose={() => setSelectedRowId(null)}
                onImprove={() => setImproveOpen(true)}
              />
            )}
          </div>
        )}
      </div>

      <MediaPicker
        open={!!picker}
        onClose={() => setPicker(null)}
        onPick={onPickAsset}
        title="Select media for creative"
      />

      {template && (
        <>
          <GenerateVariantsModal
            open={generateOpen}
            onClose={() => setGenerateOpen(false)}
            templateId={template.id}
            feedId={feedId}
            template={template}
          />
          <AutofillModal
            open={autofillOpen}
            onClose={() => setAutofillOpen(false)}
            feedId={feedId}
            template={template}
            rows={feed.rows}
          />
          {selectedRow && (
            <ImproveCreativeModal
              open={improveOpen}
              onClose={() => setImproveOpen(false)}
              feedId={feedId}
              template={template}
              row={selectedRow}
            />
          )}
        </>
      )}

      <StudioAgentPanel
        feedId={feedId}
        templateId={feed.templateId}
        scopeLabel={feed.name}
        onGenerate={template ? () => setGenerateOpen(true) : undefined}
        onAutofill={template ? () => setAutofillOpen(true) : undefined}
        qaHref={`/studio/feeds/${feedId}/qa`}
      />
    </StudioLayout>
  );
}
