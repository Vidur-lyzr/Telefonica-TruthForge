/**
 * Creative Studio — Review & Distribution. The sign-off surface for a feed:
 *
 *  - A row×variant review matrix where each cell carries an approve /
 *    changes-requested / pending status (persisted via the review store).
 *  - A pack-level approval banner gating distribution.
 *  - The latest Matrix QA summary (populated by the QA surface).
 *  - Distribution: export the stored render set as a ZIP and hand the approved
 *    pack off to the DAM fixture, with a record of past handoffs.
 *
 * Every status mutation goes through the server review store; nothing here is
 * auto-generated — approvals are explicit user actions.
 */
import { useMemo } from "react";
import { Link, useParams } from "wouter";
import {
  ArrowLeft,
  Check,
  CircleDashed,
  Download,
  Loader2,
  RotateCcw,
  Send,
  ShieldCheck,
  TriangleAlert,
} from "lucide-react";
import { StudioLayout } from "@/components/studio/StudioLayout";
import { feedExportUrl } from "@/components/studio/scene";
import {
  useFeed,
  useTemplate,
  useRenders,
  useReview,
  useUpdateReviewEntry,
  useApprovePack,
  useDistributionHandoff,
} from "@/lib/studio-api";
import type {
  StudioReviewStatus,
  StudioReviewEntry,
} from "@/components/studio/types";

const STATUS_META: Record<
  StudioReviewStatus,
  { label: string; cls: string; icon: React.ReactNode }
> = {
  approved: {
    label: "Approved",
    cls: "bg-emerald-50 text-emerald-700 border-emerald-200",
    icon: <Check className="w-3 h-3" />,
  },
  changes_requested: {
    label: "Changes",
    cls: "bg-amber-50 text-amber-700 border-amber-200",
    icon: <TriangleAlert className="w-3 h-3" />,
  },
  pending: {
    label: "Pending",
    cls: "bg-muted text-muted-foreground border-card-border",
    icon: <CircleDashed className="w-3 h-3" />,
  },
};

function StatusPill({ status }: { status: StudioReviewStatus }) {
  const m = STATUS_META[status];
  return (
    <span
      className={`inline-flex items-center gap-1 px-1.5 py-0.5 text-[10px] uppercase tracking-wide border ${m.cls}`}
    >
      {m.icon} {m.label}
    </span>
  );
}

export default function StudioReviewPage() {
  const params = useParams();
  const feedId = params.id as string;

  const { data: feed, isLoading: feedLoading } = useFeed(feedId);
  const { data: template } = useTemplate(feed?.templateId);
  const { data: renders = [] } = useRenders(feedId);
  const { data: review } = useReview(feedId);

  const updateEntry = useUpdateReviewEntry(feedId);
  const approvePack = useApprovePack(feedId);
  const handoff = useDistributionHandoff();

  const rows = feed?.rows ?? [];
  const variants = useMemo(() => template?.variants ?? [], [template]);

  // Index review entries by `${rowId}:${variantId}` for O(1) cell lookups.
  const entryByKey = useMemo(() => {
    const m = new Map<string, StudioReviewEntry>();
    for (const e of review?.entries ?? []) m.set(`${e.rowId}:${e.variantId}`, e);
    return m;
  }, [review]);

  const cellCount = rows.length * variants.length;
  const approvedCount = useMemo(
    () =>
      (review?.entries ?? []).filter((e) => e.status === "approved").length,
    [review],
  );
  const changesCount = useMemo(
    () =>
      (review?.entries ?? []).filter((e) => e.status === "changes_requested")
        .length,
    [review],
  );
  const allApproved = cellCount > 0 && approvedCount >= cellCount;
  const packStatus = review?.packStatus ?? "pending";

  function setCell(
    rowId: string,
    variantId: string,
    status: StudioReviewStatus,
  ) {
    updateEntry.mutate({ rowId, variantId, status });
  }

  if (feedLoading || !feed) {
    return (
      <StudioLayout active="feeds">
        <div className="p-6 text-[13px] text-muted-foreground">Loading…</div>
      </StudioLayout>
    );
  }

  const qa = review?.qaSummary;
  const handoffs = review?.handoffs ?? [];

  return (
    <StudioLayout
      active="feeds"
      actions={
        <>
          <a
            href={feedExportUrl(feedId)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))] ${
              renders.length === 0 ? "pointer-events-none opacity-50" : ""
            }`}
            data-testid="button-review-export-zip"
          >
            <Download className="w-3.5 h-3.5" /> Export ZIP
          </a>
          <button
            type="button"
            disabled={packStatus === "approved" || approvePack.isPending}
            onClick={() => approvePack.mutate({ status: "approved" })}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
            data-testid="button-approve-pack"
          >
            {approvePack.isPending ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <ShieldCheck className="w-3.5 h-3.5" />
            )}
            {packStatus === "approved" ? "Pack approved" : "Approve pack"}
          </button>
        </>
      }
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-2">
          <Link
            href={`/studio/feeds/${feedId}/preview`}
            className="inline-flex items-center gap-1 text-[12.5px] text-muted-foreground hover:text-foreground"
            data-testid="link-back-preview"
          >
            <ArrowLeft className="w-4 h-4" /> {feed.name}
          </Link>
        </div>

        {/* Pack status banner */}
        <section
          className={`border p-4 flex items-center gap-3 ${
            packStatus === "approved"
              ? "border-emerald-200 bg-emerald-50"
              : "border-card-border bg-card"
          }`}
          data-testid="review-pack-banner"
        >
          <div
            className={`w-9 h-9 flex items-center justify-center ${
              packStatus === "approved"
                ? "bg-emerald-100 text-emerald-700"
                : "bg-muted text-muted-foreground"
            }`}
          >
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="text-[13px] font-semibold text-foreground flex items-center gap-2">
              {packStatus === "approved"
                ? "Creative pack approved"
                : "Awaiting pack approval"}
              <StatusPill status={packStatus} />
            </div>
            <p className="text-[12px] text-muted-foreground mt-0.5">
              {approvedCount}/{cellCount} cells approved
              {changesCount > 0 ? ` · ${changesCount} need changes` : ""}.{" "}
              {allApproved
                ? "All creatives signed off."
                : "Approve every creative×dimension below to clear the pack."}
            </p>
          </div>
        </section>

        {/* QA summary */}
        <section className="border border-card-border bg-card p-4">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-[13px] font-semibold text-foreground">
              Matrix QA summary
            </h2>
            <Link
              href={`/studio/feeds/${feedId}/qa`}
              className="text-[12px] text-[hsl(var(--primary))] hover:underline"
              data-testid="link-open-qa"
            >
              Open Matrix QA
            </Link>
          </div>
          {qa ? (
            <div className="flex flex-wrap items-center gap-x-6 gap-y-1.5 text-[12.5px]">
              <span className="text-foreground">
                <span className="font-semibold tabular-nums">
                  {qa.totalFindings}
                </span>{" "}
                findings
              </span>
              {Object.entries(qa.bySeverity).map(([sev, n]) => (
                <span key={sev} className="text-muted-foreground capitalize">
                  {sev}:{" "}
                  <span className="tabular-nums text-foreground">{n}</span>
                </span>
              ))}
              <span className="text-muted-foreground">
                Last run {new Date(qa.ranAt).toLocaleString()}
              </span>
            </div>
          ) : (
            <p className="text-[12.5px] text-muted-foreground">
              No QA run yet. Open Matrix QA to scan this feed.
            </p>
          )}
        </section>

        {/* Review matrix */}
        <section>
          <h2 className="text-[13px] font-semibold text-foreground mb-2.5">
            Review matrix
          </h2>
          {cellCount === 0 ? (
            <div className="border border-dashed border-card-border bg-card p-8 text-center text-[13px] text-muted-foreground">
              {rows.length === 0
                ? "This feed has no creatives yet."
                : "This template has no dimensions yet."}
            </div>
          ) : (
            <div className="border border-card-border bg-card overflow-x-auto">
              <table className="w-full border-collapse text-[12px]">
                <thead>
                  <tr className="border-b border-card-border">
                    <th className="text-left font-medium text-muted-foreground px-3 py-2 sticky left-0 bg-card">
                      Creative
                    </th>
                    {variants.map((v) => (
                      <th
                        key={v.id}
                        className="text-left font-medium text-muted-foreground px-3 py-2 border-l border-card-border whitespace-nowrap"
                      >
                        {v.name}
                        <span className="block text-[10px] tabular-nums opacity-70">
                          {v.width}×{v.height}
                        </span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr
                      key={r.id}
                      className="border-b border-card-border last:border-b-0"
                      data-testid={`review-row-${r.id}`}
                    >
                      <td className="px-3 py-2 align-top sticky left-0 bg-card">
                        <div className="text-[12.5px] font-medium text-foreground">
                          {r.uid || r.id}
                        </div>
                        <div className="text-[10.5px] text-muted-foreground">
                          {r.locale}
                        </div>
                      </td>
                      {variants.map((v) => {
                        const entry = entryByKey.get(`${r.id}:${v.id}`);
                        const status = entry?.status ?? "pending";
                        return (
                          <td
                            key={v.id}
                            className="px-3 py-2 align-top border-l border-card-border"
                            data-testid={`review-cell-${r.id}-${v.id}`}
                          >
                            <div className="flex flex-col gap-1.5">
                              <StatusPill status={status} />
                              <div className="inline-flex border border-card-border">
                                <button
                                  type="button"
                                  title="Approve"
                                  onClick={() =>
                                    setCell(r.id, v.id, "approved")
                                  }
                                  className={`p-1 border-r border-card-border ${
                                    status === "approved"
                                      ? "bg-emerald-600 text-white"
                                      : "bg-card text-muted-foreground hover:text-emerald-700 hover:bg-emerald-50"
                                  }`}
                                  data-testid={`approve-${r.id}-${v.id}`}
                                >
                                  <Check className="w-3 h-3" />
                                </button>
                                <button
                                  type="button"
                                  title="Request changes"
                                  onClick={() =>
                                    setCell(r.id, v.id, "changes_requested")
                                  }
                                  className={`p-1 border-r border-card-border ${
                                    status === "changes_requested"
                                      ? "bg-amber-500 text-white"
                                      : "bg-card text-muted-foreground hover:text-amber-700 hover:bg-amber-50"
                                  }`}
                                  data-testid={`changes-${r.id}-${v.id}`}
                                >
                                  <TriangleAlert className="w-3 h-3" />
                                </button>
                                <button
                                  type="button"
                                  title="Reset to pending"
                                  onClick={() => setCell(r.id, v.id, "pending")}
                                  className={`p-1 ${
                                    status === "pending"
                                      ? "bg-muted text-foreground"
                                      : "bg-card text-muted-foreground hover:bg-muted/60"
                                  }`}
                                  data-testid={`reset-${r.id}-${v.id}`}
                                >
                                  <RotateCcw className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Distribution */}
        <section className="border border-card-border bg-card p-4">
          <h2 className="text-[13px] font-semibold text-foreground mb-1">
            Distribution
          </h2>
          <p className="text-[12px] text-muted-foreground mb-3">
            Export the rendered set or hand the approved pack to the brand DAM.
            {packStatus !== "approved"
              ? " Pack approval is required before handoff."
              : ""}
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <a
              href={feedExportUrl(feedId)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))] ${
                renders.length === 0 ? "pointer-events-none opacity-50" : ""
              }`}
              data-testid="button-dist-export-zip"
            >
              <Download className="w-3.5 h-3.5" /> Export ZIP ({renders.length})
            </a>
            <button
              type="button"
              disabled={
                packStatus !== "approved" ||
                renders.length === 0 ||
                handoff.isPending
              }
              onClick={() =>
                handoff.mutate({ feedId, destination: "Brand DAM" })
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
              data-testid="button-dist-handoff"
            >
              {handoff.isPending ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Send className="w-3.5 h-3.5" />
              )}
              Hand off to DAM
            </button>
            {handoff.isError && (
              <span
                className="text-[11.5px] text-red-600"
                data-testid="handoff-error"
              >
                Handoff failed — try again.
              </span>
            )}
          </div>

          {handoffs.length > 0 && (
            <div className="mt-4 border-t border-card-border pt-3">
              <h3 className="text-[11.5px] uppercase tracking-wide text-muted-foreground mb-2">
                Handoff history
              </h3>
              <ul className="divide-y divide-card-border" data-testid="handoff-list">
                {[...handoffs]
                  .sort((a, b) => b.createdAt - a.createdAt)
                  .map((h) => (
                    <li
                      key={h.id}
                      className="flex items-center gap-3 py-2 text-[12px]"
                      data-testid={`handoff-${h.id}`}
                    >
                      <Send className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                      <span className="font-medium text-foreground">
                        {h.destination}
                      </span>
                      <span className="text-muted-foreground">
                        {h.renderCount} assets · {h.status}
                      </span>
                      {h.summary && (
                        <span className="text-muted-foreground truncate">
                          — {h.summary}
                        </span>
                      )}
                      <span className="ml-auto text-muted-foreground tabular-nums shrink-0">
                        {new Date(h.createdAt).toLocaleString()}
                      </span>
                    </li>
                  ))}
              </ul>
            </div>
          )}
        </section>
      </div>
    </StudioLayout>
  );
}
