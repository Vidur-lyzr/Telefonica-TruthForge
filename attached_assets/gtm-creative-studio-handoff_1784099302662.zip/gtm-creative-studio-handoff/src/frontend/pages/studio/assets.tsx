/**
 * Creative Studio — Asset Library. Bulk-upload images (and zips, unzipped
 * server-side) into the Images / Packshot pools, browse them with real
 * thumbnails, search, filter by tag, edit tags and delete. AdTUNE parity.
 */
import { useMemo, useRef, useState } from "react";
import {
  Upload,
  Search,
  LayoutGrid,
  List,
  Trash2,
  Pencil,
  ImageOff,
  Loader2,
  Tag as TagIcon,
  Sparkles,
  X,
} from "lucide-react";
import { StudioLayout } from "@/components/studio/StudioLayout";
import { StudioAgentPanel } from "@/components/studio/StudioAgentPanel";
import { AutoTagModal } from "@/components/studio/agent-modals";
import { assetFileUrl } from "@/components/studio/scene";
import {
  useAssets,
  useUploadAssets,
  usePatchAsset,
  useDeleteAsset,
} from "@/lib/studio-api";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import type { StudioAsset, StudioAssetKind } from "@/components/studio/types";

const UPLOAD_ACCEPT = "image/*,.zip,.svg";

const CHECKER: React.CSSProperties = {
  backgroundImage:
    "linear-gradient(45deg, rgba(0,0,0,0.06) 25%, transparent 25%), linear-gradient(-45deg, rgba(0,0,0,0.06) 25%, transparent 25%), linear-gradient(45deg, transparent 75%, rgba(0,0,0,0.06) 75%), linear-gradient(-45deg, transparent 75%, rgba(0,0,0,0.06) 75%)",
  backgroundSize: "16px 16px",
  backgroundPosition: "0 0, 0 8px, 8px -8px, -8px 0",
};

function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

type Tab = StudioAssetKind;
type View = "grid" | "row";

export default function AssetsPage() {
  const { toast } = useToast();
  const { data: assets = [], isLoading } = useAssets();
  const upload = useUploadAssets();
  const patch = usePatchAsset();
  const del = useDeleteAsset();

  const [tab, setTab] = useState<Tab>("image");
  const [view, setView] = useState<View>("grid");
  const [query, setQuery] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const [editing, setEditing] = useState<StudioAsset | null>(null);
  const [autoTagAsset, setAutoTagAsset] = useState<StudioAsset | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const inTab = useMemo(
    () => assets.filter((a) => a.kind === tab),
    [assets, tab],
  );

  const allTags = useMemo(() => {
    const set = new Set<string>();
    for (const a of inTab) for (const t of a.tags) set.add(t);
    return Array.from(set).sort();
  }, [inTab]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return inTab.filter((a) => {
      if (
        selectedTags.length > 0 &&
        !selectedTags.every((t) => a.tags.includes(t))
      ) {
        return false;
      }
      if (!q) return true;
      return (
        a.originalName.toLowerCase().includes(q) ||
        a.tags.some((t) => t.toLowerCase().includes(q))
      );
    });
  }, [inTab, query, selectedTags]);

  function switchTab(next: Tab) {
    setTab(next);
    setSelectedTags([]);
  }

  function toggleTag(t: string) {
    setSelectedTags((prev) =>
      prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t],
    );
  }

  async function doUpload(files: File[]) {
    if (files.length === 0) return;
    try {
      await upload.mutateAsync({ files, kind: tab });
      toast({
        title: "Upload complete",
        description: `${files.length} file${files.length === 1 ? "" : "s"} processed into ${tab === "image" ? "Images" : "Packshot"}.`,
      });
    } catch (err) {
      toast({
        title: "Upload failed",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
    }
  }

  function onFilesPicked(list: FileList | null) {
    if (!list) return;
    doUpload(Array.from(list));
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragOver(false);
    onFilesPicked(e.dataTransfer.files);
  }

  return (
    <StudioLayout
      active="assets"
      actions={
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={upload.isPending}
          className="inline-flex items-center gap-1.5 bg-[hsl(var(--primary))] px-3 py-1.5 text-[12.5px] text-white hover:brightness-95 disabled:opacity-60"
          data-testid="button-upload-assets"
        >
          {upload.isPending ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <Upload className="h-3.5 w-3.5" />
          )}
          Upload
        </button>
      }
    >
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={UPLOAD_ACCEPT}
        className="hidden"
        data-testid="input-upload-assets"
        onChange={(e) => {
          onFilesPicked(e.target.files);
          e.target.value = "";
        }}
      />

      <div className="space-y-4 p-6">
        {/* Tabs */}
        <div className="flex items-center gap-0.5 border-b border-card-border">
          {(["image", "packshot"] as Tab[]).map((k) => {
            const count = assets.filter((a) => a.kind === k).length;
            const active = tab === k;
            return (
              <button
                key={k}
                type="button"
                onClick={() => switchTab(k)}
                className={cn(
                  "-mb-px border-b-2 px-3.5 py-2 text-[12.5px] transition-colors",
                  active
                    ? "border-[hsl(var(--primary))] font-medium text-foreground"
                    : "border-transparent text-muted-foreground hover:text-foreground",
                )}
                data-testid={`assets-tab-${k}`}
              >
                {k === "image" ? "Images" : "Packshot"} ({count})
              </button>
            );
          })}
        </div>

        {/* Drop zone */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          className={cn(
            "flex flex-col items-center justify-center gap-2 border border-dashed bg-card px-6 py-7 text-center transition-colors",
            dragOver
              ? "border-[hsl(var(--primary))] bg-[hsl(var(--primary))]/5"
              : "border-card-border",
          )}
          data-testid="assets-dropzone"
        >
          <div className="flex h-9 w-9 items-center justify-center bg-muted text-muted-foreground">
            {upload.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Upload className="h-4 w-4" />
            )}
          </div>
          <div className="text-[13px] font-medium text-foreground">
            {upload.isPending
              ? "Uploading…"
              : `Drop images or a .zip into ${tab === "image" ? "Images" : "Packshot"}`}
          </div>
          <div className="text-[11.5px] text-muted-foreground">
            PNG, JPG, WEBP, GIF, SVG — or a .zip the server will unpack.
          </div>
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={upload.isPending}
            className="mt-1 inline-flex items-center gap-1.5 border border-card-border bg-background px-3 py-1.5 text-[12px] text-foreground hover:bg-muted/60 disabled:opacity-60"
            data-testid="button-browse-files"
          >
            <Upload className="h-3.5 w-3.5" /> Browse files
          </button>
        </div>

        {/* Toolbar: search + view toggle */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name or tag…"
              className="w-full border border-card-border bg-background py-1.5 pl-8 pr-3 text-[12.5px] text-foreground placeholder:text-muted-foreground focus:border-[hsl(var(--primary))] focus:outline-none"
              data-testid="input-search-assets"
            />
          </div>
          <div className="flex items-center border border-card-border">
            <button
              type="button"
              onClick={() => setView("grid")}
              className={cn(
                "flex h-8 w-8 items-center justify-center",
                view === "grid"
                  ? "bg-muted text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
              data-testid="button-view-grid"
              aria-label="Grid view"
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => setView("row")}
              className={cn(
                "flex h-8 w-8 items-center justify-center border-l border-card-border",
                view === "row"
                  ? "bg-muted text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
              data-testid="button-view-row"
              aria-label="Row view"
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Tag chips — single horizontally-scrollable row */}
        {allTags.length > 0 && (
          <div
            className="flex flex-nowrap items-center gap-1.5 overflow-x-auto pb-1"
            data-testid="tag-filter"
          >
            <TagIcon className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            {allTags.map((t) => {
              const active = selectedTags.includes(t);
              return (
                <button
                  key={t}
                  type="button"
                  onClick={() => toggleTag(t)}
                  className={cn(
                    "shrink-0 whitespace-nowrap border px-2 py-0.5 text-[11px] transition-colors",
                    active
                      ? "border-[hsl(var(--primary))] bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]"
                      : "border-card-border text-muted-foreground hover:text-foreground",
                  )}
                  data-testid={`tag-chip-${t}`}
                >
                  {t}
                </button>
              );
            })}
            {selectedTags.length > 0 && (
              <button
                type="button"
                onClick={() => setSelectedTags([])}
                className="ml-1 inline-flex shrink-0 items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground"
                data-testid="button-clear-tags"
              >
                <X className="h-3 w-3" /> Clear
              </button>
            )}
          </div>
        )}

        {/* Assets */}
        {isLoading ? (
          <div className="flex items-center gap-2 py-12 text-[12.5px] text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading assets…
          </div>
        ) : filtered.length === 0 ? (
          <div
            className="flex flex-col items-center gap-2 border border-dashed border-card-border bg-card py-14 text-center"
            data-testid="assets-empty"
          >
            <ImageOff className="h-7 w-7 text-muted-foreground" />
            <div className="text-[13px] font-medium text-foreground">
              {inTab.length === 0
                ? `No ${tab === "image" ? "images" : "packshots"} yet`
                : "No assets match your filters"}
            </div>
            <div className="text-[12px] text-muted-foreground">
              {inTab.length === 0
                ? "Upload files above to populate this library."
                : "Try a different search or clear the tag filter."}
            </div>
          </div>
        ) : view === "grid" ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6">
            {filtered.map((a) => (
              <AssetCard
                key={a.id}
                asset={a}
                onEdit={() => setEditing(a)}
                onAutoTag={() => setAutoTagAsset(a)}
                onDelete={() => {
                  if (
                    window.confirm(`Delete "${a.originalName}"? This cannot be undone.`)
                  ) {
                    del.mutate(a.id);
                  }
                }}
              />
            ))}
          </div>
        ) : (
          <div className="divide-y divide-card-border border border-card-border bg-card">
            {filtered.map((a) => (
              <AssetRow
                key={a.id}
                asset={a}
                onEdit={() => setEditing(a)}
                onAutoTag={() => setAutoTagAsset(a)}
                onDelete={() => {
                  if (
                    window.confirm(`Delete "${a.originalName}"? This cannot be undone.`)
                  ) {
                    del.mutate(a.id);
                  }
                }}
              />
            ))}
          </div>
        )}
      </div>

      {editing && (
        <EditTagsModal
          asset={editing}
          saving={patch.isPending}
          onClose={() => setEditing(null)}
          onSave={async (tags) => {
            try {
              await patch.mutateAsync({ id: editing.id, tags });
              toast({ title: "Tags updated" });
              setEditing(null);
            } catch (err) {
              toast({
                title: "Could not update tags",
                description: err instanceof Error ? err.message : "Unknown error",
                variant: "destructive",
              });
            }
          }}
        />
      )}

      {autoTagAsset && (
        <AutoTagModal
          open={!!autoTagAsset}
          onClose={() => setAutoTagAsset(null)}
          asset={autoTagAsset}
        />
      )}

      <StudioAgentPanel scopeLabel="Asset Library" />
    </StudioLayout>
  );
}

/* ------------------------------ asset card ------------------------------ */

function DimBadge({ asset }: { asset: StudioAsset }) {
  return (
    <span className="bg-muted px-1.5 py-0.5 text-[10px] tabular-nums text-muted-foreground">
      {asset.width ?? "?"}×{asset.height ?? "?"}
    </span>
  );
}

function FmtBadge({ asset }: { asset: StudioAsset }) {
  return (
    <span className="border border-card-border px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
      {asset.ext}
    </span>
  );
}

function AssetCard({
  asset,
  onEdit,
  onAutoTag,
  onDelete,
}: {
  asset: StudioAsset;
  onEdit: () => void;
  onAutoTag: () => void;
  onDelete: () => void;
}) {
  return (
    <div
      className="group flex flex-col border border-card-border bg-card"
      data-testid={`asset-card-${asset.id}`}
    >
      <div
        className="relative flex aspect-[4/3] items-center justify-center bg-muted p-3"
        style={CHECKER}
      >
        <img
          src={assetFileUrl(asset.fileName)}
          crossOrigin="anonymous"
          alt={asset.originalName}
          className="max-h-full max-w-full object-contain"
          loading="lazy"
        />
        <div className="absolute right-1.5 top-1.5 flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
          <button
            type="button"
            onClick={onAutoTag}
            className="flex h-7 w-7 items-center justify-center border border-card-border bg-card text-muted-foreground hover:text-[hsl(var(--primary))]"
            data-testid={`button-auto-tag-${asset.id}`}
            aria-label="Auto-tag with AI"
            title="Auto-tag with AI"
          >
            <Sparkles className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onEdit}
            className="flex h-7 w-7 items-center justify-center border border-card-border bg-card text-muted-foreground hover:text-foreground"
            data-testid={`button-edit-tags-${asset.id}`}
            aria-label="Edit tags"
          >
            <Pencil className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="flex h-7 w-7 items-center justify-center border border-card-border bg-card text-muted-foreground hover:text-destructive"
            data-testid={`button-delete-asset-${asset.id}`}
            aria-label="Delete asset"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
      <div className="min-w-0 space-y-1.5 p-2.5">
        <div
          className="truncate text-[12px] font-medium text-foreground"
          title={asset.originalName}
        >
          {asset.originalName}
        </div>
        <div className="flex flex-wrap items-center gap-1">
          <DimBadge asset={asset} />
          <FmtBadge asset={asset} />
          <span className="text-[10.5px] text-muted-foreground">
            {fmtBytes(asset.bytes)}
          </span>
        </div>
        {asset.tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {asset.tags.map((t) => (
              <span
                key={t}
                className="bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground"
              >
                {t}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function AssetRow({
  asset,
  onEdit,
  onAutoTag,
  onDelete,
}: {
  asset: StudioAsset;
  onEdit: () => void;
  onAutoTag: () => void;
  onDelete: () => void;
}) {
  return (
    <div
      className="flex items-center gap-3 px-3 py-2.5"
      data-testid={`asset-row-${asset.id}`}
    >
      <div
        className="flex h-12 w-12 flex-shrink-0 items-center justify-center bg-muted p-1"
        style={CHECKER}
      >
        <img
          src={assetFileUrl(asset.fileName)}
          crossOrigin="anonymous"
          alt={asset.originalName}
          className="max-h-full max-w-full object-contain"
          loading="lazy"
        />
      </div>
      <div className="min-w-0 flex-1">
        <div
          className="truncate text-[12.5px] font-medium text-foreground"
          title={asset.originalName}
        >
          {asset.originalName}
        </div>
        <div className="mt-0.5 flex flex-wrap items-center gap-1">
          <DimBadge asset={asset} />
          <FmtBadge asset={asset} />
          <span className="text-[10.5px] text-muted-foreground">
            {fmtBytes(asset.bytes)}
          </span>
          {asset.tags.map((t) => (
            <span
              key={t}
              className="bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground"
            >
              {t}
            </span>
          ))}
        </div>
      </div>
      <button
        type="button"
        onClick={onAutoTag}
        className="flex h-7 w-7 items-center justify-center text-muted-foreground hover:text-[hsl(var(--primary))]"
        data-testid={`button-auto-tag-${asset.id}`}
        aria-label="Auto-tag with AI"
        title="Auto-tag with AI"
      >
        <Sparkles className="h-3.5 w-3.5" />
      </button>
      <button
        type="button"
        onClick={onEdit}
        className="flex h-7 w-7 items-center justify-center text-muted-foreground hover:text-foreground"
        data-testid={`button-edit-tags-${asset.id}`}
        aria-label="Edit tags"
      >
        <Pencil className="h-3.5 w-3.5" />
      </button>
      <button
        type="button"
        onClick={onDelete}
        className="flex h-7 w-7 items-center justify-center text-muted-foreground hover:text-destructive"
        data-testid={`button-delete-asset-${asset.id}`}
        aria-label="Delete asset"
      >
        <Trash2 className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}

/* ---------------------------- edit tags modal ---------------------------- */

function EditTagsModal({
  asset,
  saving,
  onClose,
  onSave,
}: {
  asset: StudioAsset;
  saving: boolean;
  onClose: () => void;
  onSave: (tags: string[]) => void;
}) {
  const [draft, setDraft] = useState(asset.tags.join(", "));

  function parseTags(): string[] {
    return draft
      .split(",")
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean)
      .slice(0, 24);
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      onClick={onClose}
      data-testid="edit-tags-overlay"
    >
      <div
        className="w-[420px] max-w-[94vw] border border-card-border bg-card"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between border-b border-card-border px-4 py-3">
          <h2 className="text-[13px] font-semibold text-foreground">Edit tags</h2>
          <button
            type="button"
            onClick={onClose}
            className="flex h-7 w-7 items-center justify-center text-muted-foreground hover:text-foreground"
            data-testid="button-edit-tags-close"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="space-y-3 p-4">
          <div
            className="truncate text-[12px] text-muted-foreground"
            title={asset.originalName}
          >
            {asset.originalName}
          </div>
          <div>
            <label className="mb-1 block text-[11.5px] font-medium text-foreground">
              Tags (comma separated)
            </label>
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="e.g. hero, finance, dark"
              className="w-full border border-card-border bg-background px-2.5 py-1.5 text-[12.5px] text-foreground placeholder:text-muted-foreground focus:border-[hsl(var(--primary))] focus:outline-none"
              data-testid="input-edit-tags"
              autoFocus
            />
          </div>
        </div>
        <div className="flex items-center justify-end gap-2 border-t border-card-border px-4 py-3">
          <button
            type="button"
            onClick={onClose}
            className="border border-card-border bg-background px-3 py-1.5 text-[12px] text-foreground hover:bg-muted/60"
            data-testid="button-edit-tags-cancel"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => onSave(parseTags())}
            disabled={saving}
            className="inline-flex items-center gap-1.5 bg-[hsl(var(--primary))] px-3 py-1.5 text-[12px] text-white hover:brightness-95 disabled:opacity-60"
            data-testid="button-edit-tags-save"
          >
            {saving && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
