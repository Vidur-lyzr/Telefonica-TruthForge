/**
 * Creative Studio — full-screen canvas editor for a single template dimension
 * (variant). Renders the shared StudioScene on react-konva (MIT, no watermark)
 * and exposes a layers panel + full property inspector:
 *   - select a layer on the canvas (click) or in the layers panel,
 *   - drag to reposition, or set exact layout (x/y/w/h, rotation),
 *   - opacity, corner radius, typography, alignment, color, fill, stroke, blur,
 *   - bind text/image layers to schema fields and use %merge_tokens%,
 *   - live "preview with creative data" from a feed row,
 *   - export the rendered dimension as a real PNG bitmap.
 * The editor bypasses the StudioLayout chrome and renders edge-to-edge, like the
 * existing GTM canvas.
 */
import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Link, useParams } from "wouter";
import type Konva from "konva";
import {
  ArrowLeft,
  Save,
  Download,
  Plus,
  Trash2,
  Copy,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  ChevronUp,
  ChevronDown,
  Type as TypeIcon,
  Image as ImageIcon,
  Square,
  Droplets,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Loader2,
  Check,
  Maximize2,
  Minus,
  ZoomIn,
  Play,
  Pause,
  Film,
  RotateCcw,
  X,
} from "lucide-react";
import StudioKonva from "@/components/studio/StudioKonva";
import {
  STUDIO_BRAND,
  STUDIO_DEFAULT_DURATION_MS,
  STUDIO_DEFAULT_FPS,
  STUDIO_FONT_FAMILY,
  assetFileUrl,
  makeImageLayer,
  makeRectLayer,
  makeTextLayer,
  mergeValues,
  cloneLayer,
} from "@/components/studio/scene";
import type {
  StudioAnimationClip,
  StudioAsset,
  StudioClipType,
  StudioEasing,
  StudioImageLayer,
  StudioLayer,
  StudioRectLayer,
  StudioScene,
  StudioTextLayer,
} from "@/components/studio/types";
import {
  MAX_CROP_SCALE,
  MIN_CROP_SCALE,
  zoomCrop,
} from "@/components/studio/cropMath";
import {
  useAssets,
  useFeeds,
  useTemplate,
  useUpdateVariantScene,
} from "@/lib/studio-api";

type AnyLayerPatch = Partial<StudioTextLayer> &
  Partial<StudioImageLayer> &
  Partial<StudioRectLayer>;

const FONT_OPTIONS: { label: string; value: string }[] = [
  { label: "Amazon Ember", value: STUDIO_FONT_FAMILY },
  { label: "Inter", value: "Inter, system-ui, sans-serif" },
  { label: "Georgia (serif)", value: "Georgia, 'Times New Roman', serif" },
  { label: "Mono", value: "'Courier New', ui-monospace, monospace" },
];

function move<T>(arr: T[], from: number, to: number): T[] {
  if (to < 0 || to >= arr.length) return arr;
  const next = arr.slice();
  const [it] = next.splice(from, 1);
  next.splice(to, 0, it);
  return next;
}

function layerIcon(t: StudioLayer["type"]) {
  if (t === "text") return <TypeIcon className="w-3.5 h-3.5" />;
  if (t === "image") return <ImageIcon className="w-3.5 h-3.5" />;
  return <Square className="w-3.5 h-3.5" />;
}

const CLIP_PRESETS: { type: StudioClipType; label: string }[] = [
  { type: "fadeIn", label: "Fade in" },
  { type: "slideIn", label: "Slide in" },
  { type: "popIn", label: "Pop in" },
  { type: "pulse", label: "Pulse" },
  { type: "fadeOut", label: "Fade out" },
  { type: "slideOut", label: "Slide out" },
];

function clipLabel(type: StudioClipType): string {
  return CLIP_PRESETS.find((c) => c.type === type)?.label ?? type;
}

/** Build a sensible default clip for a given preset within a scene duration. */
function makeClip(
  type: StudioClipType,
  durationMs: number,
): StudioAnimationClip {
  switch (type) {
    case "fadeIn":
      return { type, startMs: 0, durationMs: 600, easing: "easeOut" };
    case "slideIn":
      return {
        type,
        startMs: 0,
        durationMs: 600,
        direction: "up",
        easing: "easeOut",
      };
    case "popIn":
      return { type, startMs: 0, durationMs: 500, easing: "easeOut", from: 0.6 };
    case "pulse":
      return { type, startMs: 600, durationMs: 1200, to: 1.08 };
    case "fadeOut":
      return {
        type,
        startMs: Math.max(0, durationMs - 600),
        durationMs: 600,
        easing: "easeIn",
      };
    case "slideOut":
      return {
        type,
        startMs: Math.max(0, durationMs - 600),
        durationMs: 600,
        direction: "down",
        easing: "easeIn",
      };
  }
}

function fmtMs(ms: number): string {
  return `${(ms / 1000).toFixed(1)}s`;
}

/* --------------------------- tiny form controls --------------------------- */

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="block text-[10.5px] uppercase tracking-wide text-muted-foreground mb-1">
        {label}
      </span>
      {children}
    </label>
  );
}

function NumberInput({
  value,
  onChange,
  min,
  max,
  step = 1,
  testId,
}: {
  value: number;
  onChange: (n: number) => void;
  min?: number;
  max?: number;
  step?: number;
  testId?: string;
}) {
  return (
    <input
      type="number"
      value={Number.isFinite(value) ? value : 0}
      min={min}
      max={max}
      step={step}
      onChange={(e) => {
        const n = parseFloat(e.target.value);
        if (!Number.isNaN(n)) onChange(n);
      }}
      className="w-full px-2 py-1.5 text-[12.5px] bg-background border border-card-border text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
      data-testid={testId}
    />
  );
}

function TextInput({
  value,
  onChange,
  placeholder,
  testId,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  testId?: string;
}) {
  return (
    <input
      type="text"
      value={value}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
      className="w-full px-2 py-1.5 text-[12.5px] bg-background border border-card-border text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
      data-testid={testId}
    />
  );
}

function SelectInput({
  value,
  onChange,
  options,
  testId,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { label: string; value: string }[];
  testId?: string;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full px-2 py-1.5 text-[12.5px] bg-background border border-card-border text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
      data-testid={testId}
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

function ColorInput({
  value,
  onChange,
  testId,
}: {
  value: string;
  onChange: (v: string) => void;
  testId?: string;
}) {
  const hex = value && value.startsWith("#") ? value : "#000000";
  return (
    <div className="flex items-center gap-1.5">
      <input
        type="color"
        value={hex}
        onChange={(e) => onChange(e.target.value)}
        className="w-8 h-8 p-0 border border-card-border bg-background cursor-pointer"
        data-testid={testId}
      />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="flex-1 px-2 py-1.5 text-[12px] bg-background border border-card-border text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
      />
    </div>
  );
}

function IconToggleGroup<T extends string>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; icon: React.ReactNode; title: string }[];
}) {
  return (
    <div className="inline-flex border border-card-border">
      {options.map((o, i) => (
        <button
          key={o.value}
          type="button"
          title={o.title}
          onClick={() => onChange(o.value)}
          className={`px-2.5 py-1.5 ${i > 0 ? "border-l border-card-border" : ""} ${
            value === o.value
              ? "bg-[hsl(var(--primary))] text-white"
              : "bg-background text-muted-foreground hover:text-foreground"
          }`}
          data-testid={`align-${o.value}`}
        >
          {o.icon}
        </button>
      ))}
    </div>
  );
}

/* --------------------------------- editor -------------------------------- */

export default function StudioEditorPage() {
  const params = useParams();
  const templateId = params.templateId as string;
  const variantId = params.variantId as string;

  const { data: template, isLoading } = useTemplate(templateId);
  const { data: assets = [] } = useAssets();
  const { data: feeds = [] } = useFeeds(templateId);
  const updateScene = useUpdateVariantScene(templateId);

  const variant = useMemo(
    () => template?.variants.find((v) => v.id === variantId),
    [template, variantId],
  );

  const [scene, setScene] = useState<StudioScene | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [dirty, setDirty] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [feedId, setFeedId] = useState<string>("");
  const [rowId, setRowId] = useState<string>("");
  const [zoom, setZoom] = useState(1);
  const [fittedOnce, setFittedOnce] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);

  // Animation playback (dynamic variants only).
  const [playing, setPlaying] = useState(false);
  const [playheadMs, setPlayheadMs] = useState(0);
  const [scrubbing, setScrubbing] = useState(false);
  const playBaseRef = useRef(0);

  const stageRef = useRef<Konva.Stage>(null);
  const canvasWrapRef = useRef<HTMLDivElement>(null);

  // Initialise the editable scene once per variant.
  const loadedVariantRef = useRef<string | null>(null);
  useEffect(() => {
    if (variant && loadedVariantRef.current !== variant.id) {
      setScene(structuredClone(variant.scene));
      setSelectedId(null);
      setDirty(false);
      loadedVariantRef.current = variant.id;
    }
  }, [variant]);

  const assetsById = useMemo(
    () => Object.fromEntries(assets.map((a) => [a.id, a])),
    [assets],
  );

  const schemaDefaults = useMemo(() => {
    const m: Record<string, string> = {};
    for (const f of template?.schemaFields ?? []) {
      if (f.defaultValue) m[f.id] = f.defaultValue;
    }
    return m;
  }, [template]);

  const activeFeed = feeds.find((f) => f.id === feedId);
  const activeRow = activeFeed?.rows.find((r) => r.id === rowId);

  const values = useMemo(() => {
    if (previewMode && activeRow)
      return mergeValues(schemaDefaults, activeRow.values);
    return schemaDefaults;
  }, [previewMode, activeRow, schemaDefaults]);

  const previewCrops = previewMode && activeRow ? activeRow.crops : undefined;

  // --- animation timeline derivations -------------------------------------
  const isDynamic = variant?.type === "dynamic";
  const timeline = scene?.timeline;
  const durationMs = timeline?.durationMs ?? STUDIO_DEFAULT_DURATION_MS;
  const captureMs = timeline?.captureMs ?? 0;
  // Animation frames are applied only while playing or actively scrubbing; at
  // rest the canvas stays editable and renders the layers' resting state.
  const showFrame = !!isDynamic && !!timeline && (playing || scrubbing);
  const frameMs = showFrame ? playheadMs : undefined;

  // Reset playback when switching variants.
  useEffect(() => {
    setPlaying(false);
    setPlayheadMs(0);
    setScrubbing(false);
  }, [variantId]);

  // rAF loop drives the playhead while playing (loops at durationMs).
  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    playBaseRef.current = performance.now() - playheadMs;
    const tick = (now: number) => {
      const t = (now - playBaseRef.current) % durationMs;
      setPlayheadMs(t);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // playheadMs intentionally excluded: it is the loop's output, not input.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, durationMs]);

  const enableTimeline = useCallback(() => {
    setScene((s) =>
      s && !s.timeline
        ? {
            ...s,
            timeline: {
              durationMs: STUDIO_DEFAULT_DURATION_MS,
              fps: STUDIO_DEFAULT_FPS,
              captureMs: 0,
            },
          }
        : s,
    );
    setDirty(true);
  }, []);

  const patchTimeline = useCallback(
    (patch: Partial<NonNullable<StudioScene["timeline"]>>) => {
      setScene((s) =>
        s && s.timeline ? { ...s, timeline: { ...s.timeline, ...patch } } : s,
      );
      setDirty(true);
    },
    [],
  );

  // Auto-fit zoom to the canvas viewport on first measure / variant change.
  const computeFit = useCallback(() => {
    const el = canvasWrapRef.current;
    if (!el || !variant) return 1;
    const pad = 64;
    const cw = el.clientWidth - pad;
    const ch = el.clientHeight - pad;
    if (cw <= 0 || ch <= 0) return 1;
    return Math.min(cw / variant.width, ch / variant.height, 1.5);
  }, [variant]);

  useLayoutEffect(() => {
    setFittedOnce(false);
  }, [variantId]);

  useEffect(() => {
    if (!fittedOnce && variant && canvasWrapRef.current) {
      const f = computeFit();
      if (f > 0) {
        setZoom(f);
        setFittedOnce(true);
      }
    }
  }, [fittedOnce, variant, computeFit, scene]);

  const selected = scene?.layers.find((l) => l.id === selectedId) ?? null;

  // Template per-section crop is always-on for the selected COVER image (incl.
  // the blurred background). Logos (contain) are excluded — they are framed by
  // box, not cropped. Suppressed while the animation playhead is scrubbing.
  const cropLayerId =
    !showFrame &&
    selected?.type === "image" &&
    (selected.imageKind === "blur" || (selected.fit ?? "cover") === "cover")
      ? selected.id
      : null;

  const patchScene = useCallback((next: StudioScene) => {
    setScene(next);
    setDirty(true);
  }, []);

  const updateLayer = useCallback(
    (id: string, patch: AnyLayerPatch) => {
      setScene((s) =>
        s
          ? {
              ...s,
              layers: s.layers.map((l) =>
                l.id === id ? ({ ...l, ...patch } as StudioLayer) : l,
              ),
            }
          : s,
      );
      setDirty(true);
    },
    [],
  );

  const updateSelected = useCallback(
    (patch: AnyLayerPatch) => {
      if (selectedId) updateLayer(selectedId, patch);
    },
    [selectedId, updateLayer],
  );

  const addLayer = (kind: "text" | "image" | "logo" | "rect" | "blur") => {
    if (!scene || !variant) return;
    let ly: StudioLayer;
    const cx = Math.round(variant.width / 2 - 80);
    const cy = Math.round(variant.height / 2 - 24);
    if (kind === "text") {
      ly = makeTextLayer({ x: cx, y: cy, w: 200, h: 56, color: STUDIO_BRAND.ink });
    } else if (kind === "rect") {
      ly = makeRectLayer({ x: cx, y: cy, w: 160, h: 56 });
    } else if (kind === "logo") {
      ly = makeImageLayer({
        name: "Logo",
        imageKind: "logo",
        fit: "contain",
        x: 16,
        y: 16,
        w: 120,
        h: 48,
      });
    } else if (kind === "blur") {
      ly = makeImageLayer({
        name: "BG Blur",
        imageKind: "blur",
        x: 0,
        y: 0,
        w: variant.width,
        h: variant.height,
        blur: 18,
      });
    } else {
      ly = makeImageLayer({
        name: "Image",
        imageKind: "image",
        x: cx,
        y: cy,
        w: 200,
        h: 160,
      });
    }
    patchScene({ ...scene, layers: [...scene.layers, ly] });
    setSelectedId(ly.id);
  };

  const duplicateSelected = () => {
    if (!scene || !selected) return;
    const copy = cloneLayer(selected);
    copy.x += 16;
    copy.y += 16;
    patchScene({ ...scene, layers: [...scene.layers, copy] });
    setSelectedId(copy.id);
  };

  const deleteSelected = () => {
    if (!scene || !selectedId) return;
    patchScene({
      ...scene,
      layers: scene.layers.filter((l) => l.id !== selectedId),
    });
    setSelectedId(null);
  };

  const moveLayer = (id: string, dir: 1 | -1) => {
    if (!scene) return;
    const idx = scene.layers.findIndex((l) => l.id === id);
    if (idx < 0) return;
    patchScene({ ...scene, layers: move(scene.layers, idx, idx + dir) });
  };

  const onSave = async () => {
    if (!scene) return;
    await updateScene.mutateAsync({ variantId, scene });
    setDirty(false);
  };

  const onExport = () => {
    const stage = stageRef.current;
    if (!stage || !variant) return;
    const onScreen = stage.width() / variant.width; // current scale factor
    const url = stage.toDataURL({
      pixelRatio: onScreen > 0 ? 1 / onScreen : 1,
      mimeType: "image/png",
    });
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(variant.name || "creative").replace(/\s+/g, "-").toLowerCase()}-${variant.width}x${variant.height}.png`;
    a.click();
  };

  if (isLoading || !template) {
    return (
      <div className="flex-1 min-h-0 flex items-center justify-center bg-muted/30 text-muted-foreground text-sm gap-2">
        <Loader2 className="w-4 h-4 animate-spin" /> Loading editor…
      </div>
    );
  }
  if (!variant || !scene) {
    return (
      <div className="flex-1 min-h-0 flex flex-col items-center justify-center bg-muted/30 text-muted-foreground text-sm gap-3">
        <p>Dimension not found in this template.</p>
        <Link
          href={`/studio/templates/${templateId}`}
          className="text-[hsl(var(--primary))] hover:underline"
          data-testid="link-back-missing"
        >
          Back to template
        </Link>
      </div>
    );
  }

  const mediaFields = template.schemaFields.filter((f) => f.type === "media");
  const textFields = template.schemaFields.filter((f) => f.type === "rich_text");

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-background text-foreground overflow-hidden">
      {/* Top bar */}
      <header className="flex-shrink-0 h-12 px-3 flex items-center gap-3 bg-card border-b border-card-border">
        <Link
          href={`/studio/templates/${templateId}`}
          className="inline-flex items-center gap-1.5 text-[12.5px] text-muted-foreground hover:text-foreground"
          data-testid="link-back-template"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </Link>
        <div className="h-5 w-px bg-muted" />
        <div className="min-w-0">
          <div className="text-[13px] font-medium leading-none truncate">
            {variant.name}
          </div>
          <div className="text-[11px] text-muted-foreground mt-0.5">
            {template.name} · {variant.width}×{variant.height} ·{" "}
            <span className="uppercase">{variant.type}</span>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-2">
          {/* Preview-with-data controls */}
          <button
            type="button"
            onClick={() => setPreviewMode((p) => !p)}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[12px] border ${
              previewMode
                ? "bg-[hsl(var(--primary))] border-[hsl(var(--primary))] text-white"
                : "border-card-border text-muted-foreground hover:text-foreground"
            }`}
            data-testid="toggle-preview-data"
          >
            <Eye className="w-3.5 h-3.5" /> Preview data
          </button>
          {previewMode && (
            <>
              <select
                value={feedId}
                onChange={(e) => {
                  setFeedId(e.target.value);
                  setRowId("");
                }}
                className="px-2 py-1.5 text-[12px] bg-background border border-card-border text-foreground focus:outline-none"
                data-testid="select-preview-feed"
              >
                <option value="">Select feed…</option>
                {feeds.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
              <select
                value={rowId}
                onChange={(e) => setRowId(e.target.value)}
                disabled={!activeFeed}
                className="px-2 py-1.5 text-[12px] bg-background border border-card-border text-foreground focus:outline-none disabled:opacity-40"
                data-testid="select-preview-row"
              >
                <option value="">Select creative…</option>
                {activeFeed?.rows.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.uid || r.id}
                    {r.locale ? ` · ${r.locale}` : ""}
                  </option>
                ))}
              </select>
            </>
          )}

          <div className="h-5 w-px bg-muted" />

          {/* Zoom */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.1, z - 0.1))}
              className="w-7 h-7 flex items-center justify-center border border-card-border text-muted-foreground hover:text-foreground"
              title="Zoom out"
              data-testid="zoom-out"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] tabular-nums text-muted-foreground w-9 text-center">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(4, z + 0.1))}
              className="w-7 h-7 flex items-center justify-center border border-card-border text-muted-foreground hover:text-foreground"
              title="Zoom in"
              data-testid="zoom-in"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setZoom(computeFit())}
              className="w-7 h-7 flex items-center justify-center border border-card-border text-muted-foreground hover:text-foreground"
              title="Fit to screen"
              data-testid="zoom-fit"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-5 w-px bg-muted" />

          <button
            type="button"
            onClick={onExport}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[12px] border border-card-border text-foreground hover:text-foreground"
            data-testid="button-export-png"
          >
            <Download className="w-3.5 h-3.5" /> PNG
          </button>
          <button
            type="button"
            onClick={onSave}
            disabled={updateScene.isPending || !dirty}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12px] bg-[hsl(var(--primary))] text-white disabled:opacity-50"
            data-testid="button-save-scene"
          >
            {updateScene.isPending ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : dirty ? (
              <Save className="w-3.5 h-3.5" />
            ) : (
              <Check className="w-3.5 h-3.5" />
            )}
            {dirty ? "Save" : "Saved"}
          </button>
        </div>
      </header>

      <div className="flex-1 min-h-0 flex">
        {/* Layers panel */}
        <aside className="w-60 flex-shrink-0 bg-card border-r border-card-border flex flex-col">
          <div className="px-3 py-2.5 border-b border-card-border flex items-center justify-between">
            <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
              Layers
            </span>
            <div className="relative group">
              <button
                type="button"
                className="inline-flex items-center gap-1 px-2 py-1 text-[11.5px] bg-muted hover:bg-muted/70"
                data-testid="button-add-layer"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
              <div className="absolute right-0 top-full mt-1 z-20 hidden group-hover:block bg-card border border-card-border min-w-[140px] py-1 shadow-lg">
                {[
                  { k: "text" as const, l: "Text" },
                  { k: "image" as const, l: "Image" },
                  { k: "logo" as const, l: "Logo" },
                  { k: "rect" as const, l: "Rectangle" },
                  { k: "blur" as const, l: "BG Blur" },
                ].map((o) => (
                  <button
                    key={o.k}
                    type="button"
                    onClick={() => addLayer(o.k)}
                    className="w-full text-left px-3 py-1.5 text-[12px] text-foreground hover:bg-muted/60"
                    data-testid={`add-layer-${o.k}`}
                  >
                    {o.l}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="flex-1 overflow-auto py-1">
            {[...scene.layers].reverse().map((ly) => {
              const isSel = ly.id === selectedId;
              return (
                <div
                  key={ly.id}
                  onClick={() => setSelectedId(ly.id)}
                  className={`group flex items-center gap-2 px-3 py-1.5 cursor-pointer text-[12px] ${
                    isSel ? "bg-[hsl(var(--primary))]/20" : "hover:bg-muted/50"
                  }`}
                  data-testid={`layer-row-${ly.id}`}
                >
                  <span className="text-muted-foreground">{layerIcon(ly.type)}</span>
                  <span className="flex-1 truncate text-foreground">
                    {ly.name}
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      updateLayer(ly.id, { visible: ly.visible === false });
                    }}
                    className="text-muted-foreground hover:text-foreground"
                    title="Toggle visibility"
                    data-testid={`layer-vis-${ly.id}`}
                  >
                    {ly.visible === false ? (
                      <EyeOff className="w-3.5 h-3.5" />
                    ) : (
                      <Eye className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      updateLayer(ly.id, { locked: !ly.locked });
                    }}
                    className="text-muted-foreground hover:text-foreground"
                    title="Lock"
                    data-testid={`layer-lock-${ly.id}`}
                  >
                    {ly.locked ? (
                      <Lock className="w-3.5 h-3.5" />
                    ) : (
                      <Unlock className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              );
            })}
            {scene.layers.length === 0 && (
              <p className="px-3 py-4 text-[12px] text-muted-foreground">
                No layers yet — add one.
              </p>
            )}
          </div>
          {selected && (
            <div className="px-3 py-2 border-t border-card-border flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => moveLayer(selected.id, 1)}
                className="flex-1 inline-flex items-center justify-center gap-1 py-1.5 text-[11.5px] bg-muted hover:bg-muted/60"
                title="Bring forward"
                data-testid="layer-forward"
              >
                <ChevronUp className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => moveLayer(selected.id, -1)}
                className="flex-1 inline-flex items-center justify-center gap-1 py-1.5 text-[11.5px] bg-muted hover:bg-muted/60"
                title="Send backward"
                data-testid="layer-backward"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={duplicateSelected}
                className="flex-1 inline-flex items-center justify-center gap-1 py-1.5 text-[11.5px] bg-muted hover:bg-muted/60"
                title="Duplicate"
                data-testid="layer-duplicate"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={deleteSelected}
                className="flex-1 inline-flex items-center justify-center gap-1 py-1.5 text-[11.5px] bg-red-500/15 text-red-300 hover:bg-red-500/25"
                title="Delete"
                data-testid="layer-delete"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </aside>

        {/* Canvas + timeline column */}
        <div className="flex-1 min-w-0 flex flex-col">
          <main
            ref={canvasWrapRef}
            className="flex-1 min-h-0 overflow-auto flex items-center justify-center bg-muted/40 bg-[radial-gradient(circle,rgba(0,0,0,0.06)_1px,transparent_1px)] [background-size:18px_18px] p-8"
          >
            <div
              className="shadow-2xl"
              style={{
                width: variant.width * zoom,
                height: variant.height * zoom,
              }}
            >
              <StudioKonva
                ref={stageRef}
                scene={scene}
                width={variant.width}
                height={variant.height}
                scale={zoom}
                values={values}
                assetsById={assetsById}
                crops={previewCrops}
                interactive={!showFrame}
                frameMs={frameMs}
                selectedLayerId={selectedId}
                onSelectLayer={setSelectedId}
                onLayerChange={(id, patch) => updateLayer(id, patch)}
                cropLayerId={cropLayerId}
                onLayerCropDraft={(id, crop) => updateLayer(id, { crop })}
              />
            </div>
          </main>

          {isDynamic && (
            <TimelineBar
              hasTimeline={!!timeline}
              playing={playing}
              playheadMs={playheadMs}
              durationMs={durationMs}
              fps={timeline?.fps ?? STUDIO_DEFAULT_FPS}
              captureMs={captureMs}
              onEnable={enableTimeline}
              onPlayToggle={() => setPlaying((p) => !p)}
              onScrubStart={() => {
                setPlaying(false);
                setScrubbing(true);
              }}
              onScrub={setPlayheadMs}
              onScrubEnd={() => setScrubbing(false)}
              onReset={() => {
                setPlaying(false);
                setPlayheadMs(0);
              }}
              onSetCapture={() => patchTimeline({ captureMs: Math.round(playheadMs) })}
              onChangeDuration={(ms) => patchTimeline({ durationMs: ms })}
              onChangeFps={(fps) => patchTimeline({ fps })}
            />
          )}
        </div>

        {/* Inspector */}
        <aside className="w-72 flex-shrink-0 bg-card border-l border-card-border overflow-auto">
          {!selected ? (
            <div className="p-4 text-[12px] text-muted-foreground">
              Select a layer to edit its properties, or add a new layer.
            </div>
          ) : (
            <div className="text-foreground">
              <div className="px-3 py-2.5 border-b border-card-border flex items-center gap-2">
                <span className="text-muted-foreground">{layerIcon(selected.type)}</span>
                <input
                  value={selected.name}
                  onChange={(e) => updateSelected({ name: e.target.value })}
                  className="flex-1 bg-transparent text-[13px] font-medium focus:outline-none"
                  data-testid="input-layer-name"
                />
              </div>

              <div className="p-3 space-y-4">
                {/* Layout */}
                <section className="space-y-2.5">
                  <h3 className="text-[10.5px] uppercase tracking-wide text-muted-foreground">
                    Layout
                  </h3>
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="X">
                      <NumberInput
                        value={selected.x}
                        onChange={(n) => updateSelected({ x: Math.round(n) })}
                        testId="prop-x"
                      />
                    </Field>
                    <Field label="Y">
                      <NumberInput
                        value={selected.y}
                        onChange={(n) => updateSelected({ y: Math.round(n) })}
                        testId="prop-y"
                      />
                    </Field>
                    <Field label="Width">
                      <NumberInput
                        value={selected.w}
                        min={1}
                        onChange={(n) =>
                          updateSelected({ w: Math.max(1, Math.round(n)) })
                        }
                        testId="prop-w"
                      />
                    </Field>
                    <Field label="Height">
                      <NumberInput
                        value={selected.h}
                        min={1}
                        onChange={(n) =>
                          updateSelected({ h: Math.max(1, Math.round(n)) })
                        }
                        testId="prop-h"
                      />
                    </Field>
                    <Field label="Rotation">
                      <NumberInput
                        value={selected.rotation ?? 0}
                        onChange={(n) => updateSelected({ rotation: n })}
                        testId="prop-rotation"
                      />
                    </Field>
                    <Field label={`Opacity ${Math.round((selected.opacity ?? 1) * 100)}%`}>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={Math.round((selected.opacity ?? 1) * 100)}
                        onChange={(e) =>
                          updateSelected({
                            opacity: parseInt(e.target.value, 10) / 100,
                          })
                        }
                        className="w-full accent-[hsl(var(--primary))]"
                        data-testid="prop-opacity"
                      />
                    </Field>
                  </div>
                </section>

                {/* Text props */}
                {selected.type === "text" && (
                  <TextProps
                    layer={selected}
                    textFields={textFields}
                    onChange={updateSelected}
                  />
                )}

                {/* Image props */}
                {selected.type === "image" && (
                  <ImageProps
                    layer={selected}
                    mediaFields={mediaFields}
                    assets={assets}
                    assetsById={assetsById}
                    onChange={updateSelected}
                    onOpenPicker={() => setPickerOpen(true)}
                  />
                )}

                {/* Rect props */}
                {selected.type === "rect" && (
                  <RectProps layer={selected} onChange={updateSelected} />
                )}

                {/* Animation (dynamic variants only) */}
                {isDynamic && (
                  <AnimationProps
                    layer={selected}
                    durationMs={durationMs}
                    onChange={updateSelected}
                  />
                )}
              </div>
            </div>
          )}
        </aside>
      </div>

      {/* Asset picker modal */}
      {pickerOpen && selected?.type === "image" && (
        <AssetPicker
          assets={assets}
          onClose={() => setPickerOpen(false)}
          onPick={(id) => {
            updateSelected({ assetId: id });
            setPickerOpen(false);
          }}
        />
      )}
    </div>
  );
}

/* ----------------------------- text inspector ----------------------------- */

function TextProps({
  layer,
  textFields,
  onChange,
}: {
  layer: StudioTextLayer;
  textFields: { id: string; label: string }[];
  onChange: (p: AnyLayerPatch) => void;
}) {
  return (
    <>
      <section className="space-y-2.5">
        <h3 className="text-[10.5px] uppercase tracking-wide text-muted-foreground">
          Content
        </h3>
        <Field label="Text">
          <textarea
            value={layer.text}
            onChange={(e) => onChange({ text: e.target.value })}
            rows={2}
            className="w-full px-2 py-1.5 text-[12.5px] bg-background border border-card-border text-foreground focus:outline-none focus:border-[hsl(var(--primary))] resize-y"
            data-testid="prop-text"
          />
        </Field>
        <Field label="Bind to field">
          <SelectInput
            value={layer.fieldId ?? ""}
            onChange={(v) => onChange({ fieldId: v || undefined })}
            options={[
              { label: "— none (static) —", value: "" },
              ...textFields.map((f) => ({ label: f.label, value: f.id })),
            ]}
            testId="prop-text-field"
          />
        </Field>
        {textFields.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {textFields.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => onChange({ text: `${layer.text}%${f.id}%` })}
                className="px-1.5 py-0.5 text-[10.5px] bg-muted hover:bg-muted/70 text-muted-foreground"
                title={`Insert %${f.id}% token`}
                data-testid={`token-${f.id}`}
              >
                %{f.id}%
              </button>
            ))}
          </div>
        )}
      </section>

      <section className="space-y-2.5">
        <h3 className="text-[10.5px] uppercase tracking-wide text-muted-foreground">
          Typography
        </h3>
        <Field label="Font">
          <SelectInput
            value={layer.fontFamily ?? STUDIO_FONT_FAMILY}
            onChange={(v) => onChange({ fontFamily: v })}
            options={FONT_OPTIONS}
            testId="prop-font"
          />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Weight">
            <SelectInput
              value={String(layer.fontWeight ?? 400)}
              onChange={(v) => onChange({ fontWeight: parseInt(v, 10) })}
              options={[
                { label: "Regular", value: "400" },
                { label: "Medium", value: "500" },
                { label: "Semibold", value: "600" },
                { label: "Bold", value: "700" },
              ]}
              testId="prop-weight"
            />
          </Field>
          <Field label="Size">
            <NumberInput
              value={layer.fontSize ?? 24}
              min={4}
              onChange={(n) => onChange({ fontSize: Math.max(4, n) })}
              testId="prop-fontsize"
            />
          </Field>
          <Field label="Line height">
            <NumberInput
              value={layer.lineHeight ?? 1.15}
              step={0.05}
              onChange={(n) => onChange({ lineHeight: n })}
              testId="prop-lineheight"
            />
          </Field>
          <Field label="Letter sp.">
            <NumberInput
              value={layer.letterSpacing ?? 0}
              step={0.5}
              onChange={(n) => onChange({ letterSpacing: n })}
              testId="prop-letterspacing"
            />
          </Field>
        </div>
        <div className="flex items-center justify-between">
          <Field label="Align">
            <IconToggleGroup
              value={layer.align ?? "left"}
              onChange={(v) => onChange({ align: v })}
              options={[
                { value: "left", icon: <AlignLeft className="w-3.5 h-3.5" />, title: "Left" },
                { value: "center", icon: <AlignCenter className="w-3.5 h-3.5" />, title: "Center" },
                { value: "right", icon: <AlignRight className="w-3.5 h-3.5" />, title: "Right" },
              ]}
            />
          </Field>
          <Field label="V-Align">
            <SelectInput
              value={layer.valign ?? "top"}
              onChange={(v) =>
                onChange({ valign: v as StudioTextLayer["valign"] })
              }
              options={[
                { label: "Top", value: "top" },
                { label: "Middle", value: "middle" },
                { label: "Bottom", value: "bottom" },
              ]}
              testId="prop-valign"
            />
          </Field>
        </div>
        <Field label="Color">
          <ColorInput
            value={layer.color ?? "#FFFFFF"}
            onChange={(v) => onChange({ color: v })}
            testId="prop-color"
          />
        </Field>
        <label className="flex items-center gap-2 text-[12px] text-foreground">
          <input
            type="checkbox"
            checked={!!layer.upper}
            onChange={(e) => onChange({ upper: e.target.checked })}
            data-testid="prop-upper"
          />
          Uppercase
        </label>
      </section>
    </>
  );
}

/* ---------------------------- image inspector ----------------------------- */

function ImageProps({
  layer,
  mediaFields,
  assets,
  assetsById,
  onChange,
  onOpenPicker,
}: {
  layer: StudioImageLayer;
  mediaFields: { id: string; label: string }[];
  assets: StudioAsset[];
  assetsById: Record<string, StudioAsset>;
  onChange: (p: AnyLayerPatch) => void;
  onOpenPicker: () => void;
}) {
  const current = layer.assetId ? assetsById[layer.assetId] : undefined;
  // Cover-fit images (incl. the blurred background) crop; logos (contain) don't.
  const isCropFit =
    layer.imageKind === "blur" || (layer.fit ?? "cover") === "cover";
  return (
    <>
      <section className="space-y-2.5">
        <h3 className="text-[10.5px] uppercase tracking-wide text-muted-foreground">
          Source
        </h3>
        <Field label="Role">
          <SelectInput
            value={layer.imageKind}
            onChange={(v) =>
              onChange({ imageKind: v as StudioImageLayer["imageKind"] })
            }
            options={[
              { label: "Image", value: "image" },
              { label: "Logo", value: "logo" },
              { label: "BG Blur", value: "blur" },
            ]}
            testId="prop-imagekind"
          />
        </Field>
        <Field label="Bind to field">
          <SelectInput
            value={layer.fieldId ?? ""}
            onChange={(v) => onChange({ fieldId: v || undefined })}
            options={[
              { label: "— none (static) —", value: "" },
              ...mediaFields.map((f) => ({ label: f.label, value: f.id })),
            ]}
            testId="prop-image-field"
          />
        </Field>
        <div>
          <span className="block text-[10.5px] uppercase tracking-wide text-muted-foreground mb-1">
            Default asset
          </span>
          <div className="flex items-center gap-2">
            <div className="w-12 h-12 bg-muted border border-card-border flex items-center justify-center overflow-hidden">
              {current ? (
                <img
                  src={assetFileUrl(current.fileName)}
                  alt=""
                  className="w-full h-full object-contain"
                />
              ) : (
                <ImageIcon className="w-4 h-4 text-muted-foreground" />
              )}
            </div>
            <button
              type="button"
              onClick={onOpenPicker}
              disabled={assets.length === 0}
              className="px-2.5 py-1.5 text-[12px] bg-muted hover:bg-muted/70 disabled:opacity-40"
              data-testid="button-pick-asset"
            >
              {assets.length === 0 ? "No assets" : "Choose…"}
            </button>
            {layer.assetId && (
              <button
                type="button"
                onClick={() => onChange({ assetId: undefined })}
                className="px-2 py-1.5 text-[12px] text-muted-foreground hover:text-foreground"
                data-testid="button-clear-asset"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      </section>

      <section className="space-y-2.5">
        <h3 className="text-[10.5px] uppercase tracking-wide text-muted-foreground">
          Appearance
        </h3>
        {layer.imageKind !== "blur" && (
          <Field label="Fit">
            <SelectInput
              value={layer.fit ?? "cover"}
              onChange={(v) => onChange({ fit: v as StudioImageLayer["fit"] })}
              options={[
                { label: "Cover (crop)", value: "cover" },
                { label: "Contain", value: "contain" },
                { label: "Stretch", value: "stretch" },
              ]}
              testId="prop-fit"
            />
          </Field>
        )}
        <Field label="Corner radius">
          <NumberInput
            value={layer.cornerRadius ?? 0}
            min={0}
            onChange={(n) => onChange({ cornerRadius: Math.max(0, n) })}
            testId="prop-corner"
          />
        </Field>
        {layer.imageKind !== "blur" && (
          <Field label={`Sharpen ${layer.sharpen ?? 0}`}>
            <input
              type="range"
              min={0}
              max={100}
              value={layer.sharpen ?? 0}
              onChange={(e) =>
                onChange({ sharpen: parseInt(e.target.value, 10) })
              }
              className="w-full accent-[hsl(var(--primary))]"
              data-testid="prop-sharpen"
            />
          </Field>
        )}
        {layer.imageKind === "blur" && (
          <Field label={`Blur ${layer.blur ?? 0}px`}>
            <input
              type="range"
              min={0}
              max={60}
              value={layer.blur ?? 0}
              onChange={(e) =>
                onChange({ blur: parseInt(e.target.value, 10) })
              }
              className="w-full accent-[hsl(var(--primary))]"
              data-testid="prop-blur"
            />
          </Field>
        )}
      </section>

      {isCropFit && (
        <section className="space-y-2.5">
          <h3 className="text-[10.5px] uppercase tracking-wide text-muted-foreground">
            Framing
          </h3>
          <p className="text-[11px] leading-snug text-muted-foreground">
            Drag on the canvas to pan, scroll to zoom. Each image section frames
            independently.
          </p>
          <Field label={`Zoom ${(layer.crop?.scale ?? 1).toFixed(2)}×`}>
            <input
              type="range"
              min={MIN_CROP_SCALE}
              max={MAX_CROP_SCALE}
              step={0.01}
              value={layer.crop?.scale ?? 1}
              onChange={(e) =>
                onChange({
                  crop: zoomCrop(layer.crop, parseFloat(e.target.value)),
                })
              }
              className="w-full accent-[hsl(var(--primary))]"
              data-testid="prop-crop-zoom"
            />
          </Field>
          <button
            type="button"
            onClick={() => onChange({ crop: undefined })}
            disabled={!layer.crop}
            className="px-2.5 py-1.5 text-[12px] bg-muted hover:bg-muted/70 disabled:opacity-40"
            data-testid="button-reset-crop"
          >
            Reset framing
          </button>
        </section>
      )}
    </>
  );
}

/* ----------------------------- rect inspector ----------------------------- */

function RectProps({
  layer,
  onChange,
}: {
  layer: StudioRectLayer;
  onChange: (p: AnyLayerPatch) => void;
}) {
  return (
    <section className="space-y-2.5">
      <h3 className="text-[10.5px] uppercase tracking-wide text-muted-foreground flex items-center gap-1.5">
        <Droplets className="w-3.5 h-3.5" /> Fill & stroke
      </h3>
      <Field label="Fill">
        <ColorInput
          value={layer.fill ?? "#000000"}
          onChange={(v) => onChange({ fill: v, gradient: undefined })}
          testId="prop-fill"
        />
      </Field>
      <Field label="Corner radius">
        <NumberInput
          value={layer.cornerRadius ?? 0}
          min={0}
          onChange={(n) => onChange({ cornerRadius: Math.max(0, n) })}
          testId="prop-rect-corner"
        />
      </Field>
      <div className="grid grid-cols-2 gap-2">
        <Field label="Stroke">
          <ColorInput
            value={layer.stroke ?? "#000000"}
            onChange={(v) => onChange({ stroke: v })}
            testId="prop-stroke"
          />
        </Field>
        <Field label="Stroke width">
          <NumberInput
            value={layer.strokeWidth ?? 0}
            min={0}
            onChange={(n) => onChange({ strokeWidth: Math.max(0, n) })}
            testId="prop-stroke-width"
          />
        </Field>
      </div>
    </section>
  );
}

/* ----------------------------- asset picker ------------------------------- */

function AssetPicker({
  assets,
  onPick,
  onClose,
}: {
  assets: StudioAsset[];
  onPick: (id: string) => void;
  onClose: () => void;
}) {
  const [q, setQ] = useState("");
  const filtered = assets.filter(
    (a) =>
      !q ||
      a.originalName.toLowerCase().includes(q.toLowerCase()) ||
      a.tags.some((t) => t.toLowerCase().includes(q.toLowerCase())),
  );
  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-6"
      onClick={onClose}
    >
      <div
        className="bg-card border border-card-border w-full max-w-3xl max-h-[80vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-4 py-3 border-b border-card-border flex items-center gap-3">
          <span className="text-[13px] font-medium text-foreground">
            Choose asset
          </span>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search assets…"
            className="ml-auto px-2 py-1.5 text-[12px] bg-background border border-card-border text-foreground focus:outline-none w-56"
            data-testid="asset-picker-search"
          />
        </div>
        <div className="flex-1 overflow-auto p-4">
          {filtered.length === 0 ? (
            <p className="text-[12px] text-muted-foreground text-center py-10">
              No matching assets.
            </p>
          ) : (
            <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
              {filtered.map((a) => (
                <button
                  key={a.id}
                  type="button"
                  onClick={() => onPick(a.id)}
                  className="group border border-card-border hover:border-[hsl(var(--primary))] bg-muted overflow-hidden text-left"
                  data-testid={`asset-pick-${a.id}`}
                >
                  <div className="aspect-square bg-muted/40 flex items-center justify-center overflow-hidden">
                    <img
                      src={assetFileUrl(a.fileName)}
                      alt={a.originalName}
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="px-1.5 py-1">
                    <div className="text-[10.5px] text-foreground truncate">
                      {a.originalName}
                    </div>
                    <div className="text-[9.5px] text-muted-foreground uppercase">
                      {a.ext}
                      {a.width ? ` · ${a.width}×${a.height}` : ""}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* --------------------------- animation inspector -------------------------- */

function AnimationProps({
  layer,
  durationMs,
  onChange,
}: {
  layer: StudioLayer;
  durationMs: number;
  onChange: (p: AnyLayerPatch) => void;
}) {
  const clips = layer.animation?.clips ?? [];
  const [preset, setPreset] = useState<StudioClipType>("fadeIn");

  const setClips = (next: StudioAnimationClip[]) =>
    onChange({ animation: next.length ? { clips: next } : undefined });

  const addClip = () => setClips([...clips, makeClip(preset, durationMs)]);

  const updateClip = (i: number, patch: Partial<StudioAnimationClip>) =>
    setClips(clips.map((c, idx) => (idx === i ? { ...c, ...patch } : c)));

  const removeClip = (i: number) =>
    setClips(clips.filter((_, idx) => idx !== i));

  return (
    <section className="space-y-2.5">
      <h3 className="text-[10.5px] uppercase tracking-wide text-muted-foreground flex items-center gap-1.5">
        <Film className="w-3.5 h-3.5" /> Animation
      </h3>

      <div className="flex items-center gap-1.5">
        <div className="flex-1">
          <SelectInput
            value={preset}
            onChange={(v) => setPreset(v as StudioClipType)}
            options={CLIP_PRESETS.map((p) => ({
              label: p.label,
              value: p.type,
            }))}
            testId="anim-preset"
          />
        </div>
        <button
          type="button"
          onClick={addClip}
          className="px-2.5 py-1.5 text-[12px] bg-[hsl(var(--primary))] text-white"
          data-testid="anim-add"
        >
          Add
        </button>
      </div>

      {clips.length === 0 ? (
        <p className="text-[11px] text-muted-foreground">No clips on this layer.</p>
      ) : (
        <div className="space-y-2">
          {clips.map((c, i) => {
            const isSlide = c.type === "slideIn" || c.type === "slideOut";
            return (
              <div
                key={i}
                className="border border-card-border p-2 space-y-2"
                data-testid={`anim-clip-${i}`}
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-[11.5px] text-foreground flex-1">
                    {clipLabel(c.type)}
                  </span>
                  <button
                    type="button"
                    onClick={() => removeClip(i)}
                    className="text-muted-foreground hover:text-foreground"
                    data-testid={`anim-remove-${i}`}
                    title="Remove clip"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Start (ms)">
                    <NumberInput
                      value={c.startMs}
                      min={0}
                      step={50}
                      onChange={(n) =>
                        updateClip(i, { startMs: Math.max(0, Math.round(n)) })
                      }
                    />
                  </Field>
                  <Field label="Duration (ms)">
                    <NumberInput
                      value={c.durationMs}
                      min={0}
                      step={50}
                      onChange={(n) =>
                        updateClip(i, {
                          durationMs: Math.max(0, Math.round(n)),
                        })
                      }
                    />
                  </Field>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Easing">
                    <SelectInput
                      value={c.easing ?? "easeOut"}
                      onChange={(v) =>
                        updateClip(i, { easing: v as StudioEasing })
                      }
                      options={[
                        { label: "Linear", value: "linear" },
                        { label: "Ease in", value: "easeIn" },
                        { label: "Ease out", value: "easeOut" },
                        { label: "Ease in-out", value: "easeInOut" },
                      ]}
                    />
                  </Field>
                  {isSlide && (
                    <Field label="Direction">
                      <SelectInput
                        value={c.direction ?? "up"}
                        onChange={(v) =>
                          updateClip(i, {
                            direction:
                              v as NonNullable<
                                StudioAnimationClip["direction"]
                              >,
                          })
                        }
                        options={[
                          { label: "Up", value: "up" },
                          { label: "Down", value: "down" },
                          { label: "Left", value: "left" },
                          { label: "Right", value: "right" },
                        ]}
                      />
                    </Field>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

/* ----------------------------- timeline bar ------------------------------- */

function TimelineBar({
  hasTimeline,
  playing,
  playheadMs,
  durationMs,
  fps,
  captureMs,
  onEnable,
  onPlayToggle,
  onScrubStart,
  onScrub,
  onScrubEnd,
  onReset,
  onSetCapture,
  onChangeDuration,
  onChangeFps,
}: {
  hasTimeline: boolean;
  playing: boolean;
  playheadMs: number;
  durationMs: number;
  fps: number;
  captureMs: number;
  onEnable: () => void;
  onPlayToggle: () => void;
  onScrubStart: () => void;
  onScrub: (ms: number) => void;
  onScrubEnd: () => void;
  onReset: () => void;
  onSetCapture: () => void;
  onChangeDuration: (ms: number) => void;
  onChangeFps: (fps: number) => void;
}) {
  if (!hasTimeline) {
    return (
      <div className="h-12 flex-shrink-0 border-t border-card-border bg-background px-4 flex items-center gap-3">
        <Film className="w-4 h-4 text-muted-foreground" />
        <span className="text-[12px] text-muted-foreground">
          Dynamic variant — enable a timeline to animate layers.
        </span>
        <button
          type="button"
          onClick={onEnable}
          className="ml-auto px-3 py-1.5 text-[12px] bg-[hsl(var(--primary))] text-white"
          data-testid="timeline-enable"
        >
          Enable animation
        </button>
      </div>
    );
  }
  return (
    <div className="flex-shrink-0 border-t border-card-border bg-background px-4 py-2.5 flex items-center gap-3">
      <button
        type="button"
        onClick={onPlayToggle}
        className="w-8 h-8 flex items-center justify-center bg-[hsl(var(--primary))] text-white"
        data-testid="timeline-play"
        title={playing ? "Pause" : "Play"}
      >
        {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
      </button>
      <button
        type="button"
        onClick={onReset}
        className="w-8 h-8 flex items-center justify-center bg-muted hover:bg-muted/70 text-foreground"
        data-testid="timeline-reset"
        title="Reset to start"
      >
        <RotateCcw className="w-3.5 h-3.5" />
      </button>
      <span className="text-[11px] tabular-nums text-muted-foreground w-20 text-center">
        {fmtMs(playheadMs)} / {fmtMs(durationMs)}
      </span>
      <input
        type="range"
        min={0}
        max={durationMs}
        step={10}
        value={Math.min(playheadMs, durationMs)}
        onMouseDown={onScrubStart}
        onMouseUp={onScrubEnd}
        onTouchStart={onScrubStart}
        onTouchEnd={onScrubEnd}
        onChange={(e) => onScrub(parseInt(e.target.value, 10))}
        className="flex-1 accent-[hsl(var(--primary))]"
        data-testid="timeline-scrub"
      />
      <label className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
        Duration
        <input
          type="number"
          min={500}
          step={500}
          value={durationMs}
          onChange={(e) => {
            const n = parseInt(e.target.value, 10);
            if (Number.isFinite(n)) onChangeDuration(Math.max(500, n));
          }}
          className="w-16 px-1.5 py-1 text-[11.5px] bg-background border border-card-border text-foreground focus:outline-none"
          data-testid="timeline-duration"
        />
      </label>
      <label className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
        FPS
        <input
          type="number"
          min={1}
          max={60}
          value={fps}
          onChange={(e) => {
            const n = parseInt(e.target.value, 10);
            if (Number.isFinite(n)) onChangeFps(Math.min(60, Math.max(1, n)));
          }}
          className="w-12 px-1.5 py-1 text-[11.5px] bg-background border border-card-border text-foreground focus:outline-none"
          data-testid="timeline-fps"
        />
      </label>
      <button
        type="button"
        onClick={onSetCapture}
        className="px-2.5 py-1.5 text-[11.5px] bg-muted hover:bg-muted/70 text-foreground whitespace-nowrap"
        data-testid="timeline-set-capture"
        title="Set the static poster frame to the current playhead time"
      >
        Poster @ {fmtMs(captureMs)}
      </button>
    </div>
  );
}
