/**
 * Creative Studio — per-creative multi-dimension editor (full screen). Shows a
 * single feed row rendered across EVERY template dimension at once and exposes:
 *   - a COPY panel (rich-text schema fields + uid / locale / tags),
 *   - an IMAGE panel (media fields via the shared MediaPicker, with the
 *     template's preselected suggestions),
 *   - MULTI SLICE: a per-source-image focal crop (pan x/y + zoom) written to
 *     `row.crops[fieldId]` and applied consistently to every cover-fit layer in
 *     every dimension,
 *   - "Render & store": rasterises this creative across all dimensions/formats
 *     to real bitmaps under `.studio/renders/`.
 * Edits are kept in a local draft and persisted via `useUpdateRow` on Save.
 */
import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "wouter";
import {
  ArrowLeft,
  Save,
  Check,
  Loader2,
  Image as ImageIcon,
  Type as TypeIcon,
  Crop,
  ImagePlus,
  RotateCcw,
  Download,
  Sparkles,
  Move,
  ExternalLink,
  SlidersHorizontal,
  Minus,
  Plus,
} from "lucide-react";
import StudioKonva from "@/components/studio/StudioKonva";
import StudioRenderQueue, {
  type RenderSpec,
} from "@/components/studio/StudioRenderQueue";
import { MediaPicker } from "@/components/studio/MediaPicker";
import { StudioAgentPanel } from "@/components/studio/StudioAgentPanel";
import { SmartCropModal } from "@/components/studio/agent-modals";
import {
  assetFileUrl,
  feedExportUrl,
  mergeValues,
} from "@/components/studio/scene";
import {
  clearFieldCrops,
  fieldHasCrop,
  perSizeCropCount,
  compositeCropKey,
  zoomCrop,
  IDENTITY_CROP,
} from "@/components/studio/cropMath";
import {
  useFeed,
  useTemplate,
  useAssets,
  useUpdateRow,
  usePersistRenders,
  useRenders,
  type RenderUploadItem,
} from "@/lib/studio-api";
import {
  STUDIO_STATIC_FORMATS,
  STUDIO_DYNAMIC_FORMATS,
  type StudioAsset,
  type StudioCropOverride,
  type StudioStyleOverride,
  type StudioCreativeRow,
  type StudioVariant,
  type StudioImageLayer,
} from "@/components/studio/types";

interface Draft {
  uid: string;
  locale: string;
  tags: string;
  values: Record<string, string>;
  crops: Record<string, StudioCropOverride>;
  styleOverrides: Record<string, StudioStyleOverride>;
}

function draftFromRow(row: StudioCreativeRow): Draft {
  return {
    uid: row.uid,
    locale: row.locale,
    tags: row.tags.join(", "),
    values: { ...row.values },
    crops: { ...(row.crops ?? {}) },
    styleOverrides: { ...(row.styleOverrides ?? {}) },
  };
}

// Static formats apply to every dimension; dynamic formats (gif/html5) are only
// produced for dynamic variants and only when enabled in the output settings.
function formatsForVariant(
  formatsByVariant: Record<string, string[]>,
  variant: StudioVariant,
): string[] {
  const raw = formatsByVariant[variant.id] ?? [];
  const isDynamic = variant.type === "dynamic";
  const allowed = raw.filter(
    (f) =>
      (STUDIO_STATIC_FORMATS as readonly string[]).includes(f) ||
      (isDynamic && (STUDIO_DYNAMIC_FORMATS as readonly string[]).includes(f)),
  );
  return allowed.length > 0 ? allowed : ["png"];
}

const EMPTY_CROPS: Record<string, StudioCropOverride> = {};

/**
 * Debounce a frequently-changing value. Used to keep textarea typing snappy
 * while the (expensive) Konva preview grid only re-renders after a short pause.
 */
function useDebouncedValue<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

interface PreviewCellProps {
  variant: StudioVariant;
  values: Record<string, string>;
  assetsById: Record<string, StudioAsset>;
  crops: Record<string, StudioCropOverride>;
  styleOverrides: Record<string, StudioStyleOverride>;
  scrollRootRef: React.RefObject<HTMLElement | null>;
  cropFieldId?: string | null;
  perSizeCrop?: boolean;
  onCropDraft?: (cropKey: string, crop: StudioCropOverride) => void;
  onEnterCrop?: (fieldId: string) => void;
}

/**
 * One dimension's live preview. Memoised so unrelated state changes don't force
 * every Konva stage to re-render, and lazy-mounted via IntersectionObserver so
 * off-screen dimensions (14+ of them) don't all paint at once.
 */
const PreviewCell = memo(function PreviewCell({
  variant,
  values,
  assetsById,
  crops,
  styleOverrides,
  scrollRootRef,
  cropFieldId,
  perSizeCrop,
  onCropDraft,
  onEnterCrop,
}: PreviewCellProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (visible) return;
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setVisible(true);
            io.disconnect();
            break;
          }
        }
      },
      { root: scrollRootRef.current ?? null, rootMargin: "600px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [visible, scrollRootRef]);

  const box = 280;
  const scale = Math.min(box / variant.width, 320 / variant.height, 1);
  const w = Math.round(variant.width * scale);
  const h = Math.round(variant.height * scale);

  return (
    <div
      ref={ref}
      className="flex flex-col"
      data-testid={`preview-variant-${variant.id}`}
    >
      <div className="text-[11px] text-muted-foreground mb-1.5 flex items-center gap-1.5">
        <span className="font-medium text-foreground">{variant.name}</span>
        <span className="tabular-nums">
          {variant.width}×{variant.height}
        </span>
        <span className="uppercase text-[9.5px] border border-card-border px-1 text-muted-foreground">
          {variant.type}
        </span>
      </div>
      <div
        className="bg-muted border border-card-border flex items-center justify-center"
        style={{ width: w, height: h }}
      >
        {visible ? (
          <StudioKonva
            scene={variant.scene}
            width={variant.width}
            height={variant.height}
            scale={scale}
            values={values}
            assetsById={assetsById}
            crops={crops}
            variantId={variant.id}
            perSizeCrop={perSizeCrop}
            styleOverrides={styleOverrides}
            cropFieldId={cropFieldId}
            onCropDraft={onCropDraft}
            onEnterCrop={onEnterCrop}
          />
        ) : null}
      </div>
    </div>
  );
});

export default function CreativeEditorPage() {
  const params = useParams();
  const feedId = params.id as string;
  const rowId = params.rowId as string;

  const { data: feed, isLoading } = useFeed(feedId);
  const { data: template } = useTemplate(feed?.templateId, {
    enabled: !!feed?.templateId,
  });
  const { data: assets = [] } = useAssets();
  const { data: renders = [] } = useRenders(feedId);

  const updateRow = useUpdateRow(feedId);
  const persistRenders = usePersistRenders();

  const row = feed?.rows.find((r) => r.id === rowId);

  const [draft, setDraft] = useState<Draft | null>(null);
  const [dirty, setDirty] = useState(false);
  const [pickerField, setPickerField] = useState<string | null>(null);
  const [sliceField, setSliceField] = useState<string>("");
  // Multi-slice: when on, dragging a frame writes a per-size crop
  // (`${variantId}:${fieldId}`) so each banner size can be reframed
  // independently; when off, a single base crop applies to every dimension.
  const [perSizeCrop, setPerSizeCrop] = useState(false);
  const [smartCropOpen, setSmartCropOpen] = useState(false);
  const [renderSpecs, setRenderSpecs] = useState<RenderSpec[] | null>(null);
  const [renderMsg, setRenderMsg] = useState<string>("");
  const [progress, setProgress] = useState<{ done: number; total: number }>({
    done: 0,
    total: 0,
  });
  // Multi-slice view: which dimensions are shown in the preview grid. Hiding a
  // size only scopes the working view (and which previews paint) — it never
  // drops the variant from the template or from rendering. The last visible
  // size can't be hidden so the grid is never empty.
  const [hiddenVariantIds, setHiddenVariantIds] = useState<Set<string>>(
    () => new Set(),
  );

  const loadedRef = useRef<string | null>(null);
  useEffect(() => {
    if (row && loadedRef.current !== row.id) {
      setDraft(draftFromRow(row));
      setDirty(false);
      loadedRef.current = row.id;
    }
  }, [row]);

  const assetsById = useMemo(
    () => Object.fromEntries(assets.map((a) => [a.id, a])),
    [assets],
  );

  const schemaDefaults = useMemo(() => {
    const m: Record<string, string> = {};
    for (const f of template?.schemaFields ?? []) {
      if (f.defaultValue) m[f.id] = f.defaultValue;
    }
    return m;
  }, [template]);

  const mergedValues = useMemo(
    () => (draft ? mergeValues(schemaDefaults, draft.values) : schemaDefaults),
    [draft, schemaDefaults],
  );

  // The preview grid is expensive (14+ Konva stages). Debounce the values/crops
  // it consumes so typing stays snappy; the textareas read draft.values directly
  // and stay immediate.
  const debouncedValues = useDebouncedValue(mergedValues, 200);
  const debouncedCrops = useDebouncedValue(draft?.crops ?? EMPTY_CROPS, 200);
  const previewScrollRef = useRef<HTMLElement>(null);

  // Dimensions shown in the grid (multi-slice working set). Always preserves
  // template order so toggling sizes never reshuffles the layout.
  const visibleVariants = useMemo(
    () => (template?.variants ?? []).filter((v) => !hiddenVariantIds.has(v.id)),
    [template, hiddenVariantIds],
  );

  const toggleVariant = useCallback(
    (id: string) => {
      setHiddenVariantIds((prev) => {
        const next = new Set(prev);
        if (next.has(id)) {
          next.delete(id);
        } else {
          // Never hide the final visible size — the grid must show at least one.
          const total = template?.variants.length ?? 0;
          if (total - next.size <= 1) return prev;
          next.add(id);
        }
        return next;
      });
    },
    [template],
  );

  const mediaFields = useMemo(
    () => (template?.schemaFields ?? []).filter((f) => f.type === "media"),
    [template],
  );
  const textFields = useMemo(
    () => (template?.schemaFields ?? []).filter((f) => f.type === "rich_text"),
    [template],
  );

  const storedForRow = renders.filter((r) => r.rowId === rowId).length;

  const patch = (p: Partial<Draft>) => {
    setDraft((d) => (d ? { ...d, ...p } : d));
    setDirty(true);
  };

  const setValue = (fieldId: string, value: string) => {
    setDraft((d) =>
      d ? { ...d, values: { ...d.values, [fieldId]: value } } : d,
    );
    setDirty(true);
  };

  const setCrop = (fieldId: string, crop: StudioCropOverride) => {
    setDraft((d) => (d ? { ...d, crops: { ...d.crops, [fieldId]: crop } } : d));
    setDirty(true);
  };

  // Stable identities so the memoised preview cells don't re-render on every
  // keystroke — only when the crop they actually consume changes.
  const handleCropDraft = useCallback(
    (fieldId: string, crop: StudioCropOverride) => {
      setDraft((d) =>
        d ? { ...d, crops: { ...d.crops, [fieldId]: crop } } : d,
      );
      setDirty(true);
    },
    [],
  );
  const handleEnterCrop = useCallback((fieldId: string) => {
    setSliceField(fieldId);
  }, []);

  // Reset a field's crop everywhere: the shared base key AND every per-size
  // override (`${variantId}:${fieldId}`) for that field.
  const resetCrop = (fieldId: string) => {
    setDraft((d) =>
      d ? { ...d, crops: clearFieldCrops(d.crops, fieldId) } : d,
    );
    setDirty(true);
  };

  // Reset just ONE size's per-size frame (composite key), leaving the shared
  // base crop and every other size untouched.
  const resetCropForVariant = (variantId: string) => {
    if (!sliceField) return;
    setDraft((d) => {
      if (!d) return d;
      const key = compositeCropKey(variantId, sliceField);
      if (!(key in d.crops)) return d;
      const next = { ...d.crops };
      delete next[key];
      return { ...d, crops: next };
    });
    setDirty(true);
  };

  // Zoom commits are rAF-throttled so dragging the slider repaints the ~14
  // preview stages at most once per frame; the slider thumb itself stays
  // instant via the control's own local state (see ZoomControl).
  const pendingZoom = useRef<{ fieldId: string; scale: number } | null>(null);
  const zoomRaf = useRef<number | null>(null);
  const commitZoom = useCallback((fieldId: string, scale: number) => {
    pendingZoom.current = { fieldId, scale };
    if (zoomRaf.current != null) return;
    zoomRaf.current = requestAnimationFrame(() => {
      zoomRaf.current = null;
      const p = pendingZoom.current;
      pendingZoom.current = null;
      if (!p) return;
      setDraft((d) =>
        d
          ? {
              ...d,
              crops: {
                ...d.crops,
                [p.fieldId]: zoomCrop(
                  d.crops[p.fieldId] ?? IDENTITY_CROP,
                  p.scale,
                ),
              },
            }
          : d,
      );
      setDirty(true);
    });
  }, []);
  useEffect(
    () => () => {
      if (zoomRaf.current != null) cancelAnimationFrame(zoomRaf.current);
    },
    [],
  );

  // Synchronously fold any rAF-batched pending zoom into a crops object so the
  // Save/Render paths never persist or render a value that's one frame stale
  // (e.g. the button clicked in the same frame the zoom slider was released).
  const flushPendingZoom = useCallback(
    (
      base: Record<string, StudioCropOverride>,
    ): Record<string, StudioCropOverride> => {
      if (zoomRaf.current != null) {
        cancelAnimationFrame(zoomRaf.current);
        zoomRaf.current = null;
      }
      const p = pendingZoom.current;
      pendingZoom.current = null;
      if (!p) return base;
      const merged = {
        ...base,
        [p.fieldId]: zoomCrop(base[p.fieldId] ?? IDENTITY_CROP, p.scale),
      };
      setDraft((d) => (d ? { ...d, crops: merged } : d));
      setDirty(true);
      return merged;
    },
    [],
  );

  // Per-creative layer styles (opacity / corner radius / blur) keyed by image
  // fieldId — same merge-by-field model as crops, applied across every
  // dimension. Persisted via the same Save button (onSave sends null-deletes).
  const setStyle = (fieldId: string, patch: Partial<StudioStyleOverride>) => {
    setDraft((d) =>
      d
        ? {
            ...d,
            styleOverrides: {
              ...d.styleOverrides,
              [fieldId]: { ...d.styleOverrides[fieldId], ...patch },
            },
          }
        : d,
    );
    setDirty(true);
  };
  const resetStyle = (fieldId: string) => {
    setDraft((d) => {
      if (!d) return d;
      const next = { ...d.styleOverrides };
      delete next[fieldId];
      return { ...d, styleOverrides: next };
    });
    setDirty(true);
  };

  const onSave = async (): Promise<Record<string, StudioCropOverride>> => {
    if (!draft) return {};
    // Fold any rAF-batched zoom into the saved crops synchronously so Save never
    // persists a value one frame stale (e.g. clicked right after a slider drag).
    const liveCrops = flushPendingZoom(draft.crops);
    // The server merges crops, so a field the user RESET this session would
    // otherwise survive by omission — send an explicit null to delete it.
    const cropsPayload: Record<string, StudioCropOverride | null> = {
      ...liveCrops,
    };
    for (const k of Object.keys(row?.crops ?? {})) {
      if (!(k in liveCrops)) cropsPayload[k] = null;
    }
    // Same null-delete-by-omission rule for layer style overrides.
    const stylesPayload: Record<string, StudioStyleOverride | null> = {
      ...draft.styleOverrides,
    };
    for (const k of Object.keys(row?.styleOverrides ?? {})) {
      if (!(k in draft.styleOverrides)) stylesPayload[k] = null;
    }
    await updateRow.mutateAsync({
      rowId,
      uid: draft.uid.trim(),
      locale: draft.locale.trim(),
      tags: draft.tags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean),
      values: draft.values,
      crops: cropsPayload,
      styleOverrides: stylesPayload,
    });
    setDirty(false);
    return liveCrops;
  };

  const onRenderStore = async () => {
    if (!template || !draft) return;
    // Persist the latest edits first so renders match what's on screen, and
    // flush any rAF-batched zoom so the render isn't one frame stale.
    const liveCrops =
      dirty || pendingZoom.current != null ? await onSave() : draft.crops;
    const specs: RenderSpec[] = template.variants.map((v) => ({
      rowId,
      variantId: v.id,
      width: v.width,
      height: v.height,
      scene: v.scene,
      values: mergedValues,
      crops: liveCrops,
      styleOverrides: draft.styleOverrides,
      formats: formatsForVariant(template.output.formatsByVariant, v),
    }));
    setRenderMsg("");
    setProgress({ done: 0, total: specs.length });
    setRenderSpecs(specs);
  };

  const onRenderComplete = async (items: RenderUploadItem[]) => {
    setRenderSpecs(null);
    if (items.length === 0) {
      setRenderMsg("Nothing to render.");
      return;
    }
    await persistRenders.mutateAsync({ feedId, items });
    setRenderMsg(`Stored ${items.length} render${items.length === 1 ? "" : "s"}.`);
  };

  if (isLoading || !feed) {
    return (
      <div className="flex-1 min-h-0 flex items-center justify-center bg-background text-muted-foreground text-sm gap-2">
        <Loader2 className="w-4 h-4 animate-spin" /> Loading creative…
      </div>
    );
  }
  if (!row || !template || !draft) {
    return (
      <div className="flex-1 min-h-0 flex flex-col items-center justify-center bg-background text-muted-foreground text-sm gap-3">
        <p>Creative not found in this feed.</p>
        <Link
          href={`/studio/feeds/${feedId}`}
          className="text-[hsl(var(--primary))] hover:underline"
          data-testid="link-back-missing"
        >
          Back to feed
        </Link>
      </div>
    );
  }

  const rendering = !!renderSpecs;
  const activeSlice = sliceField
    ? draft.crops[sliceField] ?? { x: 0, y: 0, scale: 1 }
    : null;
  // A field is "cropped" if it has a shared base crop OR any per-size override.
  const hasFieldCrop = (fid: string) => fieldHasCrop(draft.crops, fid);
  const perSizeCount = sliceField
    ? perSizeCropCount(draft.crops, sliceField)
    : 0;
  const sliceAssetId = sliceField ? mergedValues[sliceField] ?? "" : "";
  const sliceFieldLabel =
    mediaFields.find((f) => f.id === sliceField)?.label ?? "";

  // Resolve the image layer bound to the selected source field so its
  // template-authored styles become the editable baseline; the per-creative
  // override (keyed by fieldId) layers on top and applies across every size.
  const styleLayer: StudioImageLayer | undefined = sliceField
    ? (template.variants[0]?.scene.layers.find(
        (l): l is StudioImageLayer =>
          l.type === "image" && l.fieldId === sliceField,
      ) ?? undefined)
    : undefined;
  const activeStyle = sliceField ? draft.styleOverrides[sliceField] : undefined;
  const effOpacity = activeStyle?.opacity ?? styleLayer?.opacity ?? 1;
  const effCornerRadius =
    activeStyle?.cornerRadius ?? styleLayer?.cornerRadius ?? 0;
  const effBlur = activeStyle?.blur ?? styleLayer?.blur ?? 0;

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-background text-foreground overflow-hidden">
      {/* Top bar */}
      <header className="flex-shrink-0 h-12 px-3 flex items-center gap-3 bg-card border-b border-card-border">
        <Link
          href={`/studio/feeds/${feedId}`}
          className="inline-flex items-center gap-1.5 text-[12.5px] text-muted-foreground hover:text-foreground"
          data-testid="link-back-feed"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </Link>
        <div className="h-5 w-px bg-muted" />
        <div className="min-w-0">
          <div className="text-[13px] font-medium leading-none truncate">
            {draft.uid || row.id}
          </div>
          <div className="text-[11px] text-muted-foreground mt-0.5">
            {feed.name} · {template.variants.length} dimensions
            {draft.locale ? ` · ${draft.locale}` : ""}
          </div>
        </div>

        <div className="ml-auto flex items-center gap-2">
          {renderMsg && (
            <span className="text-[11.5px] text-emerald-600" data-testid="render-msg">
              {renderMsg}
            </span>
          )}
          {storedForRow > 0 && (
            <a
              href={feedExportUrl(feedId)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[12px] border border-card-border text-foreground hover:text-foreground"
              data-testid="button-export-zip"
            >
              <Download className="w-3.5 h-3.5" /> ZIP
            </a>
          )}
          <button
            type="button"
            onClick={onRenderStore}
            disabled={rendering || persistRenders.isPending}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[12px] border border-card-border text-foreground hover:text-foreground disabled:opacity-50"
            data-testid="button-render-store"
          >
            {rendering || persistRenders.isPending ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <ImagePlus className="w-3.5 h-3.5" />
            )}
            {rendering
              ? `Rendering ${progress.done}/${progress.total}`
              : "Render & store"}
          </button>
          <button
            type="button"
            onClick={onSave}
            disabled={updateRow.isPending || !dirty}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12px] bg-[hsl(var(--primary))] text-white disabled:opacity-50"
            data-testid="button-save-creative"
          >
            {updateRow.isPending ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : dirty ? (
              <Save className="w-3.5 h-3.5" />
            ) : (
              <Check className="w-3.5 h-3.5" />
            )}
            {dirty ? "Save" : "Saved"}
          </button>
        </div>
      </header>

      <div className="flex-1 min-h-0 flex">
        {/* COPY panel */}
        <aside className="w-72 flex-shrink-0 bg-card border-r border-card-border flex flex-col overflow-auto">
          <div className="px-3 py-2.5 border-b border-card-border flex items-center gap-1.5">
            <TypeIcon className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
              Copy & metadata
            </span>
          </div>
          <div className="p-3 space-y-3">
            <label className="block">
              <span className="block text-[10.5px] uppercase tracking-wide text-muted-foreground mb-1">
                UID
              </span>
              <input
                value={draft.uid}
                onChange={(e) => patch({ uid: e.target.value })}
                className="w-full px-2 py-1.5 text-[12.5px] bg-background border border-card-border text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
                data-testid="input-uid"
              />
            </label>
            <div className="grid grid-cols-2 gap-2">
              <label className="block">
                <span className="block text-[10.5px] uppercase tracking-wide text-muted-foreground mb-1">
                  Locale
                </span>
                <input
                  value={draft.locale}
                  onChange={(e) => patch({ locale: e.target.value })}
                  placeholder="en-US"
                  className="w-full px-2 py-1.5 text-[12.5px] bg-background border border-card-border text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
                  data-testid="input-locale"
                />
              </label>
              <label className="block">
                <span className="block text-[10.5px] uppercase tracking-wide text-muted-foreground mb-1">
                  Tags
                </span>
                <input
                  value={draft.tags}
                  onChange={(e) => patch({ tags: e.target.value })}
                  placeholder="tag1, tag2"
                  className="w-full px-2 py-1.5 text-[12.5px] bg-background border border-card-border text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
                  data-testid="input-tags"
                />
              </label>
            </div>

            <div className="h-px bg-muted my-1" />

            {textFields.length === 0 ? (
              <p className="text-[11.5px] text-muted-foreground">
                This template has no rich-text fields.
              </p>
            ) : (
              textFields.map((f) => (
                <label key={f.id} className="block">
                  <span className="block text-[10.5px] uppercase tracking-wide text-muted-foreground mb-1">
                    {f.label}
                  </span>
                  <textarea
                    value={draft.values[f.id] ?? ""}
                    onChange={(e) => setValue(f.id, e.target.value)}
                    rows={2}
                    placeholder={f.defaultValue || f.label}
                    className="w-full px-2 py-1.5 text-[12.5px] bg-background border border-card-border text-foreground focus:outline-none focus:border-[hsl(var(--primary))] resize-y"
                    data-testid={`input-text-${f.id}`}
                  />
                  {f.description && (
                    <span className="block text-[10px] text-muted-foreground mt-0.5">
                      {f.description}
                    </span>
                  )}
                </label>
              ))
            )}
          </div>
        </aside>

        {/* Center — all dimensions */}
        <main
          ref={previewScrollRef}
          className="flex-1 min-h-0 overflow-auto bg-muted/40 p-5"
        >
          {/* Multi-slice size selector — toggle which dimensions appear in the
              working grid. The last visible size can't be hidden. */}
          <div className="mb-4 flex flex-wrap items-center gap-1.5">
            <span className="text-[10.5px] uppercase tracking-wide text-muted-foreground mr-1">
              Sizes
            </span>
            {template.variants.map((v) => {
              const shown = !hiddenVariantIds.has(v.id);
              return (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => toggleVariant(v.id)}
                  aria-pressed={shown}
                  title={`${v.width}×${v.height}`}
                  className={`px-2 py-1 text-[11px] border tabular-nums transition-colors ${
                    shown
                      ? "border-[hsl(var(--primary))] bg-[hsl(var(--primary))]/[0.08] text-foreground"
                      : "border-card-border bg-muted/40 text-muted-foreground line-through"
                  }`}
                  data-testid={`toggle-variant-${v.id}`}
                >
                  {v.name}
                </button>
              );
            })}
            {hiddenVariantIds.size > 0 && (
              <button
                type="button"
                onClick={() => setHiddenVariantIds(new Set())}
                className="ml-1 px-2 py-1 text-[11px] text-[hsl(var(--primary))] hover:underline"
                data-testid="button-show-all-variants"
              >
                Show all ({hiddenVariantIds.size} hidden)
              </button>
            )}
          </div>
          <div className="flex flex-wrap gap-5">
            {visibleVariants.map((v) => (
              <PreviewCell
                key={v.id}
                variant={v}
                values={debouncedValues}
                assetsById={assetsById}
                // While cropping, feed the live (undebounced) crop so the focal
                // frame tracks the pointer across every size in real time.
                crops={sliceField ? draft.crops : debouncedCrops}
                styleOverrides={draft.styleOverrides}
                scrollRootRef={previewScrollRef}
                cropFieldId={sliceField || null}
                perSizeCrop={perSizeCrop}
                onCropDraft={handleCropDraft}
                onEnterCrop={handleEnterCrop}
              />
            ))}
          </div>
        </main>

        {/* IMAGE + MULTI SLICE panel */}
        <aside className="w-72 flex-shrink-0 bg-card border-l border-card-border flex flex-col overflow-auto">
          <div className="px-3 py-2.5 border-b border-card-border flex items-center gap-1.5">
            <ImageIcon className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
              Imagery
            </span>
          </div>
          <div className="p-3 space-y-3">
            {mediaFields.length === 0 ? (
              <p className="text-[11.5px] text-muted-foreground">
                This template has no media fields.
              </p>
            ) : (
              mediaFields.map((f) => {
                const current = draft.values[f.id]
                  ? assetsById[draft.values[f.id]]
                  : undefined;
                const suggestions = (f.preselectedAssetIds ?? [])
                  .map((id) => assetsById[id])
                  .filter(Boolean) as StudioAsset[];
                return (
                  <div key={f.id} className="space-y-1.5">
                    <span className="block text-[10.5px] uppercase tracking-wide text-muted-foreground">
                      {f.label}
                    </span>
                    <div className="flex items-center gap-2">
                      <div className="w-12 h-12 bg-muted border border-card-border flex items-center justify-center overflow-hidden flex-shrink-0">
                        {current ? (
                          <img
                            src={assetFileUrl(current.fileName)}
                            crossOrigin="anonymous"
                            alt={current.originalName}
                            className="w-full h-full object-contain"
                          />
                        ) : (
                          <ImageIcon className="w-4 h-4 text-muted-foreground" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <button
                          type="button"
                          onClick={() => setPickerField(f.id)}
                          className="px-2.5 py-1.5 text-[12px] bg-muted hover:bg-muted/70 w-full text-left"
                          data-testid={`button-pick-${f.id}`}
                        >
                          {current ? "Replace…" : "Choose…"}
                        </button>
                        {current && (
                          <button
                            type="button"
                            onClick={() => setValue(f.id, "")}
                            className="mt-1 text-[10.5px] text-muted-foreground hover:text-foreground"
                            data-testid={`button-clear-${f.id}`}
                          >
                            Clear
                          </button>
                        )}
                      </div>
                    </div>
                    {suggestions.length > 0 && (
                      <div className="mt-1 border border-[hsl(var(--primary))]/25 bg-[hsl(var(--primary))]/[0.04] p-2">
                        <div className="flex items-center gap-1.5 mb-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-[hsl(var(--primary))]" />
                          <span className="text-[10.5px] font-medium uppercase tracking-wide text-[hsl(var(--primary))]">
                            Suggested for this slot
                          </span>
                          <span className="text-[10px] text-muted-foreground">
                            {suggestions.length}
                          </span>
                        </div>
                        <div className="grid grid-cols-4 gap-1.5">
                          {suggestions.map((s) => (
                            <button
                              key={s.id}
                              type="button"
                              onClick={() => setValue(f.id, s.id)}
                              title={`Use ${s.originalName}`}
                              className={`aspect-square border overflow-hidden bg-muted transition-colors ${
                                draft.values[f.id] === s.id
                                  ? "border-[hsl(var(--primary))] ring-1 ring-[hsl(var(--primary))]"
                                  : "border-card-border hover:border-[hsl(var(--primary))]"
                              }`}
                              data-testid={`suggestion-${f.id}-${s.id}`}
                            >
                              <img
                                src={assetFileUrl(s.fileName)}
                                crossOrigin="anonymous"
                                alt={s.originalName}
                                className="w-full h-full object-contain"
                              />
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}

            {mediaFields.length > 0 && (
              <>
                <div className="h-px bg-muted my-1" />
                <div className="flex items-center gap-1.5">
                  <Crop className="w-3.5 h-3.5 text-[hsl(var(--primary))]" />
                  <span className="text-[11px] uppercase tracking-wide text-foreground/80 font-medium">
                    Dynamic crop
                  </span>
                </div>
                <p className="text-[10.5px] text-muted-foreground leading-snug">
                  Reframe a source image and the focal crop re-flows across every
                  cover-fit size automatically. Switch to Per-size to give each
                  dimension its own frame.
                </p>
                <label className="block">
                  <span className="block text-[10.5px] uppercase tracking-wide text-muted-foreground mb-1">
                    Source field
                  </span>
                  <select
                    value={sliceField}
                    onChange={(e) => setSliceField(e.target.value)}
                    className="w-full px-2 py-1.5 text-[12px] bg-background border border-card-border text-foreground focus:outline-none"
                    data-testid="select-slice-field"
                  >
                    <option value="">Select field…</option>
                    {mediaFields.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.label}
                        {hasFieldCrop(f.id) ? " (cropped)" : ""}
                      </option>
                    ))}
                  </select>
                </label>

                {sliceField && (
                  <div>
                    <span className="block text-[10.5px] uppercase tracking-wide text-muted-foreground mb-1">
                      Frame mode
                    </span>
                    <div className="grid grid-cols-2 gap-1 p-0.5 bg-muted/50 border border-card-border">
                      <button
                        type="button"
                        onClick={() => setPerSizeCrop(false)}
                        className={`px-2 py-1.5 text-[11px] transition-colors ${
                          !perSizeCrop
                            ? "bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                        data-testid="toggle-crop-shared"
                      >
                        One frame
                      </button>
                      <button
                        type="button"
                        onClick={() => setPerSizeCrop(true)}
                        className={`px-2 py-1.5 text-[11px] transition-colors ${
                          perSizeCrop
                            ? "bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                        data-testid="toggle-crop-per-size"
                      >
                        Per size{perSizeCount > 0 ? ` · ${perSizeCount}` : ""}
                      </button>
                    </div>
                  </div>
                )}

                {sliceField && (
                  <button
                    type="button"
                    onClick={() => setSmartCropOpen(true)}
                    disabled={!sliceAssetId}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[11.5px] border border-[hsl(var(--primary))]/60 text-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/10 disabled:opacity-40 disabled:hover:bg-transparent w-full justify-center"
                    title={
                      sliceAssetId
                        ? "Suggest focal crops with AI"
                        : "Pick a source image for this field first"
                    }
                    data-testid="button-suggest-crops"
                  >
                    <Sparkles className="w-3.5 h-3.5" /> Suggest crops
                  </button>
                )}

                {sliceField && activeSlice && (
                  <div className="space-y-2.5 pt-1">
                    <div className="flex items-start gap-1.5 px-2 py-1.5 bg-[hsl(var(--primary))]/8 border border-[hsl(var(--primary))]/30 text-[10.5px] text-foreground/80 leading-snug">
                      <Move className="w-3.5 h-3.5 mt-px flex-shrink-0 text-[hsl(var(--primary))]" />
                      <span>
                        {perSizeCrop
                          ? "Drag inside each frame to reposition that size · scroll over a frame to zoom it. Every size keeps its own frame."
                          : "Drag the image inside any frame to reposition · scroll over a frame (or use Zoom) to zoom. The frame applies to every size."}
                      </span>
                    </div>
                    {!perSizeCrop ? (
                      <ZoomControl
                        value={activeSlice.scale}
                        min={1}
                        max={4}
                        step={0.05}
                        onChange={(scale) => commitZoom(sliceField, scale)}
                      />
                    ) : (
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-[10.5px] uppercase tracking-wide text-muted-foreground">
                          <span>Per-size frames</span>
                          <span className="tabular-nums">
                            {perSizeCount}/{template.variants.length}
                          </span>
                        </div>
                        <div className="max-h-44 overflow-auto border border-card-border divide-y divide-card-border">
                          {template.variants.map((v) => {
                            const custom =
                              compositeCropKey(v.id, sliceField) in draft.crops;
                            return (
                              <div
                                key={v.id}
                                className="flex items-center justify-between gap-2 px-2 py-1 text-[10.5px]"
                                data-testid={`per-size-row-${v.id}`}
                              >
                                <span className="truncate text-foreground/80">
                                  {v.name}
                                </span>
                                <div className="flex items-center gap-1.5 flex-shrink-0">
                                  <span
                                    className={
                                      custom
                                        ? "text-[hsl(var(--primary))]"
                                        : "text-muted-foreground/60"
                                    }
                                  >
                                    {custom ? "Custom" : "Shared"}
                                  </span>
                                  {custom && (
                                    <button
                                      type="button"
                                      onClick={() => resetCropForVariant(v.id)}
                                      className="text-muted-foreground hover:text-foreground"
                                      aria-label={`Reset ${v.name} frame`}
                                      data-testid={`reset-size-${v.id}`}
                                    >
                                      <RotateCcw className="w-3 h-3" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSliceField("")}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[11.5px] bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] hover:opacity-90 flex-1 justify-center"
                        data-testid="button-done-crop"
                      >
                        <Check className="w-3.5 h-3.5" /> Done
                      </button>
                      <button
                        type="button"
                        onClick={() => resetCrop(sliceField)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[11.5px] border border-card-border text-muted-foreground hover:text-foreground"
                        data-testid="button-reset-crop"
                      >
                        <RotateCcw className="w-3.5 h-3.5" /> Reset all
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}

            {styleLayer && sliceField ? (
              <>
                <div className="h-px bg-muted my-1" />
                <div className="flex items-center gap-1.5">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
                    Layer style · {sliceFieldLabel}
                  </span>
                </div>
                <div>
                  <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1">
                    <span>Opacity</span>
                    <span className="tabular-nums">
                      {Math.round(effOpacity * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={Math.round(effOpacity * 100)}
                    onChange={(e) =>
                      setStyle(sliceField, {
                        opacity: parseInt(e.target.value, 10) / 100,
                      })
                    }
                    className="w-full accent-[hsl(var(--primary))]"
                    data-testid="slider-creative-opacity"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1">
                    <span>Corner radius</span>
                    <span className="tabular-nums">
                      {Math.round(effCornerRadius)}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={120}
                    value={Math.round(effCornerRadius)}
                    onChange={(e) =>
                      setStyle(sliceField, {
                        cornerRadius: parseInt(e.target.value, 10),
                      })
                    }
                    className="w-full accent-[hsl(var(--primary))]"
                    data-testid="slider-creative-corner"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1">
                    <span>Blur</span>
                    <span className="tabular-nums">{Math.round(effBlur)}px</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={80}
                    value={Math.round(effBlur)}
                    onChange={(e) =>
                      setStyle(sliceField, { blur: parseInt(e.target.value, 10) })
                    }
                    className="w-full accent-[hsl(var(--primary))]"
                    data-testid="slider-creative-blur"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => resetStyle(sliceField)}
                  disabled={!draft.styleOverrides[sliceField]}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[11.5px] border border-card-border text-muted-foreground hover:text-foreground disabled:opacity-40"
                  data-testid="button-reset-style"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Reset style
                </button>
                <p className="text-[10.5px] text-muted-foreground leading-snug">
                  Overrides this creative only, across every dimension. Save to
                  persist; Reset reverts to the template default.
                </p>
              </>
            ) : (
              template.variants[0] && (
                <>
                  <div className="h-px bg-muted my-1" />
                  <p className="text-[10.5px] text-muted-foreground leading-snug">
                    Pick a Source field above to edit its layer style (opacity,
                    corner radius, blur) here — or edit the shared template
                    defaults.
                  </p>
                  <Link
                    href={`/studio/editor/${template.id}/${template.variants[0].id}`}
                    className="inline-flex items-center gap-1 text-[11px] text-[hsl(var(--primary))] hover:underline"
                    data-testid="link-creative-template-editor"
                  >
                    Edit template defaults <ExternalLink className="w-3 h-3" />
                  </Link>
                </>
              )
            )}
          </div>
        </aside>
      </div>

      <MediaPicker
        open={!!pickerField}
        onClose={() => setPickerField(null)}
        onPick={(assetId) => {
          if (pickerField) setValue(pickerField, assetId);
          setPickerField(null);
        }}
        title="Select media"
        suggestedIds={
          pickerField
            ? mediaFields.find((f) => f.id === pickerField)?.preselectedAssetIds
            : undefined
        }
      />

      {sliceField && sliceAssetId && (
        <SmartCropModal
          open={smartCropOpen}
          onClose={() => setSmartCropOpen(false)}
          templateId={template.id}
          fieldId={sliceField}
          fieldLabel={sliceFieldLabel}
          assetId={sliceAssetId}
          variants={template.variants}
          onApply={(crop) => setCrop(sliceField, crop)}
        />
      )}

      <StudioAgentPanel
        feedId={feedId}
        templateId={feed.templateId}
        scopeLabel={draft.uid || row.id}
        onSmartCrop={
          sliceField && sliceAssetId ? () => setSmartCropOpen(true) : undefined
        }
        qaHref={`/studio/feeds/${feedId}/qa`}
      />

      {renderSpecs && (
        <StudioRenderQueue
          specs={renderSpecs}
          assetsById={assetsById}
          onComplete={onRenderComplete}
          onProgress={(done, total) => setProgress({ done, total })}
        />
      )}
    </div>
  );
}

/**
 * Zoom control for the crop editor. Keeps an instant local value for the thumb
 * (and ± nudge buttons) so dragging always feels responsive even while the
 * parent rAF-throttles the heavier Konva preview repaint.
 */
function ZoomControl({
  value,
  min,
  max,
  step,
  onChange,
}: {
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (n: number) => void;
}) {
  const [local, setLocal] = useState(value);
  const dragging = useRef(false);
  useEffect(() => {
    if (!dragging.current) setLocal(value);
  }, [value]);
  const emit = (n: number) => {
    const c = Math.max(min, Math.min(max, parseFloat(n.toFixed(2))));
    setLocal(c);
    onChange(c);
  };
  const btn =
    "w-6 h-6 flex items-center justify-center flex-shrink-0 border border-card-border text-muted-foreground hover:text-foreground hover:border-[hsl(var(--primary))] disabled:opacity-40 disabled:hover:border-card-border disabled:hover:text-muted-foreground";
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-[10.5px] uppercase tracking-wide text-muted-foreground">
        <span>Zoom</span>
        <span className="tabular-nums text-foreground/70">
          {local.toFixed(2)}×
        </span>
      </div>
      <div className="flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => emit(local - step * 4)}
          disabled={local <= min}
          className={btn}
          aria-label="Zoom out"
          data-testid="button-zoom-out"
        >
          <Minus className="w-3 h-3" />
        </button>
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={local}
          onPointerDown={() => {
            dragging.current = true;
          }}
          onPointerUp={() => {
            dragging.current = false;
          }}
          onPointerCancel={() => {
            dragging.current = false;
          }}
          onChange={(e) => emit(parseFloat(e.target.value))}
          className="flex-1 h-1.5 accent-[hsl(var(--primary))] cursor-pointer"
          data-testid="slice-scale"
        />
        <button
          type="button"
          onClick={() => emit(local + step * 4)}
          disabled={local >= max}
          className={btn}
          aria-label="Zoom in"
          data-testid="button-zoom-in"
        >
          <Plus className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}
