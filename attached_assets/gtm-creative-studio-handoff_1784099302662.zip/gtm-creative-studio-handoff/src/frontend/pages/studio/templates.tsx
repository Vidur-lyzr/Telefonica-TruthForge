/**
 * Creative Studio — Templates overview. Lists every banner template (name,
 * brand, dimension + field counts) linking into the detail editor, and lets
 * the user spin up a new template or delete an existing one.
 */
import { useEffect, useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutTemplate,
  Plus,
  Trash2,
  X,
  ArrowRight,
  Layers,
  ListTree,
} from "lucide-react";
import { StudioLayout } from "@/components/studio/StudioLayout";
import { StudioAgentPanel } from "@/components/studio/StudioAgentPanel";
import {
  useTemplates,
  useCreateTemplate,
  useDeleteTemplate,
} from "@/lib/studio-api";

function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  testId,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  testId?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      data-testid={testId}
    >
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-md border border-card-border bg-card shadow-lg">
        <div className="flex items-center justify-between border-b border-card-border px-4 py-3">
          <h3 className="text-[14px] font-semibold text-foreground">{title}</h3>
          <button
            type="button"
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-modal-close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4">{children}</div>
        {footer && (
          <div className="flex justify-end gap-2 border-t border-card-border px-4 py-3">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

export default function TemplatesPage() {
  const { data: templates = [], isLoading } = useTemplates();
  const createTemplate = useCreateTemplate();
  const deleteTemplate = useDeleteTemplate();
  const [, navigate] = useLocation();

  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");

  const openCreate = () => {
    setName("");
    setBrand("");
    setCreateOpen(true);
  };

  const submitCreate = async () => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const created = await createTemplate.mutateAsync({
      name: trimmed,
      brand: brand.trim() || undefined,
    });
    setCreateOpen(false);
    navigate(`/studio/templates/${created.id}`);
  };

  const removeTemplate = (id: string, label: string) => {
    if (!window.confirm(`Delete template “${label}”? This cannot be undone.`))
      return;
    deleteTemplate.mutate(id);
  };

  return (
    <StudioLayout
      active="templates"
      actions={
        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95"
          data-testid="button-new-template"
        >
          <Plus className="w-3.5 h-3.5" /> New template
        </button>
      }
    >
      <div className="p-6">
        {isLoading ? (
          <div className="text-[13px] text-muted-foreground">
            Loading templates…
          </div>
        ) : templates.length === 0 ? (
          <div className="border border-dashed border-card-border bg-card p-10 text-center">
            <div className="w-10 h-10 mx-auto bg-muted flex items-center justify-center text-muted-foreground mb-3">
              <LayoutTemplate className="w-5 h-5" />
            </div>
            <div className="text-[13px] font-medium text-foreground">
              No templates yet
            </div>
            <p className="text-[12px] text-muted-foreground mt-1">
              Create a template to define ad dimensions, schema fields and
              outputs.
            </p>
            <button
              type="button"
              onClick={openCreate}
              className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95"
              data-testid="button-new-template-empty"
            >
              <Plus className="w-3.5 h-3.5" /> New template
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3">
            {templates.map((t) => (
              <div
                key={t.id}
                className="group relative border border-card-border bg-card hover:border-[hsl(var(--primary))] transition-colors"
                data-testid={`card-template-${t.id}`}
              >
                <Link
                  href={`/studio/templates/${t.id}`}
                  className="block p-4"
                  data-testid={`link-template-${t.id}`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 bg-muted flex items-center justify-center text-muted-foreground group-hover:text-[hsl(var(--primary))] flex-shrink-0">
                      <LayoutTemplate className="w-4 h-4" />
                    </div>
                    <div className="min-w-0 pr-6">
                      <div className="text-[13.5px] font-medium text-foreground truncate">
                        {t.name}
                      </div>
                      {t.brand && (
                        <div className="text-[11.5px] text-muted-foreground truncate mt-0.5">
                          {t.brand}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 mt-3 text-[11.5px] text-muted-foreground">
                    <span className="inline-flex items-center gap-1">
                      <Layers className="w-3.5 h-3.5" />
                      {t.variants.length}{" "}
                      {t.variants.length === 1 ? "dimension" : "dimensions"}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <ListTree className="w-3.5 h-3.5" />
                      {t.schemaFields.length}{" "}
                      {t.schemaFields.length === 1 ? "field" : "fields"}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </Link>
                <button
                  type="button"
                  onClick={() => removeTemplate(t.id, t.name)}
                  className="absolute top-2.5 right-2.5 w-7 h-7 flex items-center justify-center text-muted-foreground hover:text-red-600 hover:bg-red-50"
                  title="Delete template"
                  data-testid={`button-delete-template-${t.id}`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="New template"
        testId="modal-new-template"
        footer={
          <>
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:bg-muted/40"
              data-testid="button-cancel-create-template"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={submitCreate}
              disabled={!name.trim() || createTemplate.isPending}
              className="px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
              data-testid="button-confirm-create-template"
            >
              {createTemplate.isPending ? "Creating…" : "Create"}
            </button>
          </>
        }
      >
        <div className="space-y-3">
          <div>
            <label className="block text-[12px] font-medium text-foreground mb-1">
              Name
            </label>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") submitCreate();
              }}
              placeholder="e.g. AWS CX Banner Master"
              className="w-full border border-card-border bg-background px-2.5 py-1.5 text-[13px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
              data-testid="input-template-name"
            />
          </div>
          <div>
            <label className="block text-[12px] font-medium text-foreground mb-1">
              Brand <span className="text-muted-foreground">(optional)</span>
            </label>
            <input
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") submitCreate();
              }}
              placeholder="e.g. Accenture Song × AWS"
              className="w-full border border-card-border bg-background px-2.5 py-1.5 text-[13px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
              data-testid="input-template-brand"
            />
          </div>
        </div>
      </Modal>

      <StudioAgentPanel scopeLabel="Templates" />
    </StudioLayout>
  );
}
