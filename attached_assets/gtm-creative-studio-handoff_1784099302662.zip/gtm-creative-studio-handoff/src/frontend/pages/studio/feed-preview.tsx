/**
 * Creative Studio — Preview all. A live wall of every creative (feed row)
 * rendered across every template dimension via real Konva bitmaps, with
 * All / Static / Dynamic counts, locale + UID filters and a zoom control.
 * "Render & store all" rasterises the whole matrix to disk under
 * `.studio/renders/`; "Export ZIP" downloads the stored set.
 */
import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "wouter";
import {
  ArrowLeft,
  ClipboardCheck,
  Download,
  ImagePlus,
  Loader2,
  ShieldAlert,
  ZoomIn,
} from "lucide-react";
import { StudioLayout } from "@/components/studio/StudioLayout";
import StudioKonva from "@/components/studio/StudioKonva";
import StudioRenderQueue, {
  type RenderSpec,
} from "@/components/studio/StudioRenderQueue";
import {
  feedExportUrl,
  mergeValues,
  sceneDurationMs,
} from "@/components/studio/scene";
import {
  useFeed,
  useTemplate,
  useAssets,
  useRenders,
  usePersistRenders,
  type RenderUploadItem,
} from "@/lib/studio-api";
import {
  STUDIO_STATIC_FORMATS,
  STUDIO_DYNAMIC_FORMATS,
  type StudioAsset,
  type StudioVariant,
} from "@/components/studio/types";

type TypeFilter = "all" | "static" | "dynamic";

const ZOOMS: { label: string; box: number }[] = [
  { label: "S", box: 140 },
  { label: "M", box: 200 },
  { label: "L", box: 280 },
];

// Static formats apply to every dimension; dynamic formats (gif/html5) are only
// produced for dynamic variants and only when explicitly enabled in the output
// settings. Falls back to a poster PNG so a render always yields something.
function formatsForVariant(
  formatsByVariant: Record<string, string[]>,
  variant: StudioVariant,
): string[] {
  const raw = formatsByVariant[variant.id] ?? [];
  const isDynamic = variant.type === "dynamic";
  const allowed = raw.filter(
    (f) =>
      (STUDIO_STATIC_FORMATS as readonly string[]).includes(f) ||
      (isDynamic && (STUDIO_DYNAMIC_FORMATS as readonly string[]).includes(f)),
  );
  return allowed.length > 0 ? allowed : ["png"];
}

export default function FeedPreviewPage() {
  const params = useParams();
  const feedId = params.id as string;

  const { data: feed, isLoading } = useFeed(feedId);
  const { data: template } = useTemplate(feed?.templateId, {
    enabled: !!feed?.templateId,
  });
  const { data: assets = [] } = useAssets();
  const { data: renders = [] } = useRenders(feedId);
  const persistRenders = usePersistRenders();

  const [typeFilter, setTypeFilter] = useState<TypeFilter>("all");
  const [locale, setLocale] = useState("all");
  const [uid, setUid] = useState("all");
  const [zoomIdx, setZoomIdx] = useState(1);
  const [renderSpecs, setRenderSpecs] = useState<RenderSpec[] | null>(null);
  const [renderMsg, setRenderMsg] = useState("");
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  // Shared playhead (ms) so every dynamic cell in the wall animates in sync.
  const [playMs, setPlayMs] = useState(0);

  const assetsById = useMemo(
    () => Object.fromEntries(assets.map((a) => [a.id, a])),
    [assets],
  );

  const schemaDefaults = useMemo(() => {
    const m: Record<string, string> = {};
    for (const f of template?.schemaFields ?? []) {
      if (f.defaultValue) m[f.id] = f.defaultValue;
    }
    return m;
  }, [template]);

  const locales = useMemo(() => {
    const s = new Set<string>();
    for (const r of feed?.rows ?? []) if (r.locale) s.add(r.locale);
    return Array.from(s).sort();
  }, [feed]);

  const variants = useMemo(() => {
    const all = template?.variants ?? [];
    if (typeFilter === "all") return all;
    return all.filter((v) => v.type === typeFilter);
  }, [template, typeFilter]);

  // Drive the shared playhead only when dynamic variants are actually on-screen,
  // throttled to ~16fps so a large wall of Konva stages stays responsive.
  const hasDynamicVisible = useMemo(
    () => variants.some((v) => v.type === "dynamic"),
    [variants],
  );
  useEffect(() => {
    if (!hasDynamicVisible) {
      setPlayMs(0);
      return;
    }
    let raf = 0;
    let last = 0;
    const base = performance.now();
    const tick = (t: number) => {
      const elapsed = t - base;
      if (elapsed - last >= 60) {
        last = elapsed;
        setPlayMs(elapsed);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [hasDynamicVisible]);

  const rows = useMemo(() => {
    let rs = feed?.rows ?? [];
    if (locale !== "all") rs = rs.filter((r) => r.locale === locale);
    if (uid !== "all") rs = rs.filter((r) => r.id === uid);
    return rs;
  }, [feed, locale, uid]);

  const counts = useMemo(() => {
    const rs = (feed?.rows ?? []).filter(
      (r) =>
        (locale === "all" || r.locale === locale) &&
        (uid === "all" || r.id === uid),
    );
    const staticN = (template?.variants ?? []).filter(
      (v) => v.type === "static",
    ).length;
    const dynamicN = (template?.variants ?? []).filter(
      (v) => v.type === "dynamic",
    ).length;
    return {
      all: rs.length * (staticN + dynamicN),
      static: rs.length * staticN,
      dynamic: rs.length * dynamicN,
    };
  }, [feed, template, locale, uid]);

  const box = ZOOMS[zoomIdx].box;

  const onRenderAll = async () => {
    if (!template || !feed) return;
    const specs: RenderSpec[] = [];
    for (const r of feed.rows) {
      const merged = mergeValues(schemaDefaults, r.values);
      for (const v of template.variants) {
        specs.push({
          rowId: r.id,
          variantId: v.id,
          width: v.width,
          height: v.height,
          scene: v.scene,
          values: merged,
          crops: r.crops,
          formats: formatsForVariant(template.output.formatsByVariant, v),
        });
      }
    }
    setRenderMsg("");
    setProgress({ done: 0, total: specs.length });
    setRenderSpecs(specs);
  };

  const onRenderComplete = async (items: RenderUploadItem[]) => {
    setRenderSpecs(null);
    if (items.length === 0) {
      setRenderMsg("Nothing to render.");
      return;
    }
    await persistRenders.mutateAsync({ feedId, items });
    setRenderMsg(
      `Stored ${items.length} render${items.length === 1 ? "" : "s"}.`,
    );
  };

  const rendering = !!renderSpecs;

  if (isLoading || !feed) {
    return (
      <StudioLayout active="feeds">
        <div className="p-6 text-[13px] text-muted-foreground flex items-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin" /> Loading preview…
        </div>
      </StudioLayout>
    );
  }

  return (
    <StudioLayout
      active="feeds"
      actions={
        <>
          {renderMsg && (
            <span
              className="text-[11.5px] text-emerald-600"
              data-testid="preview-render-msg"
            >
              {renderMsg}
            </span>
          )}
          <Link
            href={`/studio/feeds/${feedId}/qa`}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))]"
            data-testid="button-open-qa"
          >
            <ShieldAlert className="w-3.5 h-3.5" /> Matrix QA
          </Link>
          <Link
            href={`/studio/feeds/${feedId}/review`}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))]"
            data-testid="button-open-review"
          >
            <ClipboardCheck className="w-3.5 h-3.5" /> Review &amp; ship
          </Link>
          <button
            type="button"
            onClick={onRenderAll}
            disabled={rendering || persistRenders.isPending}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:border-[hsl(var(--primary))] disabled:opacity-50"
            data-testid="button-render-all"
          >
            {rendering || persistRenders.isPending ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <ImagePlus className="w-3.5 h-3.5" />
            )}
            {rendering
              ? `Rendering ${progress.done}/${progress.total}`
              : "Render & store all"}
          </button>
          <a
            href={feedExportUrl(feedId)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 ${
              renders.length === 0 ? "pointer-events-none opacity-50" : ""
            }`}
            data-testid="button-export-zip"
          >
            <Download className="w-3.5 h-3.5" /> Export ZIP
          </a>
        </>
      }
    >
      <div className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Link
            href={`/studio/feeds/${feedId}`}
            className="inline-flex items-center gap-1 text-[12.5px] text-muted-foreground hover:text-foreground"
            data-testid="link-back-feed"
          >
            <ArrowLeft className="w-4 h-4" /> {feed.name}
          </Link>
        </div>

        {/* Filter bar */}
        <div className="flex flex-wrap items-center gap-3 mb-5 pb-4 border-b border-card-border">
          <div className="inline-flex border border-card-border bg-card">
            {(
              [
                { key: "all", label: "All" },
                { key: "static", label: "Static" },
                { key: "dynamic", label: "Dynamic" },
              ] as { key: TypeFilter; label: string }[]
            ).map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => setTypeFilter(t.key)}
                className={`px-3 py-1.5 text-[12px] border-r border-card-border last:border-r-0 ${
                  typeFilter === t.key
                    ? "bg-[hsl(var(--primary))] text-white"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/40"
                }`}
                data-testid={`filter-type-${t.key}`}
              >
                {t.label}{" "}
                <span className="tabular-nums opacity-80">
                  {counts[t.key]}
                </span>
              </button>
            ))}
          </div>

          <label className="inline-flex items-center gap-1.5 text-[12px] text-muted-foreground">
            Locale
            <select
              value={locale}
              onChange={(e) => setLocale(e.target.value)}
              className="border border-card-border bg-background px-2 py-1 text-[12px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
              data-testid="filter-locale"
            >
              <option value="all">All</option>
              {locales.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </label>

          <label className="inline-flex items-center gap-1.5 text-[12px] text-muted-foreground">
            Creative
            <select
              value={uid}
              onChange={(e) => setUid(e.target.value)}
              className="border border-card-border bg-background px-2 py-1 text-[12px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
              data-testid="filter-uid"
            >
              <option value="all">All</option>
              {(feed.rows ?? []).map((r) => (
                <option key={r.id} value={r.id}>
                  {r.uid || r.id}
                </option>
              ))}
            </select>
          </label>

          <div className="ml-auto inline-flex items-center gap-1.5 text-[12px] text-muted-foreground">
            <ZoomIn className="w-3.5 h-3.5" />
            <div className="inline-flex border border-card-border bg-card">
              {ZOOMS.map((z, i) => (
                <button
                  key={z.label}
                  type="button"
                  onClick={() => setZoomIdx(i)}
                  className={`px-2.5 py-1 text-[12px] border-r border-card-border last:border-r-0 ${
                    zoomIdx === i
                      ? "bg-[hsl(var(--primary))] text-white"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/40"
                  }`}
                  data-testid={`zoom-${z.label}`}
                >
                  {z.label}
                </button>
              ))}
            </div>
            {renders.length > 0 && (
              <span className="ml-2 tabular-nums">
                {renders.length} stored
              </span>
            )}
          </div>
        </div>

        {/* Preview wall */}
        {rows.length === 0 || variants.length === 0 ? (
          <div className="border border-dashed border-card-border bg-card p-10 text-center text-[13px] text-muted-foreground">
            Nothing matches the current filters.
          </div>
        ) : (
          <div className="space-y-7">
            {rows.map((r) => {
              const merged = mergeValues(schemaDefaults, r.values);
              return (
                <section key={r.id} data-testid={`preview-row-${r.id}`}>
                  <div className="flex items-center gap-2 mb-2.5">
                    <span className="text-[13px] font-medium text-foreground">
                      {r.uid || r.id}
                    </span>
                    {r.locale && (
                      <span className="text-[10.5px] uppercase tracking-wide text-muted-foreground border border-card-border px-1.5 py-0.5">
                        {r.locale}
                      </span>
                    )}
                    {r.tags.map((t) => (
                      <span
                        key={t}
                        className="text-[10.5px] text-muted-foreground bg-muted px-1.5 py-0.5"
                      >
                        {t}
                      </span>
                    ))}
                    <Link
                      href={`/studio/feeds/${feedId}/creative/${r.id}`}
                      className="ml-auto text-[11.5px] text-[hsl(var(--primary))] hover:underline"
                      data-testid={`preview-edit-${r.id}`}
                    >
                      Edit creative
                    </Link>
                  </div>
                  <div className="flex flex-wrap gap-4">
                    {variants.map((v) => {
                      const scale = Math.min(
                        box / v.width,
                        (box * 1.4) / v.height,
                        1,
                      );
                      return (
                        <div
                          key={v.id}
                          className="flex flex-col"
                          data-testid={`preview-cell-${r.id}-${v.id}`}
                        >
                          <div className="text-[10.5px] text-muted-foreground mb-1 flex items-center gap-1.5">
                            <span className="font-medium text-foreground/80">
                              {v.name}
                            </span>
                            <span className="tabular-nums">
                              {v.width}×{v.height}
                            </span>
                          </div>
                          <div
                            className="bg-muted border border-card-border flex items-center justify-center"
                            style={{
                              width: Math.round(v.width * scale),
                              height: Math.round(v.height * scale),
                            }}
                          >
                            <StudioKonva
                              scene={v.scene}
                              width={v.width}
                              height={v.height}
                              scale={scale}
                              values={merged}
                              assetsById={
                                assetsById as Record<string, StudioAsset>
                              }
                              crops={r.crops}
                              frameMs={
                                v.type === "dynamic"
                                  ? playMs %
                                    Math.max(1, sceneDurationMs(v.scene))
                                  : undefined
                              }
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </section>
              );
            })}
          </div>
        )}
      </div>

      {renderSpecs && (
        <StudioRenderQueue
          specs={renderSpecs}
          assetsById={assetsById as Record<string, StudioAsset>}
          onComplete={onRenderComplete}
          onProgress={(done, total) => setProgress({ done, total })}
        />
      )}
    </StudioLayout>
  );
}
