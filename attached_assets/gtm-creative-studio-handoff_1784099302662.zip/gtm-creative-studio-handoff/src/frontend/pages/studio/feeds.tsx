/**
 * Creative Studio — Feeds overview. Lists every creative feed (name, source
 * template, row count, last update) linking into the spreadsheet grid, and lets
 * the user spin up a new feed against a template or delete an existing one.
 */
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Rows3, Plus, Trash2, X, ArrowRight, LayoutTemplate } from "lucide-react";
import { StudioLayout } from "@/components/studio/StudioLayout";
import { StudioAgentPanel } from "@/components/studio/StudioAgentPanel";
import {
  useFeeds,
  useTemplates,
  useCreateFeed,
  useDeleteFeed,
} from "@/lib/studio-api";

function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  testId,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  testId?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      data-testid={testId}
    >
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-md border border-card-border bg-card shadow-lg">
        <div className="flex items-center justify-between border-b border-card-border px-4 py-3">
          <h3 className="text-[14px] font-semibold text-foreground">{title}</h3>
          <button
            type="button"
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-modal-close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4">{children}</div>
        {footer && (
          <div className="flex justify-end gap-2 border-t border-card-border px-4 py-3">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

function fmtDate(ms: number): string {
  try {
    return new Date(ms).toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  } catch {
    return "";
  }
}

export default function FeedsPage() {
  const { data: feeds = [], isLoading } = useFeeds();
  const { data: templates = [] } = useTemplates();
  const createFeed = useCreateFeed();
  const deleteFeed = useDeleteFeed();
  const [, navigate] = useLocation();

  const templatesById = useMemo(
    () => Object.fromEntries(templates.map((t) => [t.id, t])),
    [templates],
  );

  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState("");
  const [templateId, setTemplateId] = useState("");

  const openCreate = () => {
    setName("");
    setTemplateId(templates[0]?.id ?? "");
    setCreateOpen(true);
  };

  const submitCreate = async () => {
    const trimmed = name.trim();
    if (!trimmed || !templateId) return;
    const created = await createFeed.mutateAsync({ templateId, name: trimmed });
    setCreateOpen(false);
    navigate(`/studio/feeds/${created.id}`);
  };

  const removeFeed = (id: string, label: string) => {
    if (!window.confirm(`Delete feed “${label}”? This cannot be undone.`)) return;
    deleteFeed.mutate(id);
  };

  return (
    <StudioLayout
      active="feeds"
      actions={
        <button
          type="button"
          onClick={openCreate}
          disabled={templates.length === 0}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
          data-testid="button-new-feed"
        >
          <Plus className="w-3.5 h-3.5" /> New feed
        </button>
      }
    >
      <div className="p-6">
        {isLoading ? (
          <div className="text-[13px] text-muted-foreground">Loading feeds…</div>
        ) : feeds.length === 0 ? (
          <div className="border border-dashed border-card-border bg-card p-10 text-center">
            <div className="w-10 h-10 mx-auto bg-muted flex items-center justify-center text-muted-foreground mb-3">
              <Rows3 className="w-5 h-5" />
            </div>
            <div className="text-[13px] font-medium text-foreground">
              No creative feeds yet
            </div>
            <p className="text-[12px] text-muted-foreground mt-1">
              {templates.length === 0
                ? "Create a template first, then build a feed of creatives against it."
                : "A feed is a spreadsheet of creatives (rows) bound to a template."}
            </p>
            {templates.length > 0 && (
              <button
                type="button"
                onClick={openCreate}
                className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95"
                data-testid="button-new-feed-empty"
              >
                <Plus className="w-3.5 h-3.5" /> New feed
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3">
            {feeds.map((f) => {
              const tpl = templatesById[f.templateId];
              return (
                <div
                  key={f.id}
                  className="group relative border border-card-border bg-card hover:border-[hsl(var(--primary))] transition-colors"
                  data-testid={`card-feed-${f.id}`}
                >
                  <Link
                    href={`/studio/feeds/${f.id}`}
                    className="block p-4"
                    data-testid={`link-feed-${f.id}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 bg-muted flex items-center justify-center text-muted-foreground group-hover:text-[hsl(var(--primary))] flex-shrink-0">
                        <Rows3 className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 pr-6">
                        <div className="text-[13.5px] font-medium text-foreground truncate">
                          {f.name}
                        </div>
                        <div className="text-[11.5px] text-muted-foreground truncate mt-0.5 inline-flex items-center gap-1">
                          <LayoutTemplate className="w-3 h-3" />
                          {tpl ? tpl.name : "Unknown template"}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 mt-3 text-[11.5px] text-muted-foreground">
                      <span className="tabular-nums">
                        {f.rows.length}{" "}
                        {f.rows.length === 1 ? "creative" : "creatives"}
                      </span>
                      <span>·</span>
                      <span>Updated {fmtDate(f.updatedAt)}</span>
                      <ArrowRight className="w-3.5 h-3.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </Link>
                  <button
                    type="button"
                    onClick={() => removeFeed(f.id, f.name)}
                    className="absolute top-2.5 right-2.5 w-7 h-7 flex items-center justify-center text-muted-foreground hover:text-red-600 hover:bg-red-50"
                    title="Delete feed"
                    data-testid={`button-delete-feed-${f.id}`}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="New feed"
        testId="modal-new-feed"
        footer={
          <>
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="px-3 py-1.5 text-[12.5px] border border-card-border bg-card text-foreground hover:bg-muted/40"
              data-testid="button-cancel-create-feed"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={submitCreate}
              disabled={!name.trim() || !templateId || createFeed.isPending}
              className="px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
              data-testid="button-confirm-create-feed"
            >
              {createFeed.isPending ? "Creating…" : "Create"}
            </button>
          </>
        }
      >
        <div className="space-y-3">
          <p className="text-[12px] text-muted-foreground">
            Name your feed and pick a template. We'll create one starter creative
            you can duplicate and customize per account.
          </p>
          <div>
            <label className="block text-[12px] font-medium text-foreground mb-1">
              Name
            </label>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") submitCreate();
              }}
              placeholder="e.g. Q3 ABM Cluster Feed"
              className="w-full border border-card-border bg-background px-2.5 py-1.5 text-[13px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
              data-testid="input-feed-name"
            />
          </div>
          <div>
            <label className="block text-[12px] font-medium text-foreground mb-1">
              Template
            </label>
            <select
              value={templateId}
              onChange={(e) => setTemplateId(e.target.value)}
              className="w-full border border-card-border bg-background px-2.5 py-1.5 text-[13px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
              data-testid="select-feed-template"
            >
              {templates.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </Modal>

      <StudioAgentPanel scopeLabel="Feeds" />
    </StudioLayout>
  );
}
