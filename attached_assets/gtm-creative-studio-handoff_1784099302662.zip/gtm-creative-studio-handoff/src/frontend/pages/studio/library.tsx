/**
 * Creative Library — top-level Studio destination that gathers every persisted
 * render across all feeds into a single gallery. Real bitmaps are served from
 * the same-origin render store; users can filter by feed/format and download
 * any produced creative or export a feed's full set as a ZIP.
 */
import { useMemo, useState } from "react";
import { Link } from "wouter";
import {
  GalleryHorizontalEnd,
  Download,
  ExternalLink,
  Search,
  ImageOff,
  FileCode2,
} from "lucide-react";
import { StudioLayout } from "@/components/studio/StudioLayout";
import { useRenders, useFeeds } from "@/lib/studio-api";
import { renderFileUrl, feedExportUrl } from "@/components/studio/scene";

const FORMATS = ["png", "jpg", "webp", "gif", "html5"] as const;

export default function CreativeLibraryPage() {
  const { data: renders = [], isLoading } = useRenders();
  const { data: feeds = [] } = useFeeds();

  const feedNameById = useMemo(
    () => Object.fromEntries(feeds.map((f) => [f.id, f.name])),
    [feeds],
  );

  const [feedFilter, setFeedFilter] = useState<string>("all");
  const [formatFilter, setFormatFilter] = useState<string>("all");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return [...renders]
      .sort((a, b) => b.createdAt - a.createdAt)
      .filter((r) => (feedFilter === "all" ? true : r.feedId === feedFilter))
      .filter((r) =>
        formatFilter === "all" ? true : r.format === formatFilter,
      )
      .filter((r) => {
        if (!q) return true;
        const name = (feedNameById[r.feedId] ?? "").toLowerCase();
        return (
          r.variantId.toLowerCase().includes(q) ||
          r.rowId.toLowerCase().includes(q) ||
          name.includes(q)
        );
      });
  }, [renders, feedFilter, formatFilter, query, feedNameById]);

  // Feeds that actually have renders, for the export-zip shortcuts.
  const feedsWithRenders = useMemo(() => {
    const ids = new Set(renders.map((r) => r.feedId));
    return feeds.filter((f) => ids.has(f.id));
  }, [renders, feeds]);

  return (
    <StudioLayout active="library">
      <div className="p-6 space-y-5">
        {/* Heading */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-[15px] font-semibold text-foreground inline-flex items-center gap-2">
              <GalleryHorizontalEnd className="w-4 h-4 text-[hsl(var(--primary))]" />
              Creative Library
            </h2>
            <p className="text-[12.5px] text-muted-foreground mt-1">
              Every produced creative across all feeds. {renders.length}{" "}
              {renders.length === 1 ? "render" : "renders"} stored.
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-muted-foreground absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search variant, row or feed…"
              className="w-[260px] border border-card-border bg-background pl-8 pr-2.5 py-1.5 text-[12.5px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
              data-testid="input-library-search"
            />
          </div>

          <select
            value={feedFilter}
            onChange={(e) => setFeedFilter(e.target.value)}
            className="border border-card-border bg-background px-2.5 py-1.5 text-[12.5px] text-foreground focus:outline-none focus:border-[hsl(var(--primary))]"
            data-testid="select-library-feed"
          >
            <option value="all">All feeds</option>
            {feeds.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>

          <div className="inline-flex border border-card-border">
            <button
              type="button"
              onClick={() => setFormatFilter("all")}
              className={
                "px-2.5 py-1.5 text-[12px] " +
                (formatFilter === "all"
                  ? "bg-[hsl(var(--primary))] text-white"
                  : "bg-card text-muted-foreground hover:text-foreground")
              }
              data-testid="filter-format-all"
            >
              All
            </button>
            {FORMATS.map((fmt) => (
              <button
                key={fmt}
                type="button"
                onClick={() => setFormatFilter(fmt)}
                className={
                  "px-2.5 py-1.5 text-[12px] border-l border-card-border " +
                  (formatFilter === fmt
                    ? "bg-[hsl(var(--primary))] text-white"
                    : "bg-card text-muted-foreground hover:text-foreground")
                }
                data-testid={`filter-format-${fmt}`}
              >
                {fmt.toUpperCase()}
              </button>
            ))}
          </div>

          {feedsWithRenders.length > 0 && (
            <div className="ml-auto flex items-center gap-1.5">
              <span className="text-[11px] text-muted-foreground">
                Export ZIP:
              </span>
              {feedsWithRenders.map((f) => (
                <a
                  key={f.id}
                  href={feedExportUrl(f.id)}
                  className="inline-flex items-center gap-1 px-2 py-1 text-[11.5px] border border-card-border bg-card text-foreground hover:bg-muted/40"
                  data-testid={`button-export-feed-${f.id}`}
                >
                  <Download className="w-3 h-3" />
                  {f.name}
                </a>
              ))}
            </div>
          )}
        </div>

        {/* Body */}
        {isLoading ? (
          <div className="border border-card-border bg-card p-10 text-center text-[13px] text-muted-foreground">
            Loading renders…
          </div>
        ) : renders.length === 0 ? (
          <div
            className="border border-dashed border-card-border bg-card p-12 text-center"
            data-testid="library-empty"
          >
            <ImageOff className="w-7 h-7 text-muted-foreground mx-auto mb-2.5" />
            <p className="text-[13px] text-foreground font-medium">
              No creatives produced yet
            </p>
            <p className="text-[12px] text-muted-foreground mt-1">
              Open a feed and use{" "}
              <span className="text-foreground">Render &amp; store</span> to
              populate the library.
            </p>
            <Link
              href="/studio/feeds"
              className="inline-flex items-center gap-1.5 mt-4 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95"
              data-testid="link-go-feeds"
            >
              Go to feeds
            </Link>
          </div>
        ) : filtered.length === 0 ? (
          <div className="border border-dashed border-card-border bg-card p-10 text-center text-[13px] text-muted-foreground">
            No renders match the current filters.
          </div>
        ) : (
          <div
            className="grid gap-3 [grid-template-columns:repeat(auto-fill,minmax(200px,1fr))]"
            data-testid="library-grid"
          >
            {filtered.map((r) => (
              <div
                key={r.id}
                className="border border-card-border bg-card flex flex-col"
                data-testid={`library-render-${r.id}`}
              >
                <div className="h-[150px] bg-muted flex items-center justify-center overflow-hidden border-b border-card-border relative">
                  {r.format === "html5" ? (
                    // Self-contained HTML5 replay bundles are served as downloads
                    // (never executed inline) so they can't be previewed here;
                    // show a typed placeholder with the download affordance below.
                    <div className="flex flex-col items-center justify-center gap-1.5 text-muted-foreground">
                      <FileCode2 className="w-8 h-8" />
                      <span className="text-[10.5px]">
                        HTML5 replay — download to view
                      </span>
                    </div>
                  ) : (
                    <img
                      src={renderFileUrl(r.fileName)}
                      alt={`${r.variantId} ${r.format}`}
                      crossOrigin="anonymous"
                      className="max-w-full max-h-full object-contain"
                    />
                  )}
                </div>
                <div className="p-2.5 flex flex-col gap-1.5 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[10px] uppercase tracking-wide bg-[hsl(var(--primary))] text-white px-1.5 py-0.5">
                      {r.format}
                    </span>
                    <span className="text-[10px] tabular-nums border border-card-border px-1.5 py-0.5 text-muted-foreground">
                      {r.width}×{r.height}
                    </span>
                  </div>
                  <p
                    className="text-[12px] text-foreground truncate"
                    title={feedNameById[r.feedId] ?? r.feedId}
                  >
                    {feedNameById[r.feedId] ?? "Unknown feed"}
                  </p>
                  <p className="text-[10.5px] text-muted-foreground truncate">
                    {new Date(r.createdAt).toLocaleString()}
                  </p>
                  <div className="flex items-center gap-1.5 mt-auto pt-1">
                    <a
                      href={renderFileUrl(r.fileName)}
                      download={r.fileName}
                      className="flex-1 inline-flex items-center justify-center gap-1 px-2 py-1 text-[11.5px] border border-card-border bg-card text-foreground hover:bg-muted/40"
                      data-testid={`button-download-render-${r.id}`}
                    >
                      <Download className="w-3 h-3" /> Download
                    </a>
                    <Link
                      href={`/studio/feeds/${r.feedId}/preview`}
                      className="inline-flex items-center justify-center w-7 h-7 border border-card-border bg-card text-muted-foreground hover:text-foreground hover:bg-muted/40"
                      title="Open feed preview"
                      data-testid={`link-render-feed-${r.id}`}
                    >
                      <ExternalLink className="w-3 h-3" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </StudioLayout>
  );
}
