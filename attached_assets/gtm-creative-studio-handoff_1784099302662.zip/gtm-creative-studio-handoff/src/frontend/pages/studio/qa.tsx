/**
 * Creative Studio — Matrix QA. Runs brand / competitor / compliance checks
 * across every creative (feed row) × dimension (template variant) via the
 * `/studio/agent/matrix-qa` endpoint and groups the returned findings by
 * creative (rowUid), surfacing severity, rule, snippet and guidance plus a
 * per-run summary that deep-links each skill call to /observability.
 */
import { useMemo, useState } from "react";
import { useParams, Link } from "wouter";
import {
  ArrowLeft,
  CheckCircle2,
  Loader2,
  ShieldAlert,
  ShieldCheck,
} from "lucide-react";
import { StudioLayout } from "@/components/studio/StudioLayout";
import {
  useFeed,
  useTemplate,
  useMatrixQa,
  type StudioQaCheck,
  type StudioQaFinding,
} from "@/lib/studio-api";

const CHECKS: { key: StudioQaCheck; label: string }[] = [
  { key: "brand", label: "Brand" },
  { key: "competitor", label: "Competitor" },
  { key: "compliance", label: "Compliance" },
];

const CHECK_LABEL: Record<StudioQaCheck, string> = {
  brand: "Brand",
  competitor: "Competitor",
  compliance: "Compliance",
};

// Severity strings drift across skills (warn/low/medium/high/error/info…), so
// classify by keyword into a small set of visual buckets instead of an enum.
function severityTone(severity: string): {
  rank: number;
  cls: string;
} {
  const s = severity.toLowerCase();
  if (/(crit|high|error|fail|block)/.test(s))
    return { rank: 3, cls: "bg-red-50 text-red-700 border-red-200" };
  if (/(med|warn|moderate)/.test(s))
    return { rank: 2, cls: "bg-amber-50 text-amber-700 border-amber-200" };
  if (/(low|info|minor|pass|ok)/.test(s))
    return { rank: 1, cls: "bg-sky-50 text-sky-700 border-sky-200" };
  return { rank: 2, cls: "bg-muted text-muted-foreground border-card-border" };
}

function SeverityBadge({ severity }: { severity: string }) {
  return (
    <span
      className={`inline-flex items-center px-1.5 py-0.5 text-[10px] uppercase tracking-wide border ${
        severityTone(severity).cls
      }`}
    >
      {severity}
    </span>
  );
}

export default function StudioQaPage() {
  const params = useParams();
  const feedId = params.id as string;
  const { data: feed } = useFeed(feedId);
  const { data: template } = useTemplate(feed?.templateId, {
    enabled: !!feed?.templateId,
  });
  const matrixQa = useMatrixQa();

  const [selected, setSelected] = useState<Record<StudioQaCheck, boolean>>({
    brand: true,
    competitor: true,
    compliance: true,
  });

  const result = matrixQa.data;
  const findings = result?.findings ?? [];
  const summary = result?.summary;
  const skillCallIds = result?.skillCallIds ?? summary?.skillCallIds ?? [];

  const toggle = (key: StudioQaCheck) =>
    setSelected((s) => ({ ...s, [key]: !s[key] }));

  const activeChecks = useMemo(
    () => CHECKS.filter((c) => selected[c.key]).map((c) => c.key),
    [selected],
  );

  // Group findings by creative (rowUid), severity-sorted within each group.
  const grouped = useMemo(() => {
    const m = new Map<string, StudioQaFinding[]>();
    for (const f of findings) {
      const arr = m.get(f.rowUid) ?? [];
      arr.push(f);
      m.set(f.rowUid, arr);
    }
    for (const arr of m.values()) {
      arr.sort(
        (a, b) => severityTone(b.severity).rank - severityTone(a.severity).rank,
      );
    }
    return Array.from(m.entries()).sort((a, b) =>
      a[0].localeCompare(b[0]),
    );
  }, [findings]);

  const runQa = () => {
    if (activeChecks.length === 0) return;
    matrixQa.mutate({ feedId, checks: activeChecks });
  };

  const variantCount = template?.variants.length ?? 0;
  const rowCount = feed?.rows.length ?? 0;

  return (
    <StudioLayout
      active="feeds"
      actions={
        <button
          type="button"
          onClick={runQa}
          disabled={matrixQa.isPending || activeChecks.length === 0}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[12.5px] bg-[hsl(var(--primary))] text-white hover:brightness-95 disabled:opacity-50"
          data-testid="button-run-qa"
        >
          {matrixQa.isPending ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <ShieldAlert className="w-3.5 h-3.5" />
          )}
          {matrixQa.isPending ? "Running QA…" : "Run QA"}
        </button>
      }
    >
      <div className="p-6 max-w-[1100px] space-y-6">
        <div className="flex items-center gap-2">
          <Link
            href={`/studio/feeds/${feedId}/preview`}
            className="inline-flex items-center gap-1 text-[12.5px] text-muted-foreground hover:text-foreground"
            data-testid="link-back-preview"
          >
            <ArrowLeft className="w-4 h-4" /> {feed?.name ?? "Feed"}
          </Link>
        </div>

        <div>
          <h1 className="text-[15px] font-semibold text-foreground">
            Matrix QA
          </h1>
          <p className="text-[12.5px] text-muted-foreground mt-1">
            Scan every creative across brand, competitor and compliance checks.
            {rowCount > 0 && variantCount > 0 ? (
              <>
                {" "}
                <span className="tabular-nums">{rowCount}</span> creative
                {rowCount === 1 ? "" : "s"} ×{" "}
                <span className="tabular-nums">{variantCount}</span> dimension
                {variantCount === 1 ? "" : "s"}.
              </>
            ) : null}
          </p>
        </div>

        {/* Check-type toggles */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[12px] text-muted-foreground mr-1">Checks</span>
          {CHECKS.map((c) => (
            <button
              key={c.key}
              type="button"
              onClick={() => toggle(c.key)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-[12px] border ${
                selected[c.key]
                  ? "border-[hsl(var(--primary))] bg-[hsl(var(--primary))]/10 text-foreground"
                  : "border-card-border bg-card text-muted-foreground hover:text-foreground"
              }`}
              data-testid={`toggle-check-${c.key}`}
            >
              {selected[c.key] ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-[hsl(var(--primary))]" />
              ) : (
                <ShieldAlert className="w-3.5 h-3.5" />
              )}
              {c.label}
            </button>
          ))}
        </div>

        {/* Per-run summary */}
        {summary && (
          <section
            className="border border-card-border bg-card p-4"
            data-testid="qa-summary"
          >
            <div className="flex flex-wrap items-center gap-x-6 gap-y-1.5 text-[12.5px]">
              <span className="inline-flex items-center gap-1.5 text-foreground">
                {summary.totalFindings === 0 ? (
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                ) : (
                  <ShieldAlert className="w-4 h-4 text-amber-600" />
                )}
                <span className="font-semibold tabular-nums">
                  {summary.totalFindings}
                </span>{" "}
                finding{summary.totalFindings === 1 ? "" : "s"}
              </span>
              {Object.entries(summary.bySeverity).map(([sev, n]) => (
                <span key={sev} className="inline-flex items-center gap-1.5">
                  <SeverityBadge severity={sev} />
                  <span className="tabular-nums text-foreground">{n}</span>
                </span>
              ))}
              <span className="text-muted-foreground">
                Ran {new Date(summary.ranAt).toLocaleString()}
              </span>
            </div>
            {skillCallIds.length > 0 && (
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-3 pt-3 border-t border-card-border text-[11.5px]">
                <span className="text-muted-foreground">Traces</span>
                {skillCallIds.map((id, i) => (
                  <Link
                    key={id}
                    href={`/observability?q=${encodeURIComponent(id)}`}
                    className="underline text-muted-foreground hover:text-foreground"
                    data-testid={`link-trace-${i}`}
                  >
                    {CHECKS[i]?.label ?? `Check ${i + 1}`}
                  </Link>
                ))}
              </div>
            )}
          </section>
        )}

        {matrixQa.isError && (
          <div
            className="border border-red-200 bg-red-50 p-3 text-[12.5px] text-red-700"
            data-testid="qa-error"
          >
            QA run failed — try again.
          </div>
        )}

        {/* Findings grouped by creative */}
        {!summary && !matrixQa.isPending && (
          <div
            className="border border-dashed border-card-border bg-card p-10 text-center text-[13px] text-muted-foreground"
            data-testid="qa-empty"
          >
            Run QA to scan this feed across the selected checks.
          </div>
        )}

        {summary && findings.length === 0 && (
          <div
            className="border border-emerald-200 bg-emerald-50 p-8 text-center text-[13px] text-emerald-700 flex flex-col items-center gap-2"
            data-testid="qa-clean"
          >
            <ShieldCheck className="w-7 h-7" />
            No issues found across the selected checks.
          </div>
        )}

        {grouped.length > 0 && (
          <div className="space-y-5">
            {grouped.map(([rowUid, rowFindings]) => (
              <section
                key={rowUid}
                className="border border-card-border bg-card"
                data-testid={`qa-group-${rowUid}`}
              >
                <div className="flex items-center justify-between px-4 py-2.5 border-b border-card-border">
                  <span className="text-[13px] font-medium text-foreground">
                    {rowUid}
                  </span>
                  <span className="text-[11px] text-muted-foreground tabular-nums">
                    {rowFindings.length} finding
                    {rowFindings.length === 1 ? "" : "s"}
                  </span>
                </div>
                <ul className="divide-y divide-card-border">
                  {rowFindings.map((f, i) => (
                    <li
                      key={`${f.check}-${f.fieldId ?? "all"}-${i}`}
                      className="px-4 py-3"
                      data-testid={`qa-finding-${rowUid}-${i}`}
                    >
                      <div className="flex flex-wrap items-center gap-2 mb-1.5">
                        <SeverityBadge severity={f.severity} />
                        <span className="text-[10px] uppercase tracking-wide text-muted-foreground border border-card-border px-1.5 py-0.5">
                          {CHECK_LABEL[f.check]}
                        </span>
                        {f.fieldId && (
                          <span className="text-[10.5px] text-muted-foreground bg-muted px-1.5 py-0.5">
                            {f.fieldId}
                          </span>
                        )}
                        {f.rule && (
                          <span className="text-[12.5px] font-medium text-foreground">
                            {f.rule}
                          </span>
                        )}
                      </div>
                      {f.snippet && (
                        <p className="text-[12px] text-muted-foreground border-l-2 border-card-border pl-2.5 mb-1.5">
                          “{f.snippet}”
                        </p>
                      )}
                      {f.guidance && (
                        <p className="text-[12px] text-foreground/80">
                          {f.guidance}
                        </p>
                      )}
                    </li>
                  ))}
                </ul>
              </section>
            ))}
          </div>
        )}
      </div>
    </StudioLayout>
  );
}
