# GTM Creative Studio — Rebuild Handoff Package

This package contains everything a build agent needs to recreate the GTM Creative
Studio experience (a dynamic-creative production suite: asset uploads, multi-size
templates, a full visual canvas editor, data feeds, per-creative editing with
dynamic crop, QA, review/approval, and multi-format export) inside another
application.

## Contents

| Path | What it is |
|---|---|
| `docs/REBUILD_SPEC.md` | The master specification: product surface, architecture, data model, algorithms, pitfalls, and a step-by-step build plan. **Start here.** |
| `docs/LIBRARIES.md` | Every open-source library used, with versions and the reason each was chosen (including the ones we evaluated and rejected). |
| `docs/API_SURFACE.md` | The complete backend HTTP API the frontend expects. |
| `src/frontend/components/studio/` | The real, working source of the canvas engine, crop math (+ unit tests), scene helpers, type model, layout chrome, media picker, render queue, and agent panel. |
| `src/frontend/pages/studio/` | The real source of all 12 studio pages (dashboard, assets, templates, template detail, full-screen editor, feeds, feed detail, per-creative editor, QA, review, preview, creative library). |
| `src/backend/` | The real server source: the studio route file (all endpoints) and the file-based store (types + persistence + seed logic), plus the scene-doctrine test. |

## How to use this package

Give the entire folder to the receiving build agent with an instruction like:

> "Rebuild this creative studio inside my app. Read `docs/REBUILD_SPEC.md` first,
> install the libraries in `docs/LIBRARIES.md`, implement the API in
> `docs/API_SURFACE.md`, and port the source in `src/` — adapting imports,
> routing, and styling to the host app's conventions."

The source files are written for a React + Vite + Tailwind + wouter +
TanStack Query app with an Express backend. They are directly portable; the
spec calls out every host-app assumption that needs adapting (routing library,
path aliases, toast system, styling tokens, storage layer).
