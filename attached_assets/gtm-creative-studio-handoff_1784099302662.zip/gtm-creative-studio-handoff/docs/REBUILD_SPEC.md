# GTM Creative Studio — Master Rebuild Specification

A complete blueprint for rebuilding the studio in another application. Read this
top to bottom before writing code. The `src/` folder contains the real, working
source — port it rather than reinventing it.

---

## 1. What the product is

A **dynamic creative production suite** for marketing teams. One template
defines a design across many ad sizes; a **feed** of data rows (headline, CTA,
images, locale, tags) multiplies that template into dozens of finished
creatives; editors fine-tune any creative visually per size; QA and review
gates approve the pack; export produces PNG/JPG/WebP stills, animated GIFs,
and zipped HTML5 bundles.

The mental model (familiar to users of dynamic-creative tools):

```
Assets (uploads)  ─┐
                   ├─►  Template (sizes × layered scenes, bindable fields)
Feed (data rows) ──┘             │
                                 ▼
                    Creative matrix (rows × sizes)
                                 │
              per-creative visual editing (crop, styles, copy)
                                 ▼
                       QA → Review → Renders → Export/Handoff
```

## 2. Top-level surface (tabs & routes)

Studio chrome (`StudioLayout.tsx`) is a browser-tab style bar with five tabs:

| Tab | Route | Page file | What it does |
|---|---|---|---|
| Dashboard | `/studio` | `dashboard.tsx` | Counts, recent activity, quick links |
| Asset Library | `/studio/assets` | `assets.tsx` | Upload (drag-drop, multi), tag, search, delete images/packshots |
| Templates | `/studio/templates` | `templates.tsx` | Template cards; create/delete |
| Feeds | `/studio/feeds` | `feeds.tsx` | Feed list; create feed bound to a template |
| Creative Library | `/studio/library` | `library.tsx` | Browse persisted renders across feeds |

Deeper routes (all under the same chrome except the full-screen editor):

| Route | Page file | What it does |
|---|---|---|
| `/studio/templates/:id` | `template-detail.tsx` | Template hub: schema-field designer (media/rich_text fields, defaults, allowed formats), variant/size manager (add, duplicate as exact clone, delete), output-format settings |
| `/studio/editor/:templateId/:variantId` | `editor.tsx` | **Full-screen canvas editor** (bypasses chrome). Left: layer stack (reorder, lock, hide). Center: Konva stage — drag/resize/rotate layers, inline text editing, image fit & filters (blur/sharpen), per-layer cover-crop framing, animation clips + timeline scrubber for dynamic variants. Right: properties inspector |
| `/studio/feeds/:id` | `feed-detail.tsx` | Spreadsheet-style grid: rows × schema fields; media pickers for image fields; per-row tags/locale; add/duplicate/delete rows; per-row jump into the creative editor; agent autofill |
| `/studio/feeds/:id/creative/:rowId` | `creative-editor.tsx` | **Per-creative multi-size editor**: every size previewed live at once; copy edit panel; image panel with style overrides (opacity, corner radius, blur); **Dynamic Crop** (see §5); size show/hide toggles |
| `/studio/feeds/:id/qa` | `qa.tsx` | Agent QA matrix — findings per row × size with severity |
| `/studio/feeds/:id/review` | `review.tsx` | Approval workspace — approve/request changes per creative, pack-level approval, handoff record |
| `/studio/feeds/:id/preview` | `feed-preview.tsx` | Client-side render queue: captures every row × size × format, persists to the server, batch zip download |

## 3. The scene/data model (the single most important thing)

Defined in `src/frontend/components/studio/types.ts` (client) and mirrored in
`src/backend/studio-store.ts` (server). **They are hand-mirrored by design —
any change must be made in both files.** This surface deliberately skips
API-codegen so the layer model can evolve fast.

- `StudioTemplate` → `schemaFields: StudioSchemaField[]` + `variants: StudioVariant[]` + output settings.
- `StudioVariant` = one size: `{ id, name, type: "static"|"dynamic", width, height, scene }`.
- `StudioScene` = `{ version, bg, layers: StudioLayer[], timeline? }`.
- `StudioLayer` = `text | image | rect`, each with `x,y,w,h, rotation, opacity, visible, locked, animation?`.
  - Text: font family/size/weight, line height, letter spacing, align/valign, color, uppercase, `fieldId` binding.
  - Image: `imageKind: "image"|"logo"|"blur"`, `assetId` or `fieldId` binding, `fit: cover|contain|stretch`, cornerRadius, blur, sharpen, and a template-level `crop` (per-LAYER focal framing).
  - Rect: fill, vertical gradient stops, cornerRadius, stroke.
- **Field binding**: a layer with `fieldId` pulls its content from the feed row's `values[fieldId]` (text for rich_text fields, an asset id for media fields). This is what turns one template into N creatives.
- **Animation**: dynamic variants carry `timeline {durationMs, fps, captureMs}` and per-layer `clips` (`fadeIn/fadeOut/slideIn/slideOut/popIn/pulse` with easing). Static capture samples the scene at `captureMs`.
- `StudioCreativeRow` = `{ id, uid, locale, tags, values, crops?, styleOverrides? }`.

## 4. The rendering engine (Konva, one component everywhere)

`StudioKonva.tsx` is a single component that renders a scene in four contexts:
the canvas editor (interactive), template/feed thumbnails, the per-creative
multi-size grid, and export capture. Rules that made this work:

- One `Stage` scaled with `scaleX/scaleY`; layer coordinates are always in
  design pixels — never pre-scale geometry.
- `interactive` prop gates ALL editor affordances: selection, layer dragging,
  and `listening` on every scene shape (`listening={interactive}`), so preview
  grids are inert and cheap.
- Cover-fit images use Konva's `crop` prop, computed by `coverCrop()` from
  `cropMath.ts` — the same math at edit, preview, and export time (single
  render path = WYSIWYG guarantee).
- Blur is a custom Gaussian filter cached at reduced pixel ratio for
  performance; sharpen is an unsharp-mask filter; both compose.
- Fonts must be loaded (FontFace API) before first paint or text measures
  wrong; the component tracks `fontsReady`.
- Export capture = render the stage at 1:1 scale, `stage.toDataURL()` per
  format; animated variants step the timeline per frame and encode with
  `gifenc`; HTML5 bundles are zipped client-side with `fflate`.
- Preview grids lazy-mount each size with an `IntersectionObserver`
  (600px margin) so 14 sizes don't all paint at once; each cell is `memo`ized.

## 5. The Dynamic Crop system (crop math + UX)

`cropMath.ts` (with unit tests in `cropMath.test.ts`) implements focal
cover-cropping:

- `StudioCropOverride = { x, y ∈ [-0.5, 0.5], scale ≥ 1 }` — a normalized focal
  offset from center plus zoom. Resolution-independent: the same override
  applies across every size.
- `coverGeometry()` computes the cover window for a source image in a target
  box; at `scale 1` exactly one axis has pan range (the cropped axis) — the
  other is locked by the cover constraint. Zoom > 1 opens both axes.
- `panCrop()` converts a drag delta in design px into a focal-offset delta;
  `zoomCrop()` clamps zoom.
- **Crop keys**: base key = `fieldId` ("One frame" applies across all sizes);
  per-size key = `${variantId}:${fieldId}`. Resolution order: composite key
  first, then base. The per-creative field crop wins over the template's
  per-layer crop.
- The overlay (`CropOverlay` in `StudioKonva.tsx`) draws a focal frame with
  rule-of-thirds lines + corner handles; drag pans (the draggable rect resets
  its own position each move and writes the crop through React state — the
  image moves, the frame stays), wheel zooms proportionally.

**Known UX defect to fix when rebuilding (important):** templates that bind the
same media field to BOTH a full-bleed blurred backdrop layer (`imageKind:
"blur"`) and a small sharp foreground card exclude the blur layer from the
crop overlay — so the only draggable surface is the small card, and users
report "I can't drag the image." Fix in the rebuild: keep the visual focal
frame on the sharp layer, but make the **entire frame** a transparent drag
surface (a full-canvas listening rect using the same `panCrop` handlers,
anchored to the focal layer's geometry). Wheel-zoom should work full-frame too.

## 6. Backend & persistence

- Express 5 router (`studio.routes.ts`) + a thin store module
  (`studio-store.ts`) that persists JSON files (templates, feeds, asset index,
  renders, reviews) plus binary uploads/renders on disk. First studio request
  runs a seed/upgrade hook that installs a demo template + assets.
- Uploads: `multer` memory storage → probe with `sharp` → write file + index
  entry. Files served with long-cache headers.
- Swap the store for a database freely — the route layer only talks to store
  functions. Keep zod validation on every write.
- **Concurrency pitfall (learned the hard way):** with a file-based
  read-merge-write store, two client write paths hitting the same document
  will last-writer-wins each other. Serialize client-side writes through one
  mutex (or add a server-side lock). Also: when merging grid-row edits, merge
  into the freshest server/cache value — never into stale local state — or
  concurrent field edits (e.g. a media pick + a text edit) drop one another.

## 7. Agent-assisted features (optional layer)

Server endpoints wrap an LLM: generate size variants, autofill feed rows from a
brief, improve copy for a row, suggest smart crops, auto-tag, run matrix QA
(findings with severity per row × size), and a streaming studio chat panel
(`StudioAgentPanel.tsx`, modals in `agent-modals.tsx`). Each is a
prompt-in/JSON-out wrapper — port them last; the studio stands alone without
them.

## 8. Step-by-step build plan for the receiving agent

1. **Install** frontend + backend libraries from `docs/LIBRARIES.md`.
2. **Port the type model** (`types.ts`) to client and server (keep them
   mirrored) and the store layer (or re-implement over your DB).
3. **Implement the API** from `docs/API_SURFACE.md`: templates → assets →
   feeds → renders → reviews (agent endpoints last).
4. **Port the canvas engine**: `cropMath.ts` (+ its tests, run them),
   `scene.ts`, then `StudioKonva.tsx`. Verify a hardcoded scene renders before
   wiring pages.
5. **Port pages in dependency order**: StudioLayout → assets → templates →
   template-detail → editor (full-screen) → feeds → feed-detail →
   creative-editor → feed-preview (render queue) → qa → review → dashboard →
   library.
6. **Adapt host-app specifics**: router (`wouter` calls), `@/` path aliases,
   Tailwind tokens/shadcn components, toast system, API base path.
7. **Apply the §5 crop-overlay fix** (full-frame drag surface).
8. **Verify end-to-end**: upload an asset → build a 2-size template with a
   bound media + text field → create a feed with 3 rows → per-creative crop on
   one row → render all → export zip → approve pack.

## 9. Non-goals / deliberate decisions

- No commercial canvas SDK (rejected: watermark/paid key). Konva only.
- No server-side rendering of creatives — the browser is the renderer.
- No MP4 export (browser MediaRecorder capture was explored and abandoned);
  GIF + HTML5 zip cover animated needs.
- Client/server types stay hand-mirrored on this surface; don't force it into
  an API-codegen pipeline while the scene model is still evolving.
