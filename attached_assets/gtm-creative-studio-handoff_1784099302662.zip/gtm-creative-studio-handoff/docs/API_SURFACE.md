# Backend API Surface

All endpoints the studio frontend expects, as implemented in
`src/backend/studio.routes.ts`. Mount them under your API prefix (the reference
app uses `/api`). Responses are JSON; entities match the types in
`src/frontend/components/studio/types.ts` (which hand-mirror the server types in
`src/backend/studio-store.ts`).

## Templates

| Method | Path | Purpose |
|---|---|---|
| GET | `/studio/templates` | List templates `{ templates: StudioTemplate[] }` |
| POST | `/studio/templates` | Create a template — body is `{ name, brand? }` only; the store seeds default variants/schema internally |
| GET | `/studio/templates/:id` | Fetch one → `{ template }` |
| PUT | `/studio/templates/:id` | Update template metadata |
| PUT | `/studio/templates/:id/schema` | Replace the schema fields (bindable field definitions) |
| PUT | `/studio/templates/:id/output` | Save output settings (formats per variant) |
| DELETE | `/studio/templates/:id` | Delete |
| POST | `/studio/templates/:id/variants` | Add a size/variant (blank or preset) |
| POST | `/studio/templates/:id/variants/:variantId/duplicate` | Exact clone of a variant (new id/name, same size & scene) — resizing is done afterwards in the editor |
| PUT | `/studio/templates/:id/variants/:variantId` | Save a variant's scene (the canvas editor's save path) |
| DELETE | `/studio/templates/:id/variants/:variantId` | Remove a variant |

## Assets

| Method | Path | Purpose |
|---|---|---|
| GET | `/studio/assets` | List asset index |
| POST | `/studio/assets` | Multipart upload (multer). Probe dimensions with sharp, persist file + metadata |
| PATCH | `/studio/assets/:id` | Update asset metadata (tags, kind) |
| DELETE | `/studio/assets/:id` | Delete asset + file |
| GET | `/studio/assets/file/:fileName` | Serve the binary (long-cache headers) |

## Feeds (creative data)

| Method | Path | Purpose |
|---|---|---|
| GET | `/studio/feeds` | List feeds (optionally by template) |
| POST | `/studio/feeds` | Create feed bound to a template |
| GET | `/studio/feeds/:id` | Fetch one |
| PUT | `/studio/feeds/:id` | Rename / update |
| DELETE | `/studio/feeds/:id` | Delete |
| POST | `/studio/feeds/:id/rows` | Add creative row(s) |
| PUT | `/studio/feeds/:id/rows/:rowId` | Save a row: `values`, `crops`, `styleOverrides`, tags, locale |
| DELETE | `/studio/feeds/:id/rows/:rowId` | Remove a row |

## Renders & export

| Method | Path | Purpose |
|---|---|---|
| GET | `/studio/renders` | List render records (filter by feed) |
| POST | `/studio/renders` | Persist client-captured renders (base64 payloads → files + records) |
| GET | `/studio/renders/file/:fileName` | Serve a rendered file |
| GET | `/studio/renders/export` | Zip a selection of renders for download |

> Rendering itself happens **in the browser** (Konva stage → `toDataURL` /
> frame-captured GIF / zipped HTML5). The server only stores the results.

## Review / approval

| Method | Path | Purpose |
|---|---|---|
| GET | `/studio/reviews-summary` | Approval status across feeds |
| GET | `/studio/reviews/:feedId` | Per-feed review state (per row × size entries) |
| PUT | `/studio/reviews/:feedId` | Save entry statuses / notes |
| POST | `/studio/reviews/:feedId/approve` | Approve the pack |
| POST | `/studio/distribution/handoff` | Record a distribution handoff of approved renders |

## Agent features (optional, LLM-backed)

| Method | Path | Purpose |
|---|---|---|
| POST | `/studio/agent/generate-variants` | Propose new size variants from an existing scene |
| POST | `/studio/agent/feed-autofill` | Fill feed rows from a brief/context |
| POST | `/studio/agent/improve-creative` | Copy improvement suggestions for a row |
| POST | `/studio/agent/smart-crop` | Suggest focal crops per size |
| POST | `/studio/agent/auto-tag` | Tag assets/rows |
| POST | `/studio/agent/matrix-qa` | Run QA findings across the row × size matrix |
| POST | `/studio/agent/chat` (+ `/stream`) | Studio copilot chat (SSE streaming variant) |

All agent endpoints are additive: build the studio first, wire these later.
