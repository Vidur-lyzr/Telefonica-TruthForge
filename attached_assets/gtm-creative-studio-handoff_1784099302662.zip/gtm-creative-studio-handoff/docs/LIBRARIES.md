# Libraries & Open-Source Tools

Everything the studio actually uses, with the role each plays. Versions are the
ones proven working together; newer minors are generally fine.

## Frontend — core

| Library | Version | Role |
|---|---|---|
| `react` / `react-dom` | 18.x | UI framework |
| `vite` + `@vitejs/plugin-react` | 5.x/6.x | Build tool / dev server |
| `typescript` | 5.x | Types everywhere; the scene model is fully typed |
| `wouter` | ^3.3.5 | Tiny client-side router (swap for the host app's router if different) |
| `@tanstack/react-query` | 5.x | Server-state caching for templates/assets/feeds/renders |
| `zod` | 3.x | Input validation shared shape with the server |

## Frontend — canvas engine (the heart of the studio)

| Library | Version | Role |
|---|---|---|
| `konva` | ^10.3.0 | 2D canvas scene graph: layers, transforms, filters, hit-testing, drag |
| `react-konva` | ^19.2.5 | Declarative React bindings for Konva — the whole scene renders as JSX |
| `gifenc` | ^1.0.3 | Client-side GIF encoding for animated-variant export (frame capture → GIF) |
| `fflate` | ^0.8.3 | Client-side zip packaging (HTML5 ad bundles, batch download) |

**Decision record — do NOT use a commercial canvas SDK.** We evaluated an
off-the-shelf design-editor SDK (Polotno) and rejected it: the free tier
watermarks output and production use requires a paid key. The entire editor —
selection, drag, resize, text editing, image cover-crop, blur/sharpen filters,
animation preview, export capture — is built on plain `konva` + `react-konva`
and is fully self-owned. The receiving agent should do the same.

## Frontend — UI chrome

| Library | Version | Role |
|---|---|---|
| `tailwindcss` | 4.x | Styling (utility classes; adapt tokens to host app) |
| `@radix-ui/*` (dialog, dropdown, select, slider, tabs, tooltip, toast, etc.) | 1.x–2.x | Accessible primitives (shadcn/ui-style components) |
| `lucide-react` | latest | Icons |
| `sonner` | ^2.0.7 | Toasts |
| `class-variance-authority`, `clsx`, `tailwind-merge` | latest | Class composition helpers |
| `react-resizable-panels` | ^2.1.7 | Split panes in the editor |
| `date-fns` | ^3.6.0 | Timestamps in lists |

## Backend

| Library | Version | Role |
|---|---|---|
| `express` | ^5 | HTTP server |
| `multer` | ^2.1.1 | Multipart asset uploads (memory storage → write to disk) |
| `sharp` | ^0.35.1 | Server-side image probing (dimensions) and processing |
| `zod` | 3.x | Request validation |
| `pino` + `pino-http` | 9/10 | Structured logging |
| `fflate` | ^0.8.3 | Server-side zip export of render packs (`zipSync`) — required |
| `jszip` | ^3.10.1 | Optional; used elsewhere in the reference app, NOT by the studio endpoints |

## Optional — agent features

The AI-assisted features (variant generation, feed autofill, improve-creative,
smart-crop suggestions, auto-tagging, matrix QA, studio chat) call a hosted LLM
API from the server. Any provider SDK works; the endpoints are thin wrappers
that build a prompt from the template/feed JSON and parse a JSON reply. These
features are additive — the studio is fully usable without them.

## Explicitly NOT needed

- No image-editing SaaS, no headless browser for rendering (all rendering is
  client-side Konva; the browser that runs the editor is the renderer).
- No database required to start: the reference implementation persists JSON
  files + an uploads directory. Swap the thin store layer for a DB when needed.
- MP4/video export was deliberately deferred: browser `MediaRecorder` capture
  of canvas proved unreliable (a dead end we already explored). GIF + HTML5
  zip cover animated output.
