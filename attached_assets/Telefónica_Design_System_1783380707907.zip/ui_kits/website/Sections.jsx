/* Telefónica corporate site — content sections */
const grad = (c1, c2) =>
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='400' height='250'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='${c1}'/><stop offset='1' stop-color='${c2}'/></linearGradient></defs><rect width='400' height='250' fill='url(#g)'/><g fill='rgba(255,255,255,.10)'><circle cx='330' cy='60' r='5'/><circle cx='360' cy='60' r='5'/><circle cx='345' cy='90' r='5'/><circle cx='345' cy='120' r='5'/></g></svg>`
  );

function TFFocusAreas() {
  const I = window.TFIcons;
  const items = [
    { icon: <I.Wifi />, title: 'Networks', desc: 'Fibre and 5G that reach further, carrying more data with less energy per bit.' },
    { icon: <I.Bolt />, title: 'Open Gateway', desc: 'Standardised APIs that put network capabilities directly in developers\u2019 hands.' },
    { icon: <I.Leaf />, title: 'Sustainability', desc: 'Net-zero targets and a circular approach to devices across our operations.' },
    { icon: <I.Users />, title: 'Digital society', desc: 'Bridging the digital divide and building skills for millions of people.' },
  ];
  return (
    <section className="tf-container tf-sec">
      <div className="tf-sec__head">
        <div>
          <div className="tf-sec__eyebrow">What we do</div>
          <h2 className="tf-sec__title">A single company behind four commitments</h2>
        </div>
        <p className="tf-sec__lead">From the network to the neighbourhood, technology only matters when it reaches people.</p>
      </div>
      <div className="tf-focus-grid">
        {items.map((it) => (
          <div className="tf-focus" key={it.title}>
            <div className="tf-focus__icon" style={{ fontSize: 26 }}>{it.icon}</div>
            <h3 className="tf-focus__title">{it.title}</h3>
            <p className="tf-focus__desc">{it.desc}</p>
            <span className="tf-focus__more">Learn more <I.ArrowRight style={{ fontSize: 16 }} /></span>
          </div>
        ))}
      </div>
    </section>
  );
}

function TFStats() {
  return (
    <section className="tf-container">
      <div className="tf-stats">
        <div className="tf-stats__bg" />
        <div className="tf-stat"><div className="tf-stat__num">300<em>M+</em></div><div className="tf-stat__label">Customers across our footprint</div></div>
        <div className="tf-stat"><div className="tf-stat__num">12</div><div className="tf-stat__label">Countries in Europe &amp; Latin America</div></div>
        <div className="tf-stat"><div className="tf-stat__num">1924</div><div className="tf-stat__label">Founded in Madrid — a century of connection</div></div>
      </div>
    </section>
  );
}

const NEWS = [
  { cat: 'Networks', c: 'Networks', title: '5G Standalone reaches 2,000 more towns across the country', date: '12 Jun 2026', g: ['#0066FF', '#001B41'] },
  { cat: 'Innovation', c: 'Innovation', title: 'Open Gateway APIs cross one billion monthly calls', date: '09 Jun 2026', g: ['#00C1B5', '#0047B3'] },
  { cat: 'Sustainability', c: 'Sustainability', title: 'On track for net-zero: renewable energy now powers our core', date: '03 Jun 2026', g: ['#1AB759', '#004E7A'] },
  { cat: 'Innovation', c: 'Innovation', title: 'A new AI assistant lands in the Movistar app', date: '28 May 2026', g: ['#7D5CFF', '#001B41'] },
  { cat: 'Networks', c: 'Networks', title: 'Subsea cable upgrade doubles Atlantic capacity', date: '21 May 2026', g: ['#0066FF', '#0A2A5E'] },
  { cat: 'Sustainability', c: 'Sustainability', title: 'One million devices given a second life through trade-in', date: '14 May 2026', g: ['#1AB759', '#0047B3'] },
];

function TFNewsroom() {
  const { Tabs, Card, Tag } = window.TelefNicaDesignSystem_29ea10;
  const I = window.TFIcons;
  const [filter, setFilter] = React.useState('all');
  const tabs = [
    { id: 'all', label: 'All' },
    { id: 'Networks', label: 'Networks' },
    { id: 'Innovation', label: 'Innovation' },
    { id: 'Sustainability', label: 'Sustainability' },
  ];
  const shown = NEWS.filter((n) => filter === 'all' || n.c === filter);
  return (
    <section className="tf-container tf-sec" style={{ paddingTop: 24 }}>
      <div className="tf-sec__head">
        <div>
          <div className="tf-sec__eyebrow">Newsroom</div>
          <h2 className="tf-sec__title">Latest stories</h2>
        </div>
      </div>
      <div className="tf-news__tabs"><Tabs items={tabs} value={filter} onChange={setFilter} /></div>
      <div className="tf-news-grid">
        {shown.map((n) => (
          <Card key={n.title} href="#" media={grad(n.g[0], n.g[1])}
            eyebrow={<Tag variant="info">{n.cat}</Tag>}
            title={n.title}
            footer={<span className="tf-news__date">{n.date} · 3 min read</span>} />
        ))}
      </div>
    </section>
  );
}

function TFBrands() {
  return (
    <section className="tf-container">
      <div className="tf-brands">
        <span className="tf-brands__label">Our commercial brands</span>
        <div className="tf-brands__list">
          <span className="tf-brands__item">Movistar</span>
          <span className="tf-brands__item">O<sub style={{ fontSize: '.6em' }}>2</sub></span>
          <span className="tf-brands__item">Vivo</span>
          <span className="tf-brands__item">Tuenti</span>
        </div>
      </div>
    </section>
  );
}
Object.assign(window, { TFFocusAreas, TFStats, TFNewsroom, TFBrands });
