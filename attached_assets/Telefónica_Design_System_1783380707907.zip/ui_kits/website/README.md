# UI Kit — Telefónica.com (Corporate website)

A high-fidelity recreation of the Telefónica **corporate** homepage (telefonica.com) — the investor/newsroom-facing site, not a consumer shop. It composes the design-system primitives; it does not re-implement them.

## Run
Open `index.html`. It loads (in order):
1. `../../styles.css` — tokens + component classes
2. `site.css` — kit-only layout
3. React 18 + Babel (pinned)
4. `../../assets/icons.js` → `window.TFIcons` (placeholder line icons)
5. `../../_ds_bundle.js` → `window.TelefNicaDesignSystem_29ea10` (Button, Card, Tag, Tabs…)
6. `Header.jsx`, `Hero.jsx`, `Sections.jsx`, `Footer.jsx` → each exports to `window`

## Screens / sections
- **Header** — sticky, blurred; primary nav with dropdown affordances; search toggle; language pill.
- **Hero** — full-width rounded navy→blue editorial panel with dot texture, headline and two CTAs (`Button` inverse + ghost-on-blue).
- **Focus areas** — four-up feature grid (Networks, Open Gateway, Sustainability, Digital society).
- **Stats band** — deep-navy figures panel.
- **Newsroom** — `Tabs`-filtered grid of `Card`s (category `Tag`, gradient media, date footer).
- **Brands strip** — commercial brand wordmarks (Movistar, O2, Vivo, Tuenti) as text (their logos are separate brand assets, not included).
- **Footer** — navy, four link columns, legal + social text links.

## Interactions
- Search icon toggles an inline search bar.
- Newsroom tabs filter the news cards live.
- Buttons / cards / focus tiles have real hover, focus and press states from the token CSS.

## Fidelity notes
- Copy and figures are **illustrative placeholders** in the brand's voice, not live corporate data.
- Icons are Lucide-style placeholders (`window.TFIcons`) — swap for the real `mistica-icons` set for production.
- The five-dot **T** emblem is pending the real logo SVG; the wordmark placeholder stands in.
