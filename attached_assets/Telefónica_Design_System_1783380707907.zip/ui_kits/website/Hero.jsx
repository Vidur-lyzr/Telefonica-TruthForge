/* Telefónica corporate site — Hero */
function TFHero() {
  const { Button } = window.TelefNicaDesignSystem_29ea10;
  const I = window.TFIcons;
  return (
    <section className="tf-container">
      <div className="tf-hero">
        <div className="tf-hero__panel">
          <div className="tf-hero__bg" />
          <div className="tf-hero__glow" />
          <div className="tf-hero__content">
            <div className="tf-hero__eyebrow">Newsroom · 4 min read</div>
            <h1 className="tf-hero__title">Connecting people and unlocking the opportunities of technology</h1>
            <p className="tf-hero__sub">Our networks reach hundreds of millions of people across Europe and Latin America — and we're building the digital backbone for what comes next.</p>
            <div className="tf-hero__cta">
              <Button variant="inverse" iconRight={<I.ArrowRight />}>Read the story</Button>
              <Button variant="secondary" iconLeft={<I.Play />}>Watch the film</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
Object.assign(window, { TFHero });
