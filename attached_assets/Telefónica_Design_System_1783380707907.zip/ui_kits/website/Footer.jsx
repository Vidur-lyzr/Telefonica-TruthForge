/* Telefónica corporate site — Footer */
function TFFooter() {
  const cols = [
    { h: 'Company', links: ['About Telefónica', 'Our leadership', 'Careers', 'Suppliers'] },
    { h: 'Investors', links: ['Shareholders', 'Results', 'Share price', 'Bonds & ratings'] },
    { h: 'Innovation', links: ['Open Gateway', 'Telefónica Tech', 'Wayra', 'Patents'] },
    { h: 'Newsroom', links: ['Press releases', 'Media library', 'Events', 'Contact'] },
  ];
  return (
    <footer className="tf-ftr">
      <div className="tf-container">
        <div className="tf-ftr__top">
          <div className="tf-ftr__brand">
            <img src="../../assets/telefonica-logo-white.png" alt="Telefónica" />
            <p className="tf-ftr__tagline">Connecting people and unlocking the opportunities of technology.</p>
          </div>
          {cols.map((c) => (
            <div className="tf-ftr__col" key={c.h}>
              <h4>{c.h}</h4>
              {c.links.map((l) => <a href="#" key={l}>{l}</a>)}
            </div>
          ))}
        </div>
        <div className="tf-ftr__bottom">
          <span>© 2026 Telefónica, S.A. — Gran Vía 28, Madrid. All rights reserved.</span>
          <div className="tf-ftr__social">
            <a href="#">LinkedIn</a><a href="#">X</a><a href="#">YouTube</a><a href="#">Instagram</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
Object.assign(window, { TFFooter });
