/* Telefónica corporate site — Header (sticky nav + search) */
function TFHeader({ searchOpen, onSearchToggle }) {
  const I = window.TFIcons;
  const nav = ['Shareholders & Investors', 'About Telefónica', 'Innovation', 'Sustainability', 'Newsroom'];
  return (
    <header className="tf-hdr">
      <div className="tf-container tf-hdr__row">
        <a className="tf-hdr__logo" href="#" aria-label="Telefónica home">
          <img src="../../assets/telefonica-logo.png" alt="Telefónica" />
        </a>
        <nav className="tf-hdr__nav">
          {nav.map((n) => (
            <button key={n} className="tf-hdr__link">
              {n}<I.ChevronDown style={{ fontSize: 15, opacity: .55 }} />
            </button>
          ))}
        </nav>
        <div className="tf-hdr__spacer" />
        <div className="tf-hdr__utils">
          <button className="tf-hdr__iconbtn" aria-label={searchOpen ? 'Close search' : 'Search'} onClick={onSearchToggle}>
            {searchOpen ? <I.Close /> : <I.Search />}
          </button>
          <button className="tf-lang"><I.Globe style={{ fontSize: 17 }} /> EN</button>
        </div>
      </div>
      {searchOpen && (
        <div className="tf-search">
          <div className="tf-container tf-search__inner">
            <I.Search style={{ fontSize: 22, color: 'var(--text-secondary)' }} />
            <input className="tf-search__input" placeholder="Search telefonica.com…" autoFocus />
            <span style={{ font: '500 13px var(--font-sans)', color: 'var(--text-secondary)' }}>Press Enter ↵</span>
          </div>
        </div>
      )}
    </header>
  );
}
Object.assign(window, { TFHeader });
