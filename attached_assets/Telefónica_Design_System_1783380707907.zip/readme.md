# Telefónica Design System

A brand-accurate design system for **Telefónica corporate** — the vivid-blue, five-dot identity used across [telefonica.com](https://www.telefonica.com/en/) (investor, newsroom and corporate surfaces), **not** the consumer sub-brands (Movistar, O2, Vivo).

It ships design tokens, foundation specimens, reusable React components, a corporate-website UI kit and a branded slide set — everything an agent needs to produce on-brand Telefónica interfaces and assets.

---

## Sources & ground truth

This system was assembled from public, first-party references:

- **Corporate site** — https://www.telefonica.com/en/ and /es/ (layout, tone, structure).
- **Mística** — Telefónica's own open-source design system (MIT), used as the authority for values and iconography:
  - Design/tokens: https://github.com/Telefonica/mistica-design
  - React library: https://github.com/Telefonica/mistica-web
  - **Icons:** https://github.com/Telefonica/mistica-icons
- **Brand blue `#0066FF`** — confirmed across the corporate mark and brand references (RGB 0 102 255).
- **Logo** — the 2021 five-dot "**T**" + "Telefónica" lockup in brand blue. The real artwork was supplied by the team and is shipped as `assets/telefonica-logo.png` (blue) and `assets/telefonica-logo-white.png` (dark surfaces).

> These links are recorded so a reader with access can verify or extend the system; nothing here assumes you can reach them.

### ⚠ Substitutions & open items (please help me finalise)
1. **Typeface** — the brand face *Telefónica Sans* (a customised **TT Hoves**) is proprietary. We ship the closest free match, **Hanken Grotesk** (Google Fonts). Replace it in `fonts/fonts.css` with the licensed web-font to be pixel-exact.
2. **Icons** — `assets/icons.js` (`window.TFIcons`) is a Lucide-style **placeholder** set. Swap for the real `mistica-icons` for production.

✅ **Logo** — the real five-dot "T" + Telefónica lockup (supplied by the team) is now wired in: `assets/telefonica-logo.png` (blue, transparent) on light surfaces and `assets/telefonica-logo-white.png` on navy/blue. The white background was knocked out and both variants recoloured for crisp edges.

---

## Content fundamentals — how Telefónica writes

- **Voice:** optimistic, human and purpose-led; plain over technical. The brand line is *"Connecting people and unlocking the opportunities of technology."* Copy keeps returning to **people, connection, opportunity, technology, digital**.
- **Person:** the company speaks as **"we / our"**; the customer is **"you"**. Corporate/IR copy leans "we".
- **Casing:** **sentence case** for headlines and buttons (`Read the story`, not `Read The Story`). ALL-CAPS is reserved for small eyebrows/labels with wide tracking (`+0.06–0.09em`).
- **Headlines:** short, confident, forward-looking; large type does the emphasis, not punctuation. Rare exclamation marks.
- **Tone examples:**
  - Hero: *"Connecting what's next — a century of connection, and a network built for the age of intelligence."*
  - Feature: *"Turning the network into a platform."*
  - Legal/utility: precise and calm — *"Terms apply. Coverage subject to network availability."*
- **Emoji:** **not used** in corporate contexts. Unicode arrows (`→`, `↵`) appear sparingly in UI microcopy.
- **Bilingual:** Spanish + English are both first-class; keep sentences translation-friendly (avoid idiom).

---

## Visual foundations

**Colour.** White carries most surfaces; **brand blue `#0066FF`** does the identity work (CTAs, links, focus, icon tints, key fills). **Deep navy `#001B41`** anchors full-bleed dark sections, stats bands and footers. Cool greys (`#F8F8FB → #1B1B25`) handle text, borders and surfaces. Semantic colours (success `#1AB759`, warning `#FFB800`, error `#FF4133`, info = blue) are used sparingly. A teal (`#00C1B5`) appears only as an occasional accent glow. One or two blues per composition — never a rainbow.

**Typography.** A **single sans** across the whole brand. Display/headings are **bold with tight negative tracking** (`-1.2 to -3px` at large sizes) — oversized type is a signature Telefónica move. Body is regular 16–18px at ~1.5 line-height; labels are medium 14px; eyebrows are bold, uppercase, tracked. Scale mirrors Mística presets (display / title / body / caption).

**Spacing & layout.** 8px grid with 2/4 half-steps. Generous section rhythm (~80px vertical). Content maxes around 1200px with 24px gutters. Composition is airy and editorial, not dense.

**Backgrounds.** Mostly **flat white**. Hero/impact surfaces use a **navy→blue gradient** with a subtle **dot-grid texture** (a quiet nod to the five-dot emblem — never the mark itself) and an optional soft teal glow. Imagery is **photographic, human and optimistic**, blue-forward and bright — no heavy filters or grain.

**Corner radii.** Buttons, chips and tags are **fully rounded (pill)** — a signature trait. Inputs and small cards use **8px**; media and large cards **16px**; hero panels **24px**; avatars and icon buttons are **circular**.

**Borders.** Hairline `1px` grey-200 on cards; `1.5px` grey-300 on form controls; focus is a `3px` blue ring (`rgba(0,102,255,.35)`). Dark surfaces use `rgba(255,255,255,.15)` dividers.

**Elevation / shadows.** Soft and low-contrast, used **sparingly** — resting cards (`elevation-2`), menus (`3`), dialogs (`4`). Telefónica prefers flat surfaces + hairlines over heavy shadow. A special `--elevation-brand` blue glow can lift a primary CTA.

**Cards.** White, either hairline-bordered *or* softly elevated (border drops when elevated), 16px radius, optional 16:10 media on top, body with eyebrow → title → description, footer for actions. Interactive cards **lift 2–3px** with a shadow and turn the title blue on hover.

**Motion.** Calm and functional: **120–320ms** fades/slides on a standard ease (`cubic-bezier(.4,0,.2,1)`); entrances decelerate. **No bounce, no springy scale.** Buttons nudge `0.5px` on press.

**Hover / press.** Hover = subtle background tint (grey-100) or a step-darker fill for primary; links underline; cards lift. Press = one step darker + a hair of downward nudge. Disabled = grey-200 fill / grey-400 text, no shadow.

**Transparency & blur.** The sticky header is translucent white with `backdrop-filter: blur`. Overlays/scrims use navy tints. Otherwise transparency is minimal.

---

## Iconography

- **Real system:** **Mística icons** (open source — `Telefonica/mistica-icons`): a consistent **line** family on a ~24px grid, rounded joins, with *light / regular / filled* variants. Icons are monochrome, inherit `currentColor`, and are frequently shown **blue-tinted inside rounded "app-tile" badges** for feature blocks.
- **Shipped here:** `assets/icons.js` exposes `window.TFIcons` — Lucide-style line glyphs (24px, 2px stroke, round caps) as a **flagged placeholder**. Swap for the licensed `mistica-icons` in production.
- **Emoji:** never in corporate UI. Unicode arrows are used occasionally in microcopy.
- **The five-dot "T"** is the master brand mark; it ships as an **image asset** (`assets/telefonica-logo.png`, plus `-white.png` for dark surfaces) and is echoed — never re-drawn — by the dot-grid textures on hero and stats panels.

---

## What's in here (index / manifest)

**Root**
- `styles.css` — the single entry point consumers link (an `@import` manifest only).
- `readme.md` — this guide. · `SKILL.md` — Agent-Skills wrapper.

**`tokens/`** — `colors.css`, `typography.css`, `spacing.css`, `radius.css`, `elevation.css`, `motion.css`, `base.css` (reset + type-preset helpers).

**`fonts/`** — `fonts.css` (Hanken Grotesk substitute; see open items).

**`assets/`** — `telefonica-logo.png` + `telefonica-logo-white.png` (the real lockup, blue + white), `icons.js` (`window.TFIcons`).

**`foundations/`** — 15 `@dsCard` specimens: Colors (Primary, Deep Blue, Neutrals, Semantic), Type (Display, Titles, Body & Caption, Weights, Typeface), Spacing (Scale, Radius, Elevation), Brand (Logo, Blue in use).

**`components/`** — reusable React primitives (each with `.jsx` + `.d.ts` + `.prompt.md`, one demo card per group). Namespace: `window.TelefNicaDesignSystem_29ea10`.
- `actions/` — **Button**, **IconButton**
- `forms/` — **TextField**, **Select**, **Checkbox**, **Radio**, **Switch**
- `data-display/` — **Card**, **Tag**, **Badge**, **Avatar**
- `feedback/` — **Callout**, **ProgressBar**
- `navigation/` — **Tabs**

**`ui_kits/website/`** — Telefónica.com corporate-home recreation (`Header`, `Hero`, `Sections`, `Footer` → `index.html`). See its `README.md`.

**`slides/`** — six branded 16:9 slide types: Title, Section divider, Content, Impact/Stats, Quote, Closing.

### Intentional additions
Telefónica's Mística is large; this is a focused, faithful subset. Additions beyond a literal token dump:
- **`window.TFIcons`** placeholder icon set — needed so kits/slides render before the real `mistica-icons` are wired in.
- **Slide set** — not part of Mística's web catalogue, added as a high-value brand artifact built entirely from the foundations above.

---

*Namespace for `@dsCard` / kit HTML:* `const { Button, Card, Tag, Tabs } = window.TelefNicaDesignSystem_29ea10`.
